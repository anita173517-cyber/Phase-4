.class public abstract La1/b0;
.super La1/a0;
.source "SourceFile"
