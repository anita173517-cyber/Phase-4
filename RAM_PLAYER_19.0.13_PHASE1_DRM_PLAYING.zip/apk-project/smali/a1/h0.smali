.class public interface abstract La1/h0;
.super Ljava/lang/Object;
.source "SourceFile"
