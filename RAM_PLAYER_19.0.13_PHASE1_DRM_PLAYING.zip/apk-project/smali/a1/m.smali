.class public final La1/m;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ly0/c;


# static fields
.field public static final n:Lq5/u;


# instance fields
.field public final k:Lcom/google/common/util/concurrent/s;

.field public final l:Ll3/i0;

.field public final m:I


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, La1/j;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, La1/j;-><init>(I)V

    .line 5
    .line 6
    .line 7
    invoke-static {v0}, Lc4/b0;->u(Lq5/u;)Lq5/u;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    sput-object v0, La1/m;->n:Lq5/u;

    .line 12
    .line 13
    return-void
.end method

.method public constructor <init>(La1/l;)V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Ll3/i0;

    .line 5
    .line 6
    iget-object v1, p1, La1/l;->k:Landroid/content/Context;

    .line 7
    .line 8
    invoke-direct {v0, v1}, Ll3/i0;-><init>(Landroid/content/Context;)V

    .line 9
    .line 10
    .line 11
    iput-object v0, p0, La1/m;->l:Ll3/i0;

    .line 12
    .line 13
    sget-object v0, La1/m;->n:Lq5/u;

    .line 14
    .line 15
    invoke-interface {v0}, Lq5/u;->get()Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    check-cast v0, Lcom/google/common/util/concurrent/s;

    .line 20
    .line 21
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 22
    .line 23
    .line 24
    iput-object v0, p0, La1/m;->k:Lcom/google/common/util/concurrent/s;

    .line 25
    .line 26
    iget p1, p1, La1/l;->l:I

    .line 27
    .line 28
    iput p1, p0, La1/m;->m:I

    .line 29
    .line 30
    return-void
.end method


# virtual methods
.method public final a(Lv0/n0;)Lcom/google/common/util/concurrent/r;
    .locals 2

    .line 1
    iget-object v0, p1, Lv0/n0;->k:[B

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    invoke-virtual {p0, v0}, La1/m;->q([B)Lcom/google/common/util/concurrent/r;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    return-object p1

    .line 10
    :cond_0
    iget-object p1, p1, Lv0/n0;->n:Landroid/net/Uri;

    .line 11
    .line 12
    if-eqz p1, :cond_1

    .line 13
    .line 14
    new-instance v0, La1/k;

    .line 15
    .line 16
    const/4 v1, 0x1

    .line 17
    invoke-direct {v0, p0, p1, v1}, La1/k;-><init>(La1/m;Ljava/lang/Object;I)V

    .line 18
    .line 19
    .line 20
    iget-object p1, p0, La1/m;->k:Lcom/google/common/util/concurrent/s;

    .line 21
    .line 22
    check-cast p1, Lcom/google/common/util/concurrent/u;

    .line 23
    .line 24
    invoke-virtual {p1, v0}, Lcom/google/common/util/concurrent/u;->a(Ljava/util/concurrent/Callable;)Lcom/google/common/util/concurrent/r;

    .line 25
    .line 26
    .line 27
    move-result-object p1

    .line 28
    return-object p1

    .line 29
    :cond_1
    const/4 p1, 0x0

    .line 30
    return-object p1
.end method

.method public final q([B)Lcom/google/common/util/concurrent/r;
    .locals 2

    .line 1
    new-instance v0, La1/k;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, p0, p1, v1}, La1/k;-><init>(La1/m;Ljava/lang/Object;I)V

    .line 5
    .line 6
    .line 7
    iget-object p1, p0, La1/m;->k:Lcom/google/common/util/concurrent/s;

    .line 8
    .line 9
    check-cast p1, Lcom/google/common/util/concurrent/u;

    .line 10
    .line 11
    invoke-virtual {p1, v0}, Lcom/google/common/util/concurrent/u;->a(Ljava/util/concurrent/Callable;)Lcom/google/common/util/concurrent/r;

    .line 12
    .line 13
    .line 14
    move-result-object p1

    .line 15
    return-object p1
.end method
