.class public final La1/t;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La1/h;
.implements Lu2/c;


# instance fields
.field public k:I

.field public l:I

.field public final m:Ljava/lang/Object;


# direct methods
.method public constructor <init>(I)V
    .locals 3

    sparse-switch p1, :sswitch_data_0

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    new-instance p1, Ll4/c;

    const/4 v0, 0x1

    invoke-direct {p1, v0}, Ll4/c;-><init>(I)V

    iput-object p1, p0, La1/t;->m:Ljava/lang/Object;

    const/16 p1, 0x1f40

    .line 4
    iput p1, p0, La1/t;->k:I

    .line 5
    iput p1, p0, La1/t;->l:I

    return-void

    .line 6
    :sswitch_0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/16 p1, 0x100

    .line 7
    new-array p1, p1, [La1/t;

    iput-object p1, p0, La1/t;->m:Ljava/lang/Object;

    const/4 p1, 0x0

    .line 8
    iput p1, p0, La1/t;->k:I

    .line 9
    iput p1, p0, La1/t;->l:I

    return-void

    .line 10
    :sswitch_1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/high16 p1, 0x50000

    iput p1, p0, La1/t;->k:I

    .line 11
    new-instance p1, Ljava/util/LinkedHashMap;

    const/high16 v0, 0x3f400000    # 0.75f

    const/4 v1, 0x1

    const/16 v2, 0x10

    invoke-direct {p1, v2, v0, v1}, Ljava/util/LinkedHashMap;-><init>(IFZ)V

    iput-object p1, p0, La1/t;->m:Ljava/lang/Object;

    return-void

    :sswitch_data_0
    .sparse-switch
        0x2 -> :sswitch_1
        0x5 -> :sswitch_0
    .end sparse-switch
.end method

.method public constructor <init>(II)V
    .locals 1

    .line 16
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    .line 17
    iput-object v0, p0, La1/t;->m:Ljava/lang/Object;

    .line 18
    iput p1, p0, La1/t;->k:I

    and-int/lit8 p1, p2, 0x7

    if-nez p1, :cond_0

    const/16 p1, 0x8

    .line 19
    :cond_0
    iput p1, p0, La1/t;->l:I

    return-void
.end method

.method public synthetic constructor <init>(ILjava/lang/Object;I)V
    .locals 0

    .line 1
    iput p1, p0, La1/t;->k:I

    iput p3, p0, La1/t;->l:I

    iput-object p2, p0, La1/t;->m:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(Lz0/d;Lv0/t;)V
    .locals 3

    .line 20
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 21
    iget-object p1, p1, Lz0/d;->m:Ly0/w;

    iput-object p1, p0, La1/t;->m:Ljava/lang/Object;

    const/16 v0, 0xc

    .line 22
    invoke-virtual {p1, v0}, Ly0/w;->N(I)V

    .line 23
    invoke-virtual {p1}, Ly0/w;->E()I

    move-result v0

    .line 24
    const-string v1, "audio/raw"

    iget-object v2, p2, Lv0/t;->p:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    .line 25
    iget v1, p2, Lv0/t;->M:I

    iget p2, p2, Lv0/t;->J:I

    .line 26
    invoke-static {v1}, Ly0/k0;->u(I)I

    move-result v1

    mul-int/2addr v1, p2

    .line 27
    rem-int p2, v0, v1

    if-eqz p2, :cond_0

    .line 28
    new-instance p2, Ljava/lang/StringBuilder;

    const-string v2, "Audio sample size mismatch. stsd sample size: "

    invoke-direct {p2, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, ", stsz sample size: "

    invoke-virtual {p2, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const-string v0, "BoxParsers"

    invoke-static {v0, p2}, Ly0/a;->l(Ljava/lang/String;Ljava/lang/String;)V

    move v0, v1

    :cond_0
    if-nez v0, :cond_1

    const/4 v0, -0x1

    .line 29
    :cond_1
    iput v0, p0, La1/t;->k:I

    .line 30
    invoke-virtual {p1}, Ly0/w;->E()I

    move-result p1

    iput p1, p0, La1/t;->l:I

    return-void
.end method

.method public constructor <init>([BII)V
    .locals 0

    .line 12
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 13
    iput-object p1, p0, La1/t;->m:Ljava/lang/Object;

    .line 14
    iput p2, p0, La1/t;->k:I

    .line 15
    iput p3, p0, La1/t;->l:I

    return-void
.end method


# virtual methods
.method public a()I
    .locals 1

    .line 1
    iget v0, p0, La1/t;->k:I

    .line 2
    .line 3
    return v0
.end method

.method public b()I
    .locals 1

    .line 1
    iget v0, p0, La1/t;->l:I

    .line 2
    .line 3
    return v0
.end method

.method public c()I
    .locals 2

    .line 1
    iget v0, p0, La1/t;->k:I

    .line 2
    .line 3
    const/4 v1, -0x1

    .line 4
    if-ne v0, v1, :cond_0

    .line 5
    .line 6
    iget-object v0, p0, La1/t;->m:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, Ly0/w;

    .line 9
    .line 10
    invoke-virtual {v0}, Ly0/w;->E()I

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    :cond_0
    return v0
.end method

.method public d(Ljava/lang/String;Lm6/o7;)V
    .locals 3

    .line 1
    const-string v0, "key"

    .line 2
    .line 3
    invoke-static {p1, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, La1/t;->m:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, Ljava/util/LinkedHashMap;

    .line 9
    .line 10
    invoke-virtual {v0, p1, p2}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    check-cast p1, Lm6/o7;

    .line 15
    .line 16
    const/4 v1, 0x1

    .line 17
    if-eqz p1, :cond_1

    .line 18
    .line 19
    iget v2, p0, La1/t;->l:I

    .line 20
    .line 21
    iget-object p1, p1, Lm6/o7;->c:[B

    .line 22
    .line 23
    array-length p1, p1

    .line 24
    if-ge p1, v1, :cond_0

    .line 25
    .line 26
    move p1, v1

    .line 27
    :cond_0
    sub-int/2addr v2, p1

    .line 28
    iput v2, p0, La1/t;->l:I

    .line 29
    .line 30
    :cond_1
    iget p1, p0, La1/t;->l:I

    .line 31
    .line 32
    iget-object p2, p2, Lm6/o7;->c:[B

    .line 33
    .line 34
    array-length p2, p2

    .line 35
    if-ge p2, v1, :cond_2

    .line 36
    .line 37
    move p2, v1

    .line 38
    :cond_2
    add-int/2addr p1, p2

    .line 39
    iput p1, p0, La1/t;->l:I

    .line 40
    .line 41
    invoke-virtual {v0}, Ljava/util/LinkedHashMap;->entrySet()Ljava/util/Set;

    .line 42
    .line 43
    .line 44
    move-result-object p1

    .line 45
    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 46
    .line 47
    .line 48
    move-result-object p1

    .line 49
    :goto_0
    iget p2, p0, La1/t;->l:I

    .line 50
    .line 51
    iget v0, p0, La1/t;->k:I

    .line 52
    .line 53
    if-le p2, v0, :cond_4

    .line 54
    .line 55
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 56
    .line 57
    .line 58
    move-result p2

    .line 59
    if-eqz p2, :cond_4

    .line 60
    .line 61
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 62
    .line 63
    .line 64
    move-result-object p2

    .line 65
    const-string v0, "next(...)"

    .line 66
    .line 67
    invoke-static {p2, v0}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 68
    .line 69
    .line 70
    check-cast p2, Ljava/util/Map$Entry;

    .line 71
    .line 72
    iget v0, p0, La1/t;->l:I

    .line 73
    .line 74
    invoke-interface {p2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 75
    .line 76
    .line 77
    move-result-object p2

    .line 78
    check-cast p2, Lm6/o7;

    .line 79
    .line 80
    iget-object p2, p2, Lm6/o7;->c:[B

    .line 81
    .line 82
    array-length p2, p2

    .line 83
    if-ge p2, v1, :cond_3

    .line 84
    .line 85
    move p2, v1

    .line 86
    :cond_3
    sub-int/2addr v0, p2

    .line 87
    iput v0, p0, La1/t;->l:I

    .line 88
    .line 89
    invoke-interface {p1}, Ljava/util/Iterator;->remove()V

    .line 90
    .line 91
    .line 92
    goto :goto_0

    .line 93
    :cond_4
    iget p1, p0, La1/t;->l:I

    .line 94
    .line 95
    if-gez p1, :cond_5

    .line 96
    .line 97
    const/4 p1, 0x0

    .line 98
    iput p1, p0, La1/t;->l:I

    .line 99
    .line 100
    :cond_5
    return-void
.end method

.method public e(Ljava/lang/String;)Lm6/o7;
    .locals 3

    .line 1
    const-string v0, "key"

    .line 2
    .line 3
    invoke-static {p1, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, La1/t;->m:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, Ljava/util/LinkedHashMap;

    .line 9
    .line 10
    invoke-virtual {v0, p1}, Ljava/util/AbstractMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    check-cast p1, Lm6/o7;

    .line 15
    .line 16
    if-eqz p1, :cond_2

    .line 17
    .line 18
    iget v0, p0, La1/t;->l:I

    .line 19
    .line 20
    iget-object v1, p1, Lm6/o7;->c:[B

    .line 21
    .line 22
    array-length v1, v1

    .line 23
    const/4 v2, 0x1

    .line 24
    if-ge v1, v2, :cond_0

    .line 25
    .line 26
    move v1, v2

    .line 27
    :cond_0
    sub-int/2addr v0, v1

    .line 28
    if-gez v0, :cond_1

    .line 29
    .line 30
    const/4 v0, 0x0

    .line 31
    :cond_1
    iput v0, p0, La1/t;->l:I

    .line 32
    .line 33
    :cond_2
    return-object p1
.end method

.method public f(I)V
    .locals 3

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ge p1, v0, :cond_0

    .line 3
    .line 4
    move p1, v0

    .line 5
    :cond_0
    iget v1, p0, La1/t;->k:I

    .line 6
    .line 7
    if-ne p1, v1, :cond_1

    .line 8
    .line 9
    goto :goto_1

    .line 10
    :cond_1
    iput p1, p0, La1/t;->k:I

    .line 11
    .line 12
    iget-object p1, p0, La1/t;->m:Ljava/lang/Object;

    .line 13
    .line 14
    check-cast p1, Ljava/util/LinkedHashMap;

    .line 15
    .line 16
    invoke-virtual {p1}, Ljava/util/LinkedHashMap;->entrySet()Ljava/util/Set;

    .line 17
    .line 18
    .line 19
    move-result-object p1

    .line 20
    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 21
    .line 22
    .line 23
    move-result-object p1

    .line 24
    :goto_0
    iget v1, p0, La1/t;->l:I

    .line 25
    .line 26
    iget v2, p0, La1/t;->k:I

    .line 27
    .line 28
    if-le v1, v2, :cond_3

    .line 29
    .line 30
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 31
    .line 32
    .line 33
    move-result v1

    .line 34
    if-eqz v1, :cond_3

    .line 35
    .line 36
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 37
    .line 38
    .line 39
    move-result-object v1

    .line 40
    const-string v2, "next(...)"

    .line 41
    .line 42
    invoke-static {v1, v2}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 43
    .line 44
    .line 45
    check-cast v1, Ljava/util/Map$Entry;

    .line 46
    .line 47
    iget v2, p0, La1/t;->l:I

    .line 48
    .line 49
    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 50
    .line 51
    .line 52
    move-result-object v1

    .line 53
    check-cast v1, Lm6/o7;

    .line 54
    .line 55
    iget-object v1, v1, Lm6/o7;->c:[B

    .line 56
    .line 57
    array-length v1, v1

    .line 58
    if-ge v1, v0, :cond_2

    .line 59
    .line 60
    move v1, v0

    .line 61
    :cond_2
    sub-int/2addr v2, v1

    .line 62
    iput v2, p0, La1/t;->l:I

    .line 63
    .line 64
    invoke-interface {p1}, Ljava/util/Iterator;->remove()V

    .line 65
    .line 66
    .line 67
    goto :goto_0

    .line 68
    :cond_3
    iget p1, p0, La1/t;->l:I

    .line 69
    .line 70
    if-gez p1, :cond_4

    .line 71
    .line 72
    const/4 p1, 0x0

    .line 73
    iput p1, p0, La1/t;->l:I

    .line 74
    .line 75
    :cond_4
    :goto_1
    return-void
.end method

.method public r()La1/i;
    .locals 4

    .line 1
    new-instance v0, La1/w;

    .line 2
    .line 3
    iget v1, p0, La1/t;->k:I

    .line 4
    .line 5
    iget v2, p0, La1/t;->l:I

    .line 6
    .line 7
    iget-object v3, p0, La1/t;->m:Ljava/lang/Object;

    .line 8
    .line 9
    check-cast v3, Ll4/c;

    .line 10
    .line 11
    invoke-direct {v0, v1, v2, v3}, La1/w;-><init>(IILl4/c;)V

    .line 12
    .line 13
    .line 14
    return-object v0
.end method
