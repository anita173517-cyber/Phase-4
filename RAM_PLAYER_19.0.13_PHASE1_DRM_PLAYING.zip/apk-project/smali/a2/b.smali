.class public final La2/b;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:I

.field public final b:I

.field public final c:I

.field public final d:I

.field public final e:I

.field public final f:Ljava/io/Serializable;


# direct methods
.method public constructor <init>(IIIII[BI)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput p2, p0, La2/b;->a:I

    .line 3
    iput p3, p0, La2/b;->b:I

    .line 4
    iput p4, p0, La2/b;->c:I

    .line 5
    iput p5, p0, La2/b;->d:I

    .line 6
    iput-object p6, p0, La2/b;->f:Ljava/io/Serializable;

    .line 7
    iput p7, p0, La2/b;->e:I

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;IIIII)V
    .locals 0

    .line 8
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 9
    iput-object p1, p0, La2/b;->f:Ljava/io/Serializable;

    .line 10
    iput p2, p0, La2/b;->b:I

    .line 11
    iput p3, p0, La2/b;->a:I

    .line 12
    iput p4, p0, La2/b;->c:I

    .line 13
    iput p5, p0, La2/b;->d:I

    .line 14
    iput p6, p0, La2/b;->e:I

    return-void
.end method
