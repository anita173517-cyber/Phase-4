.class public final La2/d0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lx2/m;


# instance fields
.field public final k:Ly0/w;


# direct methods
.method public constructor <init>(I)V
    .locals 1

    .line 1
    packed-switch p1, :pswitch_data_0

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    new-instance p1, Ly0/w;

    .line 8
    .line 9
    const/16 v0, 0xa

    .line 10
    .line 11
    invoke-direct {p1, v0}, Ly0/w;-><init>(I)V

    .line 12
    .line 13
    .line 14
    iput-object p1, p0, La2/d0;->k:Ly0/w;

    .line 15
    .line 16
    return-void

    .line 17
    :pswitch_0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 18
    .line 19
    .line 20
    new-instance p1, Ly0/w;

    .line 21
    .line 22
    invoke-direct {p1}, Ly0/w;-><init>()V

    .line 23
    .line 24
    .line 25
    iput-object p1, p0, La2/d0;->k:Ly0/w;

    .line 26
    .line 27
    return-void

    .line 28
    nop

    .line 29
    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_0
    .end packed-switch
.end method


# virtual methods
.method public a(La2/u;Ll4/n;I)Lv0/p0;
    .locals 12

    .line 1
    const/4 v0, 0x0

    .line 2
    const/4 v1, 0x0

    .line 3
    move v2, v0

    .line 4
    :goto_0
    move v3, v0

    .line 5
    :cond_0
    rem-int/lit8 v4, v3, 0xa

    .line 6
    .line 7
    add-int/lit8 v5, v4, 0xa

    .line 8
    .line 9
    iget-object v6, p0, La2/d0;->k:Ly0/w;

    .line 10
    .line 11
    const/16 v7, 0xa

    .line 12
    .line 13
    if-nez v4, :cond_1

    .line 14
    .line 15
    if-eqz v3, :cond_1

    .line 16
    .line 17
    iget-object v8, v6, Ly0/w;->a:[B

    .line 18
    .line 19
    const/16 v9, 0x9

    .line 20
    .line 21
    invoke-static {v8, v7, v8, v0, v9}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 22
    .line 23
    .line 24
    :cond_1
    if-nez v3, :cond_2

    .line 25
    .line 26
    move v8, v7

    .line 27
    goto :goto_1

    .line 28
    :cond_2
    const/4 v8, 0x1

    .line 29
    :goto_1
    :try_start_0
    iget-object v9, v6, Ly0/w;->a:[B

    .line 30
    .line 31
    sub-int v10, v5, v8

    .line 32
    .line 33
    invoke-interface {p1, v9, v10, v8}, La2/u;->D([BII)V
    :try_end_0
    .catch Ljava/io/EOFException; {:try_start_0 .. :try_end_0} :catch_0

    .line 34
    .line 35
    .line 36
    invoke-virtual {v6, v4}, Ly0/w;->N(I)V

    .line 37
    .line 38
    .line 39
    invoke-virtual {v6, v5}, Ly0/w;->M(I)V

    .line 40
    .line 41
    .line 42
    invoke-virtual {v6}, Ly0/w;->a()I

    .line 43
    .line 44
    .line 45
    move-result v5

    .line 46
    const/4 v8, 0x3

    .line 47
    if-lt v5, v8, :cond_8

    .line 48
    .line 49
    invoke-virtual {v6}, Ly0/w;->D()I

    .line 50
    .line 51
    .line 52
    move-result v5

    .line 53
    iget v9, v6, Ly0/w;->b:I

    .line 54
    .line 55
    sub-int/2addr v9, v8

    .line 56
    iput v9, v6, Ly0/w;->b:I

    .line 57
    .line 58
    const v9, 0x494433

    .line 59
    .line 60
    .line 61
    if-ne v5, v9, :cond_5

    .line 62
    .line 63
    invoke-virtual {v6, v8}, Ly0/w;->O(I)V

    .line 64
    .line 65
    .line 66
    invoke-virtual {v6}, Ly0/w;->A()I

    .line 67
    .line 68
    .line 69
    move-result v5

    .line 70
    const/4 v8, 0x2

    .line 71
    if-lt v5, v8, :cond_6

    .line 72
    .line 73
    const/4 v8, 0x4

    .line 74
    if-gt v5, v8, :cond_6

    .line 75
    .line 76
    invoke-virtual {v6, v4}, Ly0/w;->N(I)V

    .line 77
    .line 78
    .line 79
    iget v3, v6, Ly0/w;->b:I

    .line 80
    .line 81
    const/4 v4, 0x6

    .line 82
    invoke-virtual {v6, v4}, Ly0/w;->O(I)V

    .line 83
    .line 84
    .line 85
    invoke-virtual {v6}, Ly0/w;->z()I

    .line 86
    .line 87
    .line 88
    move-result v4

    .line 89
    add-int/lit8 v5, v4, 0xa

    .line 90
    .line 91
    invoke-interface {p1}, La2/u;->getLength()J

    .line 92
    .line 93
    .line 94
    move-result-wide v8

    .line 95
    const-wide/16 v10, -0x1

    .line 96
    .line 97
    cmp-long v8, v8, v10

    .line 98
    .line 99
    if-eqz v8, :cond_3

    .line 100
    .line 101
    invoke-interface {p1}, La2/u;->A()J

    .line 102
    .line 103
    .line 104
    move-result-wide v8

    .line 105
    int-to-long v10, v4

    .line 106
    add-long/2addr v8, v10

    .line 107
    invoke-interface {p1}, La2/u;->getLength()J

    .line 108
    .line 109
    .line 110
    move-result-wide v10

    .line 111
    cmp-long v8, v8, v10

    .line 112
    .line 113
    if-lez v8, :cond_3

    .line 114
    .line 115
    const-string p2, "Skipping ID3 tag with tagLength="

    .line 116
    .line 117
    const-string p3, " greater than input length="

    .line 118
    .line 119
    invoke-static {v5, p2, p3}, Lq3/e;->g(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 120
    .line 121
    .line 122
    move-result-object p2

    .line 123
    invoke-interface {p1}, La2/u;->getLength()J

    .line 124
    .line 125
    .line 126
    move-result-wide v3

    .line 127
    invoke-virtual {p2, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 128
    .line 129
    .line 130
    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 131
    .line 132
    .line 133
    move-result-object p2

    .line 134
    const-string p3, "Id3Peeker"

    .line 135
    .line 136
    invoke-static {p3, p2}, Ly0/a;->l(Ljava/lang/String;Ljava/lang/String;)V

    .line 137
    .line 138
    .line 139
    goto :goto_3

    .line 140
    :cond_3
    if-nez v1, :cond_4

    .line 141
    .line 142
    new-array v1, v5, [B

    .line 143
    .line 144
    iget-object v6, v6, Ly0/w;->a:[B

    .line 145
    .line 146
    invoke-static {v6, v3, v1, v0, v7}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 147
    .line 148
    .line 149
    invoke-interface {p1, v1, v7, v4}, La2/u;->D([BII)V

    .line 150
    .line 151
    .line 152
    new-instance v3, Lo2/h;

    .line 153
    .line 154
    invoke-direct {v3, p2}, Lo2/h;-><init>(Ll4/n;)V

    .line 155
    .line 156
    .line 157
    invoke-virtual {v3, v5, v1}, Lo2/h;->G(I[B)Lv0/p0;

    .line 158
    .line 159
    .line 160
    move-result-object v1

    .line 161
    goto :goto_2

    .line 162
    :cond_4
    invoke-interface {p1, v4}, La2/u;->E(I)V

    .line 163
    .line 164
    .line 165
    :goto_2
    add-int/2addr v2, v5

    .line 166
    goto/16 :goto_0

    .line 167
    .line 168
    :cond_5
    invoke-virtual {v6}, Ly0/w;->i()I

    .line 169
    .line 170
    .line 171
    move-result v4

    .line 172
    invoke-static {v4}, La2/a;->i(I)I

    .line 173
    .line 174
    .line 175
    move-result v4

    .line 176
    const/4 v5, -0x1

    .line 177
    if-eq v4, v5, :cond_6

    .line 178
    .line 179
    goto :goto_3

    .line 180
    :cond_6
    if-nez v3, :cond_7

    .line 181
    .line 182
    const/16 v4, 0x14

    .line 183
    .line 184
    invoke-virtual {v6, v4}, Ly0/w;->c(I)V

    .line 185
    .line 186
    .line 187
    :cond_7
    add-int/lit8 v3, v3, 0x1

    .line 188
    .line 189
    if-le v3, p3, :cond_0

    .line 190
    .line 191
    goto :goto_3

    .line 192
    :cond_8
    new-instance p1, Ljava/lang/IndexOutOfBoundsException;

    .line 193
    .line 194
    new-instance p2, Ljava/lang/StringBuilder;

    .line 195
    .line 196
    const-string p3, "position="

    .line 197
    .line 198
    invoke-direct {p2, p3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 199
    .line 200
    .line 201
    iget p3, v6, Ly0/w;->b:I

    .line 202
    .line 203
    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 204
    .line 205
    .line 206
    const-string p3, ", limit="

    .line 207
    .line 208
    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 209
    .line 210
    .line 211
    iget p3, v6, Ly0/w;->c:I

    .line 212
    .line 213
    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 214
    .line 215
    .line 216
    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 217
    .line 218
    .line 219
    move-result-object p2

    .line 220
    invoke-direct {p1, p2}, Ljava/lang/IndexOutOfBoundsException;-><init>(Ljava/lang/String;)V

    .line 221
    .line 222
    .line 223
    throw p1

    .line 224
    :catch_0
    :goto_3
    invoke-interface {p1}, La2/u;->p()V

    .line 225
    .line 226
    .line 227
    invoke-interface {p1, v2}, La2/u;->E(I)V

    .line 228
    .line 229
    .line 230
    return-object v1
.end method

.method public synthetic c([BII)Lx2/d;
    .locals 0

    .line 1
    invoke-static {p0, p1, p3}, Lq3/e;->a(Lx2/m;[BI)Lx2/b;

    move-result-object p1

    return-object p1
.end method

.method public d([BIILx2/l;Ly0/i;)V
    .locals 16

    .line 1
    move/from16 v0, p2

    .line 2
    .line 3
    add-int v1, v0, p3

    .line 4
    .line 5
    move-object/from16 v2, p0

    .line 6
    .line 7
    iget-object v3, v2, La2/d0;->k:Ly0/w;

    .line 8
    .line 9
    move-object/from16 v4, p1

    .line 10
    .line 11
    invoke-virtual {v3, v1, v4}, Ly0/w;->L(I[B)V

    .line 12
    .line 13
    .line 14
    invoke-virtual {v3, v0}, Ly0/w;->N(I)V

    .line 15
    .line 16
    .line 17
    new-instance v9, Ljava/util/ArrayList;

    .line 18
    .line 19
    invoke-direct {v9}, Ljava/util/ArrayList;-><init>()V

    .line 20
    .line 21
    .line 22
    :goto_0
    invoke-virtual {v3}, Ly0/w;->a()I

    .line 23
    .line 24
    .line 25
    move-result v0

    .line 26
    if-lez v0, :cond_8

    .line 27
    .line 28
    invoke-virtual {v3}, Ly0/w;->a()I

    .line 29
    .line 30
    .line 31
    move-result v0

    .line 32
    const/4 v1, 0x0

    .line 33
    const/4 v4, 0x1

    .line 34
    const/16 v5, 0x8

    .line 35
    .line 36
    if-lt v0, v5, :cond_0

    .line 37
    .line 38
    move v0, v4

    .line 39
    goto :goto_1

    .line 40
    :cond_0
    move v0, v1

    .line 41
    :goto_1
    const-string v6, "Incomplete Mp4Webvtt Top Level box header found."

    .line 42
    .line 43
    invoke-static {v6, v0}, Landroid/support/v4/media/session/b;->f(Ljava/lang/String;Z)V

    .line 44
    .line 45
    .line 46
    invoke-virtual {v3}, Ly0/w;->m()I

    .line 47
    .line 48
    .line 49
    move-result v0

    .line 50
    invoke-virtual {v3}, Ly0/w;->m()I

    .line 51
    .line 52
    .line 53
    move-result v6

    .line 54
    const v7, 0x76747463

    .line 55
    .line 56
    .line 57
    if-ne v6, v7, :cond_7

    .line 58
    .line 59
    add-int/lit8 v0, v0, -0x8

    .line 60
    .line 61
    const/4 v6, 0x0

    .line 62
    move-object v7, v6

    .line 63
    move-object v8, v7

    .line 64
    :cond_1
    :goto_2
    if-lez v0, :cond_4

    .line 65
    .line 66
    if-lt v0, v5, :cond_2

    .line 67
    .line 68
    move v10, v4

    .line 69
    goto :goto_3

    .line 70
    :cond_2
    move v10, v1

    .line 71
    :goto_3
    const-string v11, "Incomplete vtt cue box header found."

    .line 72
    .line 73
    invoke-static {v11, v10}, Landroid/support/v4/media/session/b;->f(Ljava/lang/String;Z)V

    .line 74
    .line 75
    .line 76
    invoke-virtual {v3}, Ly0/w;->m()I

    .line 77
    .line 78
    .line 79
    move-result v10

    .line 80
    invoke-virtual {v3}, Ly0/w;->m()I

    .line 81
    .line 82
    .line 83
    move-result v11

    .line 84
    add-int/lit8 v0, v0, -0x8

    .line 85
    .line 86
    sub-int/2addr v10, v5

    .line 87
    iget-object v12, v3, Ly0/w;->a:[B

    .line 88
    .line 89
    iget v13, v3, Ly0/w;->b:I

    .line 90
    .line 91
    sget-object v14, Ly0/k0;->a:Ljava/lang/String;

    .line 92
    .line 93
    new-instance v14, Ljava/lang/String;

    .line 94
    .line 95
    sget-object v15, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    .line 96
    .line 97
    invoke-direct {v14, v12, v13, v10, v15}, Ljava/lang/String;-><init>([BIILjava/nio/charset/Charset;)V

    .line 98
    .line 99
    .line 100
    invoke-virtual {v3, v10}, Ly0/w;->O(I)V

    .line 101
    .line 102
    .line 103
    sub-int/2addr v0, v10

    .line 104
    const v10, 0x73747467

    .line 105
    .line 106
    .line 107
    if-ne v11, v10, :cond_3

    .line 108
    .line 109
    new-instance v8, Lg3/g;

    .line 110
    .line 111
    invoke-direct {v8}, Lg3/g;-><init>()V

    .line 112
    .line 113
    .line 114
    invoke-static {v14, v8}, Lg3/h;->e(Ljava/lang/String;Lg3/g;)V

    .line 115
    .line 116
    .line 117
    invoke-virtual {v8}, Lg3/g;->a()Lx0/a;

    .line 118
    .line 119
    .line 120
    move-result-object v8

    .line 121
    goto :goto_2

    .line 122
    :cond_3
    const v10, 0x7061796c

    .line 123
    .line 124
    .line 125
    if-ne v11, v10, :cond_1

    .line 126
    .line 127
    invoke-virtual {v14}, Ljava/lang/String;->trim()Ljava/lang/String;

    .line 128
    .line 129
    .line 130
    move-result-object v7

    .line 131
    sget-object v10, Ljava/util/Collections;->EMPTY_LIST:Ljava/util/List;

    .line 132
    .line 133
    invoke-static {v6, v7, v10}, Lg3/h;->f(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)Landroid/text/SpannedString;

    .line 134
    .line 135
    .line 136
    move-result-object v7

    .line 137
    goto :goto_2

    .line 138
    :cond_4
    if-nez v7, :cond_5

    .line 139
    .line 140
    const-string v7, ""

    .line 141
    .line 142
    :cond_5
    if-eqz v8, :cond_6

    .line 143
    .line 144
    iput-object v7, v8, Lx0/a;->a:Ljava/lang/CharSequence;

    .line 145
    .line 146
    iput-object v6, v8, Lx0/a;->b:Landroid/graphics/Bitmap;

    .line 147
    .line 148
    invoke-virtual {v8}, Lx0/a;->a()Lx0/b;

    .line 149
    .line 150
    .line 151
    move-result-object v0

    .line 152
    goto :goto_4

    .line 153
    :cond_6
    sget-object v0, Lg3/h;->a:Ljava/util/regex/Pattern;

    .line 154
    .line 155
    new-instance v0, Lg3/g;

    .line 156
    .line 157
    invoke-direct {v0}, Lg3/g;-><init>()V

    .line 158
    .line 159
    .line 160
    iput-object v7, v0, Lg3/g;->c:Ljava/lang/CharSequence;

    .line 161
    .line 162
    invoke-virtual {v0}, Lg3/g;->a()Lx0/a;

    .line 163
    .line 164
    .line 165
    move-result-object v0

    .line 166
    invoke-virtual {v0}, Lx0/a;->a()Lx0/b;

    .line 167
    .line 168
    .line 169
    move-result-object v0

    .line 170
    :goto_4
    invoke-virtual {v9, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 171
    .line 172
    .line 173
    goto/16 :goto_0

    .line 174
    .line 175
    :cond_7
    add-int/lit8 v0, v0, -0x8

    .line 176
    .line 177
    invoke-virtual {v3, v0}, Ly0/w;->O(I)V

    .line 178
    .line 179
    .line 180
    goto/16 :goto_0

    .line 181
    .line 182
    :cond_8
    new-instance v4, Lx2/a;

    .line 183
    .line 184
    const-wide v5, -0x7fffffffffffffffL    # -4.9E-324

    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    const-wide v7, -0x7fffffffffffffffL    # -4.9E-324

    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    invoke-direct/range {v4 .. v9}, Lx2/a;-><init>(JJLjava/util/List;)V

    .line 195
    .line 196
    .line 197
    move-object/from16 v0, p5

    .line 198
    .line 199
    invoke-interface {v0, v4}, Ly0/i;->accept(Ljava/lang/Object;)V

    .line 200
    .line 201
    .line 202
    return-void
.end method

.method public e()I
    .locals 1

    .line 1
    const/4 v0, 0x2

    .line 2
    return v0
.end method

.method public synthetic reset()V
    .locals 0

    .line 1
    return-void
.end method
