.class public interface abstract La2/j;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract i(J)J
.end method
