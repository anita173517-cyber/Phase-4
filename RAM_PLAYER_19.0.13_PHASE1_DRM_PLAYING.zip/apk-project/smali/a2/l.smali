.class public interface abstract La2/l;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract b(La2/u;J)La2/k;
.end method

.method public abstract c()V
.end method
