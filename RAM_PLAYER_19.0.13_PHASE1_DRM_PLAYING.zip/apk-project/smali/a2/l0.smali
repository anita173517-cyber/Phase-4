.class public interface abstract La2/l0;
.super Ljava/lang/Object;
.source "SourceFile"
