.class public final La2/q;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La2/w;


# static fields
.field public static final q:[I

.field public static final r:Ll4/e;

.field public static final s:Ll4/e;


# instance fields
.field public k:Lr5/v1;

.field public l:Z

.field public m:Lx1/b;

.field public n:I

.field public o:I

.field public p:I


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/16 v0, 0x15

    new-array v0, v0, [I

    fill-array-data v0, :array_0

    sput-object v0, La2/q;->q:[I

    new-instance v0, Ll4/e;

    new-instance v1, La2/p;

    const/4 v2, 0x0

    invoke-direct {v1, v2}, La2/p;-><init>(I)V

    invoke-direct {v0, v1}, Ll4/e;-><init>(La2/p;)V

    sput-object v0, La2/q;->r:Ll4/e;

    new-instance v0, Ll4/e;

    new-instance v1, La2/p;

    const/4 v2, 0x1

    invoke-direct {v1, v2}, La2/p;-><init>(I)V

    invoke-direct {v0, v1}, Ll4/e;-><init>(La2/p;)V

    sput-object v0, La2/q;->s:Ll4/e;

    return-void

    :array_0
    .array-data 4
        0x5
        0x4
        0xc
        0x8
        0x3
        0xa
        0x9
        0xb
        0x6
        0x2
        0x0
        0x1
        0x7
        0x10
        0xf
        0xe
        0x11
        0x12
        0x13
        0x14
        0x15
    .end array-data
.end method

.method public constructor <init>()V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Lx1/b;

    const/4 v1, 0x3

    invoke-direct {v0, v1}, Lx1/b;-><init>(I)V

    iput-object v0, p0, La2/q;->m:Lx1/b;

    const/4 v0, 0x1

    iput-boolean v0, p0, La2/q;->l:Z

    const/4 v0, 0x3

    iput v0, p0, La2/q;->n:I

    return-void
.end method


# virtual methods
.method public final a(ILjava/util/ArrayList;)V
    .locals 10

    const/4 v0, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    packed-switch p1, :pswitch_data_0

    :pswitch_0
    goto :goto_0

    :pswitch_1
    new-instance p1, Ld2/a;

    invoke-direct {p1, v2}, Ld2/a;-><init>(I)V

    invoke-virtual {p2, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void

    :pswitch_2
    new-instance p1, Lh2/b;

    iget v0, p0, La2/q;->p:I

    invoke-direct {p1, v0, v2}, Lh2/b;-><init>(II)V

    invoke-virtual {p2, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void

    :pswitch_3
    new-instance p1, Le2/a;

    invoke-direct {p1, v2}, Le2/a;-><init>(I)V

    invoke-virtual {p2, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void

    :pswitch_4
    new-instance p1, Ld2/a;

    invoke-direct {p1, v1}, Ld2/a;-><init>(I)V

    invoke-virtual {p2, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void

    :pswitch_5
    new-instance p1, Le2/a;

    invoke-direct {p1, v1}, Le2/a;-><init>(I)V

    invoke-virtual {p2, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void

    :pswitch_6
    new-instance p1, Lc2/b;

    iget-boolean v0, p0, La2/q;->l:Z

    xor-int/2addr v0, v1

    iget-object v1, p0, La2/q;->m:Lx1/b;

    invoke-direct {p1, v0, v1}, Lc2/b;-><init>(ILx1/b;)V

    invoke-virtual {p2, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void

    :pswitch_7
    sget-object p1, La2/q;->s:Ll4/e;

    new-array v0, v2, [Ljava/lang/Object;

    invoke-virtual {p1, v0}, Ll4/e;->i([Ljava/lang/Object;)La2/t;

    move-result-object p1

    if-eqz p1, :cond_0

    invoke-virtual {p2, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_0
    :goto_0
    return-void

    :pswitch_8
    new-instance p1, Lh2/b;

    iget v0, p0, La2/q;->o:I

    invoke-direct {p1, v0, v1}, Lh2/b;-><init>(II)V

    invoke-virtual {p2, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void

    :pswitch_9
    new-instance p1, Li3/c;

    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    iput v2, p1, Li3/c;->c:I

    const-wide/16 v0, -0x1

    iput-wide v0, p1, Li3/c;->d:J

    const/4 v2, -0x1

    iput v2, p1, Li3/c;->f:I

    iput-wide v0, p1, Li3/c;->g:J

    invoke-virtual {p2, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void

    :pswitch_a
    iget-object p1, p0, La2/q;->k:Lr5/v1;

    if-nez p1, :cond_1

    sget-object p1, Lr5/l0;->l:Lr5/j0;

    sget-object p1, Lr5/v1;->o:Lr5/v1;

    iput-object p1, p0, La2/q;->k:Lr5/v1;

    :cond_1
    new-instance v3, Lh3/d0;

    iget-boolean p1, p0, La2/q;->l:Z

    xor-int/lit8 v5, p1, 0x1

    iget-object v6, p0, La2/q;->m:Lx1/b;

    new-instance v7, Ly0/j0;

    const-wide/16 v0, 0x0

    invoke-direct {v7, v0, v1}, Ly0/j0;-><init>(J)V

    new-instance v8, Lb0/i;

    iget-object p1, p0, La2/q;->k:Lr5/v1;

    const/4 v0, 0x3

    invoke-static {p0, v2}, Lcom/harindra/iptvpro/ultra/Ultra;->progressiveTsFlags(La2/q;I)I

    move-result v1

    invoke-direct {v8, v1, p1, v0}, Lb0/i;-><init>(ILjava/lang/Object;I)V

    const/4 v4, 0x1

    invoke-static {p0, v4}, Lcom/harindra/iptvpro/ultra/Ultra;->progressiveTsMode(La2/q;I)I

    move-result v4

    invoke-direct/range {v3 .. v8}, Lh3/d0;-><init>(IILx2/k;Ly0/j0;Lb0/i;)V

    invoke-virtual {p2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void

    :pswitch_b
    new-instance p1, Lh3/z;

    invoke-direct {p1}, Lh3/z;-><init>()V

    invoke-virtual {p2, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void

    :pswitch_c
    new-instance p1, Lv2/d;

    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    invoke-virtual {p2, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void

    :pswitch_d
    new-instance v3, Lu2/k;

    iget-object v4, p0, La2/q;->m:Lx1/b;

    iget p1, p0, La2/q;->n:I

    invoke-static {p1}, Lu2/k;->g(I)I

    move-result p1

    const/16 v1, 0x200

    or-int/2addr p1, v1

    iget-boolean v1, p0, La2/q;->l:Z

    const/16 v9, 0x20

    if-eqz v1, :cond_2

    move v1, v2

    goto :goto_1

    :cond_2
    move v1, v9

    :goto_1
    or-int v5, p1, v1

    sget-object p1, Lr5/l0;->l:Lr5/j0;

    sget-object v7, Lr5/v1;->o:Lr5/v1;

    const/4 v8, 0x0

    const/4 v6, 0x0

    invoke-direct/range {v3 .. v8}, Lu2/k;-><init>(Lx2/k;ILy0/j0;Ljava/util/List;Lg1/n;)V

    invoke-virtual {p2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-instance p1, Lu2/o;

    iget-object v1, p0, La2/q;->m:Lx1/b;

    iget v3, p0, La2/q;->n:I

    and-int/lit8 v4, v3, 0x1

    if-eqz v4, :cond_3

    goto :goto_2

    :cond_3
    move v9, v2

    :goto_2
    and-int/2addr v0, v3

    if-eqz v0, :cond_4

    or-int/lit16 v9, v9, 0x80

    :cond_4
    iget-boolean v0, p0, La2/q;->l:Z

    if-eqz v0, :cond_5

    goto :goto_3

    :cond_5
    const/16 v2, 0x10

    :goto_3
    or-int v0, v9, v2

    invoke-direct {p1, v1, v0}, Lu2/o;-><init>(Lx2/k;I)V

    invoke-virtual {p2, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void

    :pswitch_e
    new-instance p1, Lt2/d;

    invoke-direct {p1, v2}, Lt2/d;-><init>(I)V

    invoke-virtual {p2, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void

    :pswitch_f
    new-instance p1, Ls2/g;

    iget-object v1, p0, La2/q;->m:Lx1/b;

    iget-boolean v3, p0, La2/q;->l:Z

    if-eqz v3, :cond_6

    move v0, v2

    :cond_6
    invoke-direct {p1, v1, v0}, Ls2/g;-><init>(Lx2/k;I)V

    invoke-virtual {p2, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void

    :pswitch_10
    new-instance p1, Lg2/b;

    invoke-direct {p1}, Lg2/b;-><init>()V

    invoke-virtual {p2, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void

    :pswitch_11
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    new-array v0, v1, [Ljava/lang/Object;

    aput-object p1, v0, v2

    sget-object p1, La2/q;->r:Ll4/e;

    invoke-virtual {p1, v0}, Ll4/e;->i([Ljava/lang/Object;)La2/t;

    move-result-object p1

    if-eqz p1, :cond_7

    invoke-virtual {p2, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void

    :cond_7
    new-instance p1, Lf2/b;

    invoke-direct {p1}, Lf2/b;-><init>()V

    invoke-virtual {p2, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void

    :pswitch_12
    new-instance p1, Lb2/a;

    invoke-direct {p1}, Lb2/a;-><init>()V

    invoke-virtual {p2, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void

    :pswitch_13
    new-instance p1, Lh3/d;

    invoke-direct {p1, v2}, Lh3/d;-><init>(I)V

    invoke-virtual {p2, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void

    :pswitch_14
    new-instance p1, Lh3/c;

    invoke-direct {p1}, Lh3/c;-><init>()V

    invoke-virtual {p2, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void

    :pswitch_15
    new-instance p1, Lh3/a;

    invoke-direct {p1}, Lh3/a;-><init>()V

    invoke-virtual {p2, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_0
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
    .end packed-switch
.end method

.method public final declared-synchronized g(Landroid/net/Uri;Ljava/util/Map;)[La2/t;
    .locals 6

    monitor-enter p0

    :try_start_0
    new-instance v0, Ljava/util/ArrayList;

    sget-object v1, La2/q;->q:[I

    const/16 v2, 0x15

    invoke-direct {v0, v2}, Ljava/util/ArrayList;-><init>(I)V

    const-string v3, "Content-Type"

    invoke-interface {p2, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Ljava/util/List;

    const/4 v3, 0x0

    if-eqz p2, :cond_1

    invoke-interface {p2}, Ljava/util/List;->isEmpty()Z

    move-result v4

    if-eqz v4, :cond_0

    goto :goto_0

    :cond_0
    invoke-interface {p2, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Ljava/lang/String;

    goto :goto_1

    :cond_1
    :goto_0
    const/4 p2, 0x0

    :goto_1
    invoke-static {p2}, Lc4/b0;->r(Ljava/lang/String;)I

    move-result p2

    const/4 v4, -0x1

    if-eq p2, v4, :cond_2

    invoke-virtual {p0, p2, v0}, La2/q;->a(ILjava/util/ArrayList;)V

    goto :goto_2

    :catchall_0
    move-exception p1

    goto :goto_4

    :cond_2
    :goto_2
    invoke-static {p1}, Lc4/b0;->s(Landroid/net/Uri;)I

    move-result p1

    if-eq p1, v4, :cond_3

    if-eq p1, p2, :cond_3

    invoke-virtual {p0, p1, v0}, La2/q;->a(ILjava/util/ArrayList;)V

    :cond_3
    move v4, v3

    :goto_3
    if-ge v4, v2, :cond_5

    aget v5, v1, v4

    if-eq v5, p2, :cond_4

    if-eq v5, p1, :cond_4

    invoke-virtual {p0, v5, v0}, La2/q;->a(ILjava/util/ArrayList;)V

    :cond_4
    add-int/lit8 v4, v4, 0x1

    goto :goto_3

    :cond_5
    new-array p1, v3, [La2/t;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object p1

    check-cast p1, [La2/t;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    return-object p1

    :goto_4
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p1
.end method
