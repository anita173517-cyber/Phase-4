.class public final La2/s;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Ljava/lang/String;

.field public final b:I

.field public final c:I

.field public final d:I

.field public final e:J


# direct methods
.method public constructor <init>(Ljava/lang/String;IIIJ)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, La2/s;->a:Ljava/lang/String;

    .line 5
    .line 6
    iput p2, p0, La2/s;->c:I

    .line 7
    .line 8
    iput p3, p0, La2/s;->b:I

    .line 9
    .line 10
    iput p4, p0, La2/s;->d:I

    .line 11
    .line 12
    iput-wide p5, p0, La2/s;->e:J

    .line 13
    .line 14
    return-void
.end method
