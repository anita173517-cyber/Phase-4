.class public final La2/x;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:J
