.class public abstract Landroidx/lifecycle/i0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/lifecycle/o0;


# static fields
.field public static final k:La2/h;

.field public static final l:La2/h;

.field public static final m:La2/h;

.field public static final n:La2/h;


# direct methods
.method static synthetic constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, La2/h;

    .line 2
    .line 3
    const/4 v1, 0x4

    .line 4
    invoke-direct {v0, v1}, La2/h;-><init>(I)V

    .line 5
    .line 6
    .line 7
    sput-object v0, Landroidx/lifecycle/i0;->k:La2/h;

    .line 8
    .line 9
    new-instance v0, La2/h;

    .line 10
    .line 11
    const/4 v1, 0x5

    .line 12
    invoke-direct {v0, v1}, La2/h;-><init>(I)V

    .line 13
    .line 14
    .line 15
    sput-object v0, Landroidx/lifecycle/i0;->l:La2/h;

    .line 16
    .line 17
    new-instance v0, La2/h;

    .line 18
    .line 19
    const/4 v1, 0x3

    .line 20
    invoke-direct {v0, v1}, La2/h;-><init>(I)V

    .line 21
    .line 22
    .line 23
    sput-object v0, Landroidx/lifecycle/i0;->m:La2/h;

    .line 24
    .line 25
    new-instance v0, La2/h;

    .line 26
    .line 27
    const/4 v1, 0x7

    .line 28
    invoke-direct {v0, v1}, La2/h;-><init>(I)V

    .line 29
    .line 30
    .line 31
    sput-object v0, Landroidx/lifecycle/i0;->n:La2/h;

    .line 32
    .line 33
    return-void
.end method

.method public static final a(Landroidx/lifecycle/r;)Landroidx/lifecycle/m;
    .locals 4

    .line 1
    const-string v0, "<this>"

    .line 2
    .line 3
    invoke-static {p0, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-interface {p0}, Landroidx/lifecycle/r;->c()Landroidx/lifecycle/t;

    .line 7
    .line 8
    .line 9
    move-result-object p0

    .line 10
    invoke-static {p0, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    iget-object v0, p0, Landroidx/lifecycle/t;->a:Ljava/util/concurrent/atomic/AtomicReference;

    .line 14
    .line 15
    :goto_0
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object v1

    .line 19
    check-cast v1, Landroidx/lifecycle/m;

    .line 20
    .line 21
    if-eqz v1, :cond_0

    .line 22
    .line 23
    return-object v1

    .line 24
    :cond_0
    new-instance v1, Landroidx/lifecycle/m;

    .line 25
    .line 26
    new-instance v2, Lf7/h1;

    .line 27
    .line 28
    invoke-direct {v2}, Lf7/v0;-><init>()V

    .line 29
    .line 30
    .line 31
    sget-object v3, Lf7/b0;->a:Lm7/e;

    .line 32
    .line 33
    sget-object v3, Lk7/o;->a:Lg7/d;

    .line 34
    .line 35
    iget-object v3, v3, Lg7/d;->o:Lg7/d;

    .line 36
    .line 37
    invoke-static {v2, v3}, Lcom/bumptech/glide/d;->A(Lr6/g;Lr6/i;)Lr6/i;

    .line 38
    .line 39
    .line 40
    move-result-object v2

    .line 41
    invoke-direct {v1, p0, v2}, Landroidx/lifecycle/m;-><init>(Landroidx/lifecycle/t;Lr6/i;)V

    .line 42
    .line 43
    .line 44
    :cond_1
    const/4 v2, 0x0

    .line 45
    invoke-virtual {v0, v2, v1}, Ljava/util/concurrent/atomic/AtomicReference;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 46
    .line 47
    .line 48
    move-result v3

    .line 49
    if-eqz v3, :cond_2

    .line 50
    .line 51
    sget-object p0, Lf7/b0;->a:Lm7/e;

    .line 52
    .line 53
    sget-object p0, Lk7/o;->a:Lg7/d;

    .line 54
    .line 55
    iget-object p0, p0, Lg7/d;->o:Lg7/d;

    .line 56
    .line 57
    new-instance v0, Landroidx/lifecycle/l;

    .line 58
    .line 59
    const/4 v3, 0x0

    .line 60
    invoke-direct {v0, v1, v2, v3}, Landroidx/lifecycle/l;-><init>(Ljava/lang/Object;Lr6/d;I)V

    .line 61
    .line 62
    .line 63
    const/4 v2, 0x2

    .line 64
    invoke-static {v1, p0, v0, v2}, Lf7/v;->j(Lf7/s;Lr6/i;Lz6/p;I)Lf7/g1;

    .line 65
    .line 66
    .line 67
    return-object v1

    .line 68
    :cond_2
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 69
    .line 70
    .line 71
    move-result-object v2

    .line 72
    if-eqz v2, :cond_1

    .line 73
    .line 74
    goto :goto_0
.end method
