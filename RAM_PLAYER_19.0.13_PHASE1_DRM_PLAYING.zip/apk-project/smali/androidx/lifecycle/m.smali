.class public final Landroidx/lifecycle/m;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/lifecycle/p;
.implements Lf7/s;


# instance fields
.field public final k:Landroidx/lifecycle/t;

.field public final l:Lr6/i;


# direct methods
.method public constructor <init>(Landroidx/lifecycle/t;Lr6/i;)V
    .locals 1

    .line 1
    const-string v0, "coroutineContext"

    .line 2
    .line 3
    invoke-static {p2, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object p1, p0, Landroidx/lifecycle/m;->k:Landroidx/lifecycle/t;

    .line 10
    .line 11
    iput-object p2, p0, Landroidx/lifecycle/m;->l:Lr6/i;

    .line 12
    .line 13
    iget-object p1, p1, Landroidx/lifecycle/t;->d:Landroidx/lifecycle/k;

    .line 14
    .line 15
    sget-object v0, Landroidx/lifecycle/k;->k:Landroidx/lifecycle/k;

    .line 16
    .line 17
    if-ne p1, v0, :cond_0

    .line 18
    .line 19
    sget-object p1, Lf7/r;->l:Lf7/r;

    .line 20
    .line 21
    invoke-interface {p2, p1}, Lr6/i;->e(Lr6/h;)Lr6/g;

    .line 22
    .line 23
    .line 24
    move-result-object p1

    .line 25
    check-cast p1, Lf7/s0;

    .line 26
    .line 27
    if-eqz p1, :cond_0

    .line 28
    .line 29
    const/4 p2, 0x0

    .line 30
    invoke-interface {p1, p2}, Lf7/s0;->c(Ljava/util/concurrent/CancellationException;)V

    .line 31
    .line 32
    .line 33
    :cond_0
    return-void
.end method


# virtual methods
.method public final a(Landroidx/lifecycle/r;Landroidx/lifecycle/j;)V
    .locals 1

    .line 1
    iget-object p1, p0, Landroidx/lifecycle/m;->k:Landroidx/lifecycle/t;

    .line 2
    .line 3
    iget-object p2, p1, Landroidx/lifecycle/t;->d:Landroidx/lifecycle/k;

    .line 4
    .line 5
    sget-object v0, Landroidx/lifecycle/k;->k:Landroidx/lifecycle/k;

    .line 6
    .line 7
    invoke-virtual {p2, v0}, Ljava/lang/Enum;->compareTo(Ljava/lang/Enum;)I

    .line 8
    .line 9
    .line 10
    move-result p2

    .line 11
    if-gtz p2, :cond_0

    .line 12
    .line 13
    invoke-virtual {p1, p0}, Landroidx/lifecycle/t;->f(Landroidx/lifecycle/q;)V

    .line 14
    .line 15
    .line 16
    sget-object p1, Lf7/r;->l:Lf7/r;

    .line 17
    .line 18
    iget-object p2, p0, Landroidx/lifecycle/m;->l:Lr6/i;

    .line 19
    .line 20
    invoke-interface {p2, p1}, Lr6/i;->e(Lr6/h;)Lr6/g;

    .line 21
    .line 22
    .line 23
    move-result-object p1

    .line 24
    check-cast p1, Lf7/s0;

    .line 25
    .line 26
    if-eqz p1, :cond_0

    .line 27
    .line 28
    const/4 p2, 0x0

    .line 29
    invoke-interface {p1, p2}, Lf7/s0;->c(Ljava/util/concurrent/CancellationException;)V

    .line 30
    .line 31
    .line 32
    :cond_0
    return-void
.end method

.method public final g()Lr6/i;
    .locals 1

    .line 1
    iget-object v0, p0, Landroidx/lifecycle/m;->l:Lr6/i;

    .line 2
    .line 3
    return-object v0
.end method
