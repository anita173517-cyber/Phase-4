.class public final Landroidx/media3/exoplayer/hls/HlsMediaSource$Factory;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lr1/a0;


# instance fields
.field public final a:Landroidx/lifecycle/c0;

.field public b:Lj1/c;

.field public c:Lx1/b;

.field public d:Z

.field public e:I

.field public final f:Li1/n;

.field public final g:Le1/f;

.field public final h:Lp1/h0;

.field public final i:Ll4/t;

.field public final j:Lp1/h0;

.field public k:Z

.field public final l:I

.field public final m:J


# direct methods
.method public constructor <init>(La1/h;)V
    .locals 2

    .line 1
    new-instance v0, Landroidx/lifecycle/c0;

    .line 2
    .line 3
    const/16 v1, 0x16

    .line 4
    .line 5
    invoke-direct {v0, v1, p1}, Landroidx/lifecycle/c0;-><init>(ILjava/lang/Object;)V

    .line 6
    .line 7
    .line 8
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 9
    .line 10
    .line 11
    iput-object v0, p0, Landroidx/media3/exoplayer/hls/HlsMediaSource$Factory;->a:Landroidx/lifecycle/c0;

    .line 12
    .line 13
    new-instance p1, Ll4/t;

    .line 14
    .line 15
    const/16 v0, 0xb

    .line 16
    .line 17
    invoke-direct {p1, v0}, Ll4/t;-><init>(I)V

    .line 18
    .line 19
    .line 20
    iput-object p1, p0, Landroidx/media3/exoplayer/hls/HlsMediaSource$Factory;->i:Ll4/t;

    .line 21
    .line 22
    new-instance p1, Li1/n;

    .line 23
    .line 24
    const/4 v0, 0x4

    .line 25
    invoke-direct {p1, v0}, Li1/n;-><init>(I)V

    .line 26
    .line 27
    .line 28
    iput-object p1, p0, Landroidx/media3/exoplayer/hls/HlsMediaSource$Factory;->f:Li1/n;

    .line 29
    .line 30
    sget-object p1, Lk1/d;->G:Le1/f;

    .line 31
    .line 32
    iput-object p1, p0, Landroidx/media3/exoplayer/hls/HlsMediaSource$Factory;->g:Le1/f;

    .line 33
    .line 34
    new-instance p1, Lp1/h0;

    .line 35
    .line 36
    const/16 v0, 0x14

    .line 37
    .line 38
    invoke-direct {p1, v0}, Lp1/h0;-><init>(I)V

    .line 39
    .line 40
    .line 41
    iput-object p1, p0, Landroidx/media3/exoplayer/hls/HlsMediaSource$Factory;->j:Lp1/h0;

    .line 42
    .line 43
    new-instance p1, Lp1/h0;

    .line 44
    .line 45
    const/16 v0, 0xa

    .line 46
    .line 47
    invoke-direct {p1, v0}, Lp1/h0;-><init>(I)V

    .line 48
    .line 49
    .line 50
    iput-object p1, p0, Landroidx/media3/exoplayer/hls/HlsMediaSource$Factory;->h:Lp1/h0;

    .line 51
    .line 52
    const/4 p1, 0x1

    .line 53
    iput p1, p0, Landroidx/media3/exoplayer/hls/HlsMediaSource$Factory;->l:I

    .line 54
    .line 55
    const-wide v0, -0x7fffffffffffffffL    # -4.9E-324

    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    iput-wide v0, p0, Landroidx/media3/exoplayer/hls/HlsMediaSource$Factory;->m:J

    .line 61
    .line 62
    iput-boolean p1, p0, Landroidx/media3/exoplayer/hls/HlsMediaSource$Factory;->k:Z

    .line 63
    .line 64
    const/4 v0, 0x3

    .line 65
    iput v0, p0, Landroidx/media3/exoplayer/hls/HlsMediaSource$Factory;->e:I

    .line 66
    .line 67
    iput-boolean p1, p0, Landroidx/media3/exoplayer/hls/HlsMediaSource$Factory;->d:Z

    .line 68
    .line 69
    return-void
.end method


# virtual methods
.method public final a(Z)Lr1/a0;
    .locals 0

    .line 1
    iput-boolean p1, p0, Landroidx/media3/exoplayer/hls/HlsMediaSource$Factory;->d:Z

    .line 2
    .line 3
    return-object p0
.end method

.method public final b(Lx1/b;)Lr1/a0;
    .locals 0

    .line 1
    iput-object p1, p0, Landroidx/media3/exoplayer/hls/HlsMediaSource$Factory;->c:Lx1/b;

    .line 2
    .line 3
    return-object p0
.end method

.method public final bridge synthetic c(Lv0/k0;)Lr1/a;
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, Landroidx/media3/exoplayer/hls/HlsMediaSource$Factory;->e(Lv0/k0;)Lj1/m;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    return-object p1
.end method

.method public final d(I)Lr1/a0;
    .locals 0

    .line 1
    iput p1, p0, Landroidx/media3/exoplayer/hls/HlsMediaSource$Factory;->e:I

    .line 2
    .line 3
    return-object p0
.end method

.method public final e(Lv0/k0;)Lj1/m;
    .locals 14

    .line 1
    iget-object v0, p1, Lv0/k0;->b:Lv0/f0;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Landroidx/media3/exoplayer/hls/HlsMediaSource$Factory;->b:Lj1/c;

    .line 7
    .line 8
    if-nez v0, :cond_0

    .line 9
    .line 10
    new-instance v0, Lj1/c;

    .line 11
    .line 12
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 13
    .line 14
    .line 15
    new-instance v1, Lx1/b;

    .line 16
    .line 17
    const/4 v2, 0x3

    .line 18
    invoke-direct {v1, v2}, Lx1/b;-><init>(I)V

    .line 19
    .line 20
    .line 21
    iput-object v1, v0, Lj1/c;->a:Lx1/b;

    .line 22
    .line 23
    const/4 v1, 0x3

    .line 24
    iput v1, v0, Lj1/c;->c:I

    .line 25
    .line 26
    iput-object v0, p0, Landroidx/media3/exoplayer/hls/HlsMediaSource$Factory;->b:Lj1/c;

    .line 27
    .line 28
    :cond_0
    iget-object v0, p0, Landroidx/media3/exoplayer/hls/HlsMediaSource$Factory;->c:Lx1/b;

    .line 29
    .line 30
    if-eqz v0, :cond_1

    .line 31
    .line 32
    iget-object v1, p0, Landroidx/media3/exoplayer/hls/HlsMediaSource$Factory;->b:Lj1/c;

    .line 33
    .line 34
    iput-object v0, v1, Lj1/c;->a:Lx1/b;

    .line 35
    .line 36
    :cond_1
    iget-object v5, p0, Landroidx/media3/exoplayer/hls/HlsMediaSource$Factory;->b:Lj1/c;

    .line 37
    .line 38
    iget-boolean v0, p0, Landroidx/media3/exoplayer/hls/HlsMediaSource$Factory;->d:Z

    .line 39
    .line 40
    iput-boolean v0, v5, Lj1/c;->b:Z

    .line 41
    .line 42
    iget v0, p0, Landroidx/media3/exoplayer/hls/HlsMediaSource$Factory;->e:I

    .line 43
    .line 44
    iput v0, v5, Lj1/c;->c:I

    .line 45
    .line 46
    iget-object v0, p1, Lv0/k0;->b:Lv0/f0;

    .line 47
    .line 48
    iget-object v0, v0, Lv0/f0;->e:Ljava/util/List;

    .line 49
    .line 50
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    .line 51
    .line 52
    .line 53
    move-result v1

    .line 54
    iget-object v2, p0, Landroidx/media3/exoplayer/hls/HlsMediaSource$Factory;->f:Li1/n;

    .line 55
    .line 56
    if-nez v1, :cond_2

    .line 57
    .line 58
    new-instance v1, Ll4/l;

    .line 59
    .line 60
    invoke-direct {v1, v2, v0}, Ll4/l;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 61
    .line 62
    .line 63
    move-object v2, v1

    .line 64
    :cond_2
    new-instance v0, Lj1/m;

    .line 65
    .line 66
    iget-object v1, p0, Landroidx/media3/exoplayer/hls/HlsMediaSource$Factory;->i:Ll4/t;

    .line 67
    .line 68
    invoke-virtual {v1, p1}, Ll4/t;->u(Lv0/k0;)Li1/p;

    .line 69
    .line 70
    .line 71
    move-result-object v7

    .line 72
    iget-object v1, p0, Landroidx/media3/exoplayer/hls/HlsMediaSource$Factory;->g:Le1/f;

    .line 73
    .line 74
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 75
    .line 76
    .line 77
    new-instance v9, Lk1/d;

    .line 78
    .line 79
    iget-object v4, p0, Landroidx/media3/exoplayer/hls/HlsMediaSource$Factory;->a:Landroidx/lifecycle/c0;

    .line 80
    .line 81
    iget-object v8, p0, Landroidx/media3/exoplayer/hls/HlsMediaSource$Factory;->j:Lp1/h0;

    .line 82
    .line 83
    invoke-direct {v9, v4, v8, v2}, Lk1/d;-><init>(Landroidx/lifecycle/c0;Lp1/h0;Lk1/t;)V

    .line 84
    .line 85
    .line 86
    iget-boolean v12, p0, Landroidx/media3/exoplayer/hls/HlsMediaSource$Factory;->k:Z

    .line 87
    .line 88
    iget v13, p0, Landroidx/media3/exoplayer/hls/HlsMediaSource$Factory;->l:I

    .line 89
    .line 90
    iget-object v6, p0, Landroidx/media3/exoplayer/hls/HlsMediaSource$Factory;->h:Lp1/h0;

    .line 91
    .line 92
    iget-wide v10, p0, Landroidx/media3/exoplayer/hls/HlsMediaSource$Factory;->m:J

    .line 93
    .line 94
    move-object v3, p1

    .line 95
    move-object v2, v0

    .line 96
    invoke-direct/range {v2 .. v13}, Lj1/m;-><init>(Lv0/k0;Landroidx/lifecycle/c0;Lj1/c;Lp1/h0;Li1/p;Lp1/h0;Lk1/d;JZI)V

    .line 97
    .line 98
    .line 99
    return-object v2
.end method
