.class public abstract Landroidx/work/CoroutineWorker;
.super Lc4/p;
.source "SourceFile"


# instance fields
.field public final o:Lf7/v0;

.field public final p:Ln4/k;

.field public final q:Lm7/e;


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroidx/work/WorkerParameters;)V
    .locals 2

    .line 1
    const-string v0, "appContext"

    .line 2
    .line 3
    invoke-static {p1, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "params"

    .line 7
    .line 8
    invoke-static {p2, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    invoke-direct {p0, p1, p2}, Lc4/p;-><init>(Landroid/content/Context;Landroidx/work/WorkerParameters;)V

    .line 12
    .line 13
    .line 14
    new-instance p1, Lf7/v0;

    .line 15
    .line 16
    invoke-direct {p1}, Lf7/v0;-><init>()V

    .line 17
    .line 18
    .line 19
    iput-object p1, p0, Landroidx/work/CoroutineWorker;->o:Lf7/v0;

    .line 20
    .line 21
    new-instance p1, Ln4/k;

    .line 22
    .line 23
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 24
    .line 25
    .line 26
    iput-object p1, p0, Landroidx/work/CoroutineWorker;->p:Ln4/k;

    .line 27
    .line 28
    new-instance v0, Landroidx/lifecycle/z;

    .line 29
    .line 30
    const/4 v1, 0x4

    .line 31
    invoke-direct {v0, v1, p0}, Landroidx/lifecycle/z;-><init>(ILjava/lang/Object;)V

    .line 32
    .line 33
    .line 34
    iget-object p2, p2, Landroidx/work/WorkerParameters;->e:Ll4/i;

    .line 35
    .line 36
    iget-object p2, p2, Ll4/i;->k:Ljava/lang/Object;

    .line 37
    .line 38
    check-cast p2, Li/p;

    .line 39
    .line 40
    invoke-virtual {p1, v0, p2}, Ln4/i;->a(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V

    .line 41
    .line 42
    .line 43
    sget-object p1, Lf7/b0;->a:Lm7/e;

    .line 44
    .line 45
    iput-object p1, p0, Landroidx/work/CoroutineWorker;->q:Lm7/e;

    .line 46
    .line 47
    return-void
.end method


# virtual methods
.method public final a()Lcom/google/common/util/concurrent/r;
    .locals 5

    .line 1
    new-instance v0, Lf7/v0;

    .line 2
    .line 3
    invoke-direct {v0}, Lf7/v0;-><init>()V

    .line 4
    .line 5
    .line 6
    iget-object v1, p0, Landroidx/work/CoroutineWorker;->q:Lm7/e;

    .line 7
    .line 8
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 9
    .line 10
    .line 11
    invoke-static {v1, v0}, Lcom/bumptech/glide/d;->A(Lr6/g;Lr6/i;)Lr6/i;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    invoke-static {v1}, Lf7/v;->a(Lr6/i;)Lk7/e;

    .line 16
    .line 17
    .line 18
    move-result-object v1

    .line 19
    new-instance v2, Lc4/k;

    .line 20
    .line 21
    invoke-direct {v2, v0}, Lc4/k;-><init>(Lf7/v0;)V

    .line 22
    .line 23
    .line 24
    new-instance v0, Lc4/d;

    .line 25
    .line 26
    const/4 v3, 0x0

    .line 27
    const/4 v4, 0x0

    .line 28
    invoke-direct {v0, v2, p0, v4, v3}, Lc4/d;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lr6/d;I)V

    .line 29
    .line 30
    .line 31
    const/4 v3, 0x3

    .line 32
    invoke-static {v1, v4, v0, v3}, Lf7/v;->j(Lf7/s;Lr6/i;Lz6/p;I)Lf7/g1;

    .line 33
    .line 34
    .line 35
    return-object v2
.end method

.method public final b()V
    .locals 2

    .line 1
    iget-object v0, p0, Landroidx/work/CoroutineWorker;->p:Ln4/k;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-virtual {v0, v1}, Ln4/i;->cancel(Z)Z

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method public final c()Ln4/k;
    .locals 4

    .line 1
    iget-object v0, p0, Landroidx/work/CoroutineWorker;->q:Lm7/e;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    iget-object v1, p0, Landroidx/work/CoroutineWorker;->o:Lf7/v0;

    .line 7
    .line 8
    invoke-static {v0, v1}, Lcom/bumptech/glide/d;->A(Lr6/g;Lr6/i;)Lr6/i;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    invoke-static {v0}, Lf7/v;->a(Lr6/i;)Lk7/e;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    new-instance v1, Lm6/o5;

    .line 17
    .line 18
    const/4 v2, 0x3

    .line 19
    const/4 v3, 0x0

    .line 20
    invoke-direct {v1, p0, v3, v2}, Lm6/o5;-><init>(Ljava/lang/Object;Lr6/d;I)V

    .line 21
    .line 22
    .line 23
    invoke-static {v0, v3, v1, v2}, Lf7/v;->j(Lf7/s;Lr6/i;Lz6/p;I)Lf7/g1;

    .line 24
    .line 25
    .line 26
    iget-object v0, p0, Landroidx/work/CoroutineWorker;->p:Ln4/k;

    .line 27
    .line 28
    return-object v0
.end method

.method public abstract f(Lt6/c;)Ljava/lang/Object;
.end method
