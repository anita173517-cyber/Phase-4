.class public final synthetic Lb0/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/Comparator;


# instance fields
.field public final synthetic k:I


# direct methods
.method public synthetic constructor <init>(I)V
    .locals 0

    .line 1
    iput p1, p0, Lb0/a;->k:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final compare(Ljava/lang/Object;Ljava/lang/Object;)I
    .locals 6

    .line 1
    iget v0, p0, Lb0/a;->k:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    check-cast p1, Ly2/d;

    .line 7
    .line 8
    check-cast p2, Ly2/d;

    .line 9
    .line 10
    iget p2, p2, Ly2/d;->b:I

    .line 11
    .line 12
    iget p1, p1, Ly2/d;->b:I

    .line 13
    .line 14
    invoke-static {p2, p1}, Ljava/lang/Integer;->compare(II)I

    .line 15
    .line 16
    .line 17
    move-result p1

    .line 18
    return p1

    .line 19
    :pswitch_0
    check-cast p1, Lv1/q;

    .line 20
    .line 21
    check-cast p2, Lv1/q;

    .line 22
    .line 23
    iget p1, p1, Lv1/q;->c:F

    .line 24
    .line 25
    iget p2, p2, Lv1/q;->c:F

    .line 26
    .line 27
    invoke-static {p1, p2}, Ljava/lang/Float;->compare(FF)I

    .line 28
    .line 29
    .line 30
    move-result p1

    .line 31
    return p1

    .line 32
    :pswitch_1
    check-cast p1, Lv1/q;

    .line 33
    .line 34
    check-cast p2, Lv1/q;

    .line 35
    .line 36
    iget p1, p1, Lv1/q;->a:I

    .line 37
    .line 38
    iget p2, p2, Lv1/q;->a:I

    .line 39
    .line 40
    sub-int/2addr p1, p2

    .line 41
    return p1

    .line 42
    :pswitch_2
    check-cast p1, Lu1/o;

    .line 43
    .line 44
    check-cast p2, Lu1/o;

    .line 45
    .line 46
    iget-boolean v0, p1, Lu1/o;->o:Z

    .line 47
    .line 48
    iget v1, p1, Lu1/o;->t:I

    .line 49
    .line 50
    if-eqz v0, :cond_0

    .line 51
    .line 52
    iget-boolean v0, p1, Lu1/o;->r:Z

    .line 53
    .line 54
    if-eqz v0, :cond_0

    .line 55
    .line 56
    sget-object v0, Lu1/p;->u:Lr5/t1;

    .line 57
    .line 58
    goto :goto_0

    .line 59
    :cond_0
    sget-object v0, Lu1/p;->u:Lr5/t1;

    .line 60
    .line 61
    invoke-virtual {v0}, Lr5/t1;->a()Lr5/t1;

    .line 62
    .line 63
    .line 64
    move-result-object v0

    .line 65
    :goto_0
    iget-object v2, p1, Lu1/o;->p:Lu1/k;

    .line 66
    .line 67
    iget-boolean v2, v2, Lv0/p1;->F:Z

    .line 68
    .line 69
    sget-object v3, Lr5/a0;->a:Lr5/y;

    .line 70
    .line 71
    if-eqz v2, :cond_1

    .line 72
    .line 73
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 74
    .line 75
    .line 76
    move-result-object v2

    .line 77
    iget v4, p2, Lu1/o;->t:I

    .line 78
    .line 79
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 80
    .line 81
    .line 82
    move-result-object v4

    .line 83
    sget-object v5, Lu1/p;->u:Lr5/t1;

    .line 84
    .line 85
    invoke-virtual {v5}, Lr5/t1;->a()Lr5/t1;

    .line 86
    .line 87
    .line 88
    move-result-object v5

    .line 89
    invoke-virtual {v3, v2, v4, v5}, Lr5/y;->b(Ljava/lang/Object;Ljava/lang/Object;Ljava/util/Comparator;)Lr5/a0;

    .line 90
    .line 91
    .line 92
    move-result-object v3

    .line 93
    :cond_1
    iget-boolean v2, p1, Lu1/o;->I:Z

    .line 94
    .line 95
    iget-boolean v4, p2, Lu1/o;->I:Z

    .line 96
    .line 97
    invoke-virtual {v3, v2, v4}, Lr5/a0;->c(ZZ)Lr5/a0;

    .line 98
    .line 99
    .line 100
    move-result-object v2

    .line 101
    iget v3, p1, Lu1/o;->u:I

    .line 102
    .line 103
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 104
    .line 105
    .line 106
    move-result-object v3

    .line 107
    iget v4, p2, Lu1/o;->u:I

    .line 108
    .line 109
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 110
    .line 111
    .line 112
    move-result-object v4

    .line 113
    invoke-virtual {v2, v3, v4, v0}, Lr5/a0;->b(Ljava/lang/Object;Ljava/lang/Object;Ljava/util/Comparator;)Lr5/a0;

    .line 114
    .line 115
    .line 116
    move-result-object v2

    .line 117
    iget-boolean v3, p1, Lu1/o;->E:Z

    .line 118
    .line 119
    if-eqz v3, :cond_2

    .line 120
    .line 121
    iget-boolean v3, p1, Lu1/o;->G:Z

    .line 122
    .line 123
    if-eqz v3, :cond_2

    .line 124
    .line 125
    iget v3, p1, Lu1/o;->H:I

    .line 126
    .line 127
    iget v4, p2, Lu1/o;->H:I

    .line 128
    .line 129
    invoke-virtual {v2, v3, v4}, Lr5/a0;->a(II)Lr5/a0;

    .line 130
    .line 131
    .line 132
    move-result-object v2

    .line 133
    :cond_2
    iget-boolean p1, p1, Lu1/o;->F:Z

    .line 134
    .line 135
    iget-boolean v3, p2, Lu1/o;->F:Z

    .line 136
    .line 137
    invoke-virtual {v2, p1, v3}, Lr5/a0;->c(ZZ)Lr5/a0;

    .line 138
    .line 139
    .line 140
    move-result-object p1

    .line 141
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 142
    .line 143
    .line 144
    move-result-object v1

    .line 145
    iget p2, p2, Lu1/o;->t:I

    .line 146
    .line 147
    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 148
    .line 149
    .line 150
    move-result-object p2

    .line 151
    invoke-virtual {p1, v1, p2, v0}, Lr5/a0;->b(Ljava/lang/Object;Ljava/lang/Object;Ljava/util/Comparator;)Lr5/a0;

    .line 152
    .line 153
    .line 154
    move-result-object p1

    .line 155
    invoke-virtual {p1}, Lr5/a0;->e()I

    .line 156
    .line 157
    .line 158
    move-result p1

    .line 159
    return p1

    .line 160
    :pswitch_3
    check-cast p1, Lu1/o;

    .line 161
    .line 162
    check-cast p2, Lu1/o;

    .line 163
    .line 164
    invoke-static {p1, p2}, Lu1/o;->c(Lu1/o;Lu1/o;)I

    .line 165
    .line 166
    .line 167
    move-result p1

    .line 168
    return p1

    .line 169
    :pswitch_4
    check-cast p1, Ljava/util/List;

    .line 170
    .line 171
    check-cast p2, Ljava/util/List;

    .line 172
    .line 173
    const/4 v0, 0x0

    .line 174
    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 175
    .line 176
    .line 177
    move-result-object p1

    .line 178
    check-cast p1, Lu1/l;

    .line 179
    .line 180
    invoke-interface {p2, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 181
    .line 182
    .line 183
    move-result-object p2

    .line 184
    check-cast p2, Lu1/l;

    .line 185
    .line 186
    invoke-virtual {p1, p2}, Lu1/l;->c(Lu1/l;)I

    .line 187
    .line 188
    .line 189
    move-result p1

    .line 190
    return p1

    .line 191
    :pswitch_5
    check-cast p1, Ljava/util/List;

    .line 192
    .line 193
    check-cast p2, Ljava/util/List;

    .line 194
    .line 195
    invoke-static {p1}, Ljava/util/Collections;->max(Ljava/util/Collection;)Ljava/lang/Object;

    .line 196
    .line 197
    .line 198
    move-result-object p1

    .line 199
    check-cast p1, Lu1/g;

    .line 200
    .line 201
    invoke-static {p2}, Ljava/util/Collections;->max(Ljava/util/Collection;)Ljava/lang/Object;

    .line 202
    .line 203
    .line 204
    move-result-object p2

    .line 205
    check-cast p2, Lu1/g;

    .line 206
    .line 207
    invoke-virtual {p1, p2}, Lu1/g;->c(Lu1/g;)I

    .line 208
    .line 209
    .line 210
    move-result p1

    .line 211
    return p1

    .line 212
    :pswitch_6
    check-cast p1, Ljava/util/List;

    .line 213
    .line 214
    check-cast p2, Ljava/util/List;

    .line 215
    .line 216
    new-instance v0, Lb0/a;

    .line 217
    .line 218
    const/16 v1, 0xf

    .line 219
    .line 220
    invoke-direct {v0, v1}, Lb0/a;-><init>(I)V

    .line 221
    .line 222
    .line 223
    invoke-static {p1, v0}, Ljava/util/Collections;->max(Ljava/util/Collection;Ljava/util/Comparator;)Ljava/lang/Object;

    .line 224
    .line 225
    .line 226
    move-result-object v0

    .line 227
    check-cast v0, Lu1/o;

    .line 228
    .line 229
    new-instance v1, Lb0/a;

    .line 230
    .line 231
    const/16 v2, 0xf

    .line 232
    .line 233
    invoke-direct {v1, v2}, Lb0/a;-><init>(I)V

    .line 234
    .line 235
    .line 236
    invoke-static {p2, v1}, Ljava/util/Collections;->max(Ljava/util/Collection;Ljava/util/Comparator;)Ljava/lang/Object;

    .line 237
    .line 238
    .line 239
    move-result-object v1

    .line 240
    check-cast v1, Lu1/o;

    .line 241
    .line 242
    invoke-static {v0, v1}, Lu1/o;->c(Lu1/o;Lu1/o;)I

    .line 243
    .line 244
    .line 245
    move-result v0

    .line 246
    invoke-static {v0}, Lr5/y;->f(I)Lr5/a0;

    .line 247
    .line 248
    .line 249
    move-result-object v0

    .line 250
    invoke-interface {p1}, Ljava/util/List;->size()I

    .line 251
    .line 252
    .line 253
    move-result v1

    .line 254
    invoke-interface {p2}, Ljava/util/List;->size()I

    .line 255
    .line 256
    .line 257
    move-result v2

    .line 258
    invoke-virtual {v0, v1, v2}, Lr5/a0;->a(II)Lr5/a0;

    .line 259
    .line 260
    .line 261
    move-result-object v0

    .line 262
    new-instance v1, Lb0/a;

    .line 263
    .line 264
    const/16 v2, 0x10

    .line 265
    .line 266
    invoke-direct {v1, v2}, Lb0/a;-><init>(I)V

    .line 267
    .line 268
    .line 269
    invoke-static {p1, v1}, Ljava/util/Collections;->max(Ljava/util/Collection;Ljava/util/Comparator;)Ljava/lang/Object;

    .line 270
    .line 271
    .line 272
    move-result-object p1

    .line 273
    check-cast p1, Lu1/o;

    .line 274
    .line 275
    new-instance v1, Lb0/a;

    .line 276
    .line 277
    invoke-direct {v1, v2}, Lb0/a;-><init>(I)V

    .line 278
    .line 279
    .line 280
    invoke-static {p2, v1}, Ljava/util/Collections;->max(Ljava/util/Collection;Ljava/util/Comparator;)Ljava/lang/Object;

    .line 281
    .line 282
    .line 283
    move-result-object p2

    .line 284
    check-cast p2, Lu1/o;

    .line 285
    .line 286
    new-instance v1, Lb0/a;

    .line 287
    .line 288
    invoke-direct {v1, v2}, Lb0/a;-><init>(I)V

    .line 289
    .line 290
    .line 291
    invoke-virtual {v0, p1, p2, v1}, Lr5/a0;->b(Ljava/lang/Object;Ljava/lang/Object;Ljava/util/Comparator;)Lr5/a0;

    .line 292
    .line 293
    .line 294
    move-result-object p1

    .line 295
    invoke-virtual {p1}, Lr5/a0;->e()I

    .line 296
    .line 297
    .line 298
    move-result p1

    .line 299
    return p1

    .line 300
    :pswitch_7
    check-cast p1, Ljava/util/List;

    .line 301
    .line 302
    check-cast p2, Ljava/util/List;

    .line 303
    .line 304
    const/4 v0, 0x0

    .line 305
    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 306
    .line 307
    .line 308
    move-result-object p1

    .line 309
    check-cast p1, Lu1/h;

    .line 310
    .line 311
    invoke-interface {p2, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 312
    .line 313
    .line 314
    move-result-object p2

    .line 315
    check-cast p2, Lu1/h;

    .line 316
    .line 317
    iget p1, p1, Lu1/h;->p:I

    .line 318
    .line 319
    iget p2, p2, Lu1/h;->p:I

    .line 320
    .line 321
    invoke-static {p1, p2}, Ljava/lang/Integer;->compare(II)I

    .line 322
    .line 323
    .line 324
    move-result p1

    .line 325
    return p1

    .line 326
    :pswitch_8
    check-cast p1, Ljava/lang/Integer;

    .line 327
    .line 328
    check-cast p2, Ljava/lang/Integer;

    .line 329
    .line 330
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 331
    .line 332
    .line 333
    move-result v0

    .line 334
    const/4 v1, -0x1

    .line 335
    if-ne v0, v1, :cond_3

    .line 336
    .line 337
    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    .line 338
    .line 339
    .line 340
    move-result p1

    .line 341
    if-ne p1, v1, :cond_5

    .line 342
    .line 343
    const/4 v1, 0x0

    .line 344
    goto :goto_1

    .line 345
    :cond_3
    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    .line 346
    .line 347
    .line 348
    move-result v0

    .line 349
    if-ne v0, v1, :cond_4

    .line 350
    .line 351
    const/4 v1, 0x1

    .line 352
    goto :goto_1

    .line 353
    :cond_4
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 354
    .line 355
    .line 356
    move-result p1

    .line 357
    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    .line 358
    .line 359
    .line 360
    move-result p2

    .line 361
    sub-int v1, p1, p2

    .line 362
    .line 363
    :cond_5
    :goto_1
    return v1

    .line 364
    :pswitch_9
    check-cast p1, Lv0/t;

    .line 365
    .line 366
    check-cast p2, Lv0/t;

    .line 367
    .line 368
    iget p2, p2, Lv0/t;->k:I

    .line 369
    .line 370
    iget p1, p1, Lv0/t;->k:I

    .line 371
    .line 372
    invoke-static {p2, p1}, Ljava/lang/Integer;->compare(II)I

    .line 373
    .line 374
    .line 375
    move-result p1

    .line 376
    return p1

    .line 377
    :pswitch_a
    check-cast p1, Lp1/i;

    .line 378
    .line 379
    check-cast p2, Lp1/i;

    .line 380
    .line 381
    iget-object p1, p1, Lp1/i;->a:Lp1/h;

    .line 382
    .line 383
    iget p1, p1, Lp1/h;->c:I

    .line 384
    .line 385
    iget-object p2, p2, Lp1/i;->a:Lp1/h;

    .line 386
    .line 387
    iget p2, p2, Lp1/h;->c:I

    .line 388
    .line 389
    invoke-static {p1, p2}, Lp1/j;->b(II)I

    .line 390
    .line 391
    .line 392
    move-result p1

    .line 393
    return p1

    .line 394
    :pswitch_b
    check-cast p1, Lm3/g0;

    .line 395
    .line 396
    check-cast p2, Lm3/g0;

    .line 397
    .line 398
    iget v0, p2, Lm3/g0;->a:I

    .line 399
    .line 400
    iget v1, p1, Lm3/g0;->a:I

    .line 401
    .line 402
    invoke-static {v0, v1}, Ljava/lang/Integer;->compare(II)I

    .line 403
    .line 404
    .line 405
    move-result v0

    .line 406
    if-eqz v0, :cond_6

    .line 407
    .line 408
    goto :goto_2

    .line 409
    :cond_6
    iget-object v0, p2, Lm3/g0;->c:Ljava/lang/String;

    .line 410
    .line 411
    iget-object v1, p1, Lm3/g0;->c:Ljava/lang/String;

    .line 412
    .line 413
    invoke-virtual {v0, v1}, Ljava/lang/String;->compareTo(Ljava/lang/String;)I

    .line 414
    .line 415
    .line 416
    move-result v0

    .line 417
    if-eqz v0, :cond_7

    .line 418
    .line 419
    goto :goto_2

    .line 420
    :cond_7
    iget-object p2, p2, Lm3/g0;->d:Ljava/lang/String;

    .line 421
    .line 422
    iget-object p1, p1, Lm3/g0;->d:Ljava/lang/String;

    .line 423
    .line 424
    invoke-virtual {p2, p1}, Ljava/lang/String;->compareTo(Ljava/lang/String;)I

    .line 425
    .line 426
    .line 427
    move-result v0

    .line 428
    :goto_2
    return v0

    .line 429
    :pswitch_c
    check-cast p1, Lm3/g0;

    .line 430
    .line 431
    check-cast p2, Lm3/g0;

    .line 432
    .line 433
    iget v0, p2, Lm3/g0;->b:I

    .line 434
    .line 435
    iget v1, p1, Lm3/g0;->b:I

    .line 436
    .line 437
    invoke-static {v0, v1}, Ljava/lang/Integer;->compare(II)I

    .line 438
    .line 439
    .line 440
    move-result v0

    .line 441
    if-eqz v0, :cond_8

    .line 442
    .line 443
    goto :goto_3

    .line 444
    :cond_8
    iget-object v0, p1, Lm3/g0;->c:Ljava/lang/String;

    .line 445
    .line 446
    iget-object v1, p2, Lm3/g0;->c:Ljava/lang/String;

    .line 447
    .line 448
    invoke-virtual {v0, v1}, Ljava/lang/String;->compareTo(Ljava/lang/String;)I

    .line 449
    .line 450
    .line 451
    move-result v0

    .line 452
    if-eqz v0, :cond_9

    .line 453
    .line 454
    goto :goto_3

    .line 455
    :cond_9
    iget-object p1, p1, Lm3/g0;->d:Ljava/lang/String;

    .line 456
    .line 457
    iget-object p2, p2, Lm3/g0;->d:Ljava/lang/String;

    .line 458
    .line 459
    invoke-virtual {p1, p2}, Ljava/lang/String;->compareTo(Ljava/lang/String;)I

    .line 460
    .line 461
    .line 462
    move-result v0

    .line 463
    :goto_3
    return v0

    .line 464
    :pswitch_d
    check-cast p1, Lk1/e;

    .line 465
    .line 466
    check-cast p2, Lk1/e;

    .line 467
    .line 468
    iget-object p1, p1, Lk1/e;->a:Ljava/lang/String;

    .line 469
    .line 470
    iget-object p2, p2, Lk1/e;->a:Ljava/lang/String;

    .line 471
    .line 472
    invoke-virtual {p1, p2}, Ljava/lang/String;->compareTo(Ljava/lang/String;)I

    .line 473
    .line 474
    .line 475
    move-result p1

    .line 476
    return p1

    .line 477
    :pswitch_e
    check-cast p1, Lg3/c;

    .line 478
    .line 479
    check-cast p2, Lg3/c;

    .line 480
    .line 481
    iget-wide v0, p1, Lg3/c;->b:J

    .line 482
    .line 483
    iget-wide p1, p2, Lg3/c;->b:J

    .line 484
    .line 485
    invoke-static {v0, v1, p1, p2}, Ljava/lang/Long;->compare(JJ)I

    .line 486
    .line 487
    .line 488
    move-result p1

    .line 489
    return p1

    .line 490
    :pswitch_f
    check-cast p1, Lg3/d;

    .line 491
    .line 492
    check-cast p2, Lg3/d;

    .line 493
    .line 494
    iget-object p1, p1, Lg3/d;->a:Lg3/e;

    .line 495
    .line 496
    iget p1, p1, Lg3/e;->b:I

    .line 497
    .line 498
    iget-object p2, p2, Lg3/d;->a:Lg3/e;

    .line 499
    .line 500
    iget p2, p2, Lg3/e;->b:I

    .line 501
    .line 502
    invoke-static {p1, p2}, Ljava/lang/Integer;->compare(II)I

    .line 503
    .line 504
    .line 505
    move-result p1

    .line 506
    return p1

    .line 507
    :pswitch_10
    check-cast p1, Lh1/b;

    .line 508
    .line 509
    check-cast p2, Lh1/b;

    .line 510
    .line 511
    iget v0, p1, Lh1/b;->c:I

    .line 512
    .line 513
    iget v1, p2, Lh1/b;->c:I

    .line 514
    .line 515
    invoke-static {v0, v1}, Ljava/lang/Integer;->compare(II)I

    .line 516
    .line 517
    .line 518
    move-result v0

    .line 519
    if-eqz v0, :cond_a

    .line 520
    .line 521
    goto :goto_4

    .line 522
    :cond_a
    iget-object p1, p1, Lh1/b;->b:Ljava/lang/String;

    .line 523
    .line 524
    iget-object p2, p2, Lh1/b;->b:Ljava/lang/String;

    .line 525
    .line 526
    invoke-virtual {p1, p2}, Ljava/lang/String;->compareTo(Ljava/lang/String;)I

    .line 527
    .line 528
    .line 529
    move-result v0

    .line 530
    :goto_4
    return v0

    .line 531
    :pswitch_11
    check-cast p1, Ljava/lang/Integer;

    .line 532
    .line 533
    check-cast p2, Ljava/lang/Integer;

    .line 534
    .line 535
    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    .line 536
    .line 537
    .line 538
    move-result p2

    .line 539
    invoke-static {p2}, Ljava/lang/Integer;->bitCount(I)I

    .line 540
    .line 541
    .line 542
    move-result p2

    .line 543
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 544
    .line 545
    .line 546
    move-result p1

    .line 547
    invoke-static {p1}, Ljava/lang/Integer;->bitCount(I)I

    .line 548
    .line 549
    .line 550
    move-result p1

    .line 551
    sub-int/2addr p2, p1

    .line 552
    return p2

    .line 553
    :pswitch_12
    check-cast p1, [B

    .line 554
    .line 555
    check-cast p2, [B

    .line 556
    .line 557
    array-length v0, p1

    .line 558
    array-length v1, p2

    .line 559
    if-eq v0, v1, :cond_b

    .line 560
    .line 561
    array-length p1, p1

    .line 562
    array-length p2, p2

    .line 563
    sub-int/2addr p1, p2

    .line 564
    goto :goto_6

    .line 565
    :cond_b
    const/4 v0, 0x0

    .line 566
    move v1, v0

    .line 567
    :goto_5
    array-length v2, p1

    .line 568
    if-ge v1, v2, :cond_d

    .line 569
    .line 570
    aget-byte v2, p1, v1

    .line 571
    .line 572
    aget-byte v3, p2, v1

    .line 573
    .line 574
    if-eq v2, v3, :cond_c

    .line 575
    .line 576
    sub-int p1, v2, v3

    .line 577
    .line 578
    goto :goto_6

    .line 579
    :cond_c
    add-int/lit8 v1, v1, 0x1

    .line 580
    .line 581
    goto :goto_5

    .line 582
    :cond_d
    move p1, v0

    .line 583
    :goto_6
    return p1

    .line 584
    nop

    .line 585
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
