.class public interface abstract Lb5/l;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract h()S
.end method

.method public abstract j()I
.end method

.method public abstract k(I[B)I
.end method

.method public abstract skip(J)J
.end method
