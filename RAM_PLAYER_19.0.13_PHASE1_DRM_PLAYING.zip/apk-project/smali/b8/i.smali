.class public interface abstract Lb8/i;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lb8/v;
.implements Ljava/nio/channels/ReadableByteChannel;


# virtual methods
.method public abstract A()Ljava/io/InputStream;
.end method

.method public abstract h(J)Lb8/j;
.end method

.method public abstract i(J)Z
.end method

.method public abstract l()Ljava/lang/String;
.end method

.method public abstract p()Lb8/g;
.end method

.method public abstract readByte()B
.end method

.method public abstract readInt()I
.end method

.method public abstract readShort()S
.end method

.method public abstract s(J)Ljava/lang/String;
.end method

.method public abstract skip(J)V
.end method

.method public abstract w(J)V
.end method

.method public abstract z()J
.end method
