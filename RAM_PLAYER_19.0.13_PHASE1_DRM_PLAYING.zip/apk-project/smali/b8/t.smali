.class public interface abstract Lb8/t;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/io/Closeable;
.implements Ljava/io/Flushable;


# virtual methods
.method public abstract b()Lb8/x;
.end method

.method public abstract close()V
.end method

.method public abstract flush()V
.end method

.method public abstract q(JLb8/g;)V
.end method
