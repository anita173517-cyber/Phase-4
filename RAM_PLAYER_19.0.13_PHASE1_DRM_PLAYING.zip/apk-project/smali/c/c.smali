.class public final synthetic Lc/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lt3/d;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .locals 0

    .line 1
    iput p1, p0, Lc/c;->a:I

    iput-object p2, p0, Lc/c;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()Landroid/os/Bundle;
    .locals 13

    .line 1
    iget v0, p0, Lc/c;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lc/c;->b:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, Lr0/o;

    .line 9
    .line 10
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 11
    .line 12
    .line 13
    new-instance v1, Landroid/os/Bundle;

    .line 14
    .line 15
    invoke-direct {v1}, Landroid/os/Bundle;-><init>()V

    .line 16
    .line 17
    .line 18
    invoke-virtual {v0}, Lr0/o;->b()Ljava/util/HashSet;

    .line 19
    .line 20
    .line 21
    move-result-object v2

    .line 22
    invoke-virtual {v2}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    .line 23
    .line 24
    .line 25
    move-result-object v2

    .line 26
    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 27
    .line 28
    .line 29
    move-result v3

    .line 30
    if-eqz v3, :cond_0

    .line 31
    .line 32
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 33
    .line 34
    .line 35
    move-result-object v3

    .line 36
    check-cast v3, Lr0/v;

    .line 37
    .line 38
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 39
    .line 40
    .line 41
    goto :goto_0

    .line 42
    :cond_0
    invoke-virtual {v0}, Lr0/o;->b()Ljava/util/HashSet;

    .line 43
    .line 44
    .line 45
    move-result-object v2

    .line 46
    invoke-virtual {v2}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    .line 47
    .line 48
    .line 49
    move-result-object v2

    .line 50
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 51
    .line 52
    .line 53
    move-result v3

    .line 54
    const/4 v4, 0x0

    .line 55
    if-nez v3, :cond_c

    .line 56
    .line 57
    const/4 v2, 0x1

    .line 58
    invoke-virtual {v0, v2}, Lr0/o;->e(Z)Z

    .line 59
    .line 60
    .line 61
    iput-boolean v2, v0, Lr0/o;->y:Z

    .line 62
    .line 63
    iget-object v2, v0, Lr0/o;->E:Lr0/q;

    .line 64
    .line 65
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 66
    .line 67
    .line 68
    iget-object v2, v0, Lr0/o;->c:Ll4/i;

    .line 69
    .line 70
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 71
    .line 72
    .line 73
    new-instance v3, Ljava/util/ArrayList;

    .line 74
    .line 75
    iget-object v2, v2, Ll4/i;->l:Ljava/lang/Object;

    .line 76
    .line 77
    check-cast v2, Ljava/util/HashMap;

    .line 78
    .line 79
    invoke-virtual {v2}, Ljava/util/HashMap;->size()I

    .line 80
    .line 81
    .line 82
    move-result v5

    .line 83
    invoke-direct {v3, v5}, Ljava/util/ArrayList;-><init>(I)V

    .line 84
    .line 85
    .line 86
    invoke-virtual {v2}, Ljava/util/HashMap;->values()Ljava/util/Collection;

    .line 87
    .line 88
    .line 89
    move-result-object v2

    .line 90
    invoke-interface {v2}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    .line 91
    .line 92
    .line 93
    move-result-object v2

    .line 94
    :goto_1
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 95
    .line 96
    .line 97
    move-result v5

    .line 98
    if-eqz v5, :cond_2

    .line 99
    .line 100
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 101
    .line 102
    .line 103
    move-result-object v5

    .line 104
    if-nez v5, :cond_1

    .line 105
    .line 106
    goto :goto_1

    .line 107
    :cond_1
    new-instance v0, Ljava/lang/ClassCastException;

    .line 108
    .line 109
    invoke-direct {v0}, Ljava/lang/ClassCastException;-><init>()V

    .line 110
    .line 111
    .line 112
    throw v0

    .line 113
    :cond_2
    iget-object v2, v0, Lr0/o;->c:Ll4/i;

    .line 114
    .line 115
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 116
    .line 117
    .line 118
    new-instance v5, Ljava/util/ArrayList;

    .line 119
    .line 120
    iget-object v2, v2, Ll4/i;->m:Ljava/lang/Object;

    .line 121
    .line 122
    check-cast v2, Ljava/util/HashMap;

    .line 123
    .line 124
    invoke-virtual {v2}, Ljava/util/HashMap;->values()Ljava/util/Collection;

    .line 125
    .line 126
    .line 127
    move-result-object v2

    .line 128
    invoke-direct {v5, v2}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 129
    .line 130
    .line 131
    invoke-virtual {v5}, Ljava/util/ArrayList;->isEmpty()Z

    .line 132
    .line 133
    .line 134
    move-result v2

    .line 135
    const/4 v6, 0x2

    .line 136
    if-eqz v2, :cond_3

    .line 137
    .line 138
    invoke-static {v6}, Lr0/o;->h(I)Z

    .line 139
    .line 140
    .line 141
    goto/16 :goto_6

    .line 142
    .line 143
    :cond_3
    iget-object v2, v0, Lr0/o;->c:Ll4/i;

    .line 144
    .line 145
    iget-object v7, v2, Ll4/i;->k:Ljava/lang/Object;

    .line 146
    .line 147
    check-cast v7, Ljava/util/ArrayList;

    .line 148
    .line 149
    monitor-enter v7

    .line 150
    :try_start_0
    iget-object v8, v2, Ll4/i;->k:Ljava/lang/Object;

    .line 151
    .line 152
    check-cast v8, Ljava/util/ArrayList;

    .line 153
    .line 154
    invoke-virtual {v8}, Ljava/util/ArrayList;->isEmpty()Z

    .line 155
    .line 156
    .line 157
    move-result v8

    .line 158
    if-eqz v8, :cond_4

    .line 159
    .line 160
    monitor-exit v7

    .line 161
    move-object v8, v4

    .line 162
    goto :goto_2

    .line 163
    :catchall_0
    move-exception v0

    .line 164
    goto/16 :goto_7

    .line 165
    .line 166
    :cond_4
    new-instance v8, Ljava/util/ArrayList;

    .line 167
    .line 168
    iget-object v9, v2, Ll4/i;->k:Ljava/lang/Object;

    .line 169
    .line 170
    check-cast v9, Ljava/util/ArrayList;

    .line 171
    .line 172
    invoke-virtual {v9}, Ljava/util/ArrayList;->size()I

    .line 173
    .line 174
    .line 175
    move-result v9

    .line 176
    invoke-direct {v8, v9}, Ljava/util/ArrayList;-><init>(I)V

    .line 177
    .line 178
    .line 179
    iget-object v2, v2, Ll4/i;->k:Ljava/lang/Object;

    .line 180
    .line 181
    check-cast v2, Ljava/util/ArrayList;

    .line 182
    .line 183
    invoke-virtual {v2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 184
    .line 185
    .line 186
    move-result-object v2

    .line 187
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 188
    .line 189
    .line 190
    move-result v9

    .line 191
    if-nez v9, :cond_a

    .line 192
    .line 193
    monitor-exit v7
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 194
    :goto_2
    iget-object v2, v0, Lr0/o;->d:Ljava/util/ArrayList;

    .line 195
    .line 196
    const/4 v7, 0x0

    .line 197
    if-eqz v2, :cond_6

    .line 198
    .line 199
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    .line 200
    .line 201
    .line 202
    move-result v2

    .line 203
    if-lez v2, :cond_6

    .line 204
    .line 205
    new-array v9, v2, [Lr0/b;

    .line 206
    .line 207
    move v10, v7

    .line 208
    :goto_3
    if-ge v10, v2, :cond_7

    .line 209
    .line 210
    new-instance v11, Lr0/b;

    .line 211
    .line 212
    iget-object v12, v0, Lr0/o;->d:Ljava/util/ArrayList;

    .line 213
    .line 214
    invoke-virtual {v12, v10}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 215
    .line 216
    .line 217
    move-result-object v12

    .line 218
    check-cast v12, Lr0/a;

    .line 219
    .line 220
    invoke-direct {v11, v12}, Lr0/b;-><init>(Lr0/a;)V

    .line 221
    .line 222
    .line 223
    aput-object v11, v9, v10

    .line 224
    .line 225
    invoke-static {v6}, Lr0/o;->h(I)Z

    .line 226
    .line 227
    .line 228
    move-result v11

    .line 229
    if-eqz v11, :cond_5

    .line 230
    .line 231
    iget-object v11, v0, Lr0/o;->d:Ljava/util/ArrayList;

    .line 232
    .line 233
    invoke-virtual {v11, v10}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 234
    .line 235
    .line 236
    move-result-object v11

    .line 237
    invoke-static {v11}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    .line 238
    .line 239
    .line 240
    :cond_5
    add-int/lit8 v10, v10, 0x1

    .line 241
    .line 242
    goto :goto_3

    .line 243
    :cond_6
    move-object v9, v4

    .line 244
    :cond_7
    new-instance v2, Lr0/p;

    .line 245
    .line 246
    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    .line 247
    .line 248
    .line 249
    iput-object v4, v2, Lr0/p;->o:Ljava/lang/String;

    .line 250
    .line 251
    new-instance v4, Ljava/util/ArrayList;

    .line 252
    .line 253
    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    .line 254
    .line 255
    .line 256
    iput-object v4, v2, Lr0/p;->p:Ljava/util/ArrayList;

    .line 257
    .line 258
    new-instance v6, Ljava/util/ArrayList;

    .line 259
    .line 260
    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    .line 261
    .line 262
    .line 263
    iput-object v6, v2, Lr0/p;->q:Ljava/util/ArrayList;

    .line 264
    .line 265
    iput-object v3, v2, Lr0/p;->k:Ljava/util/ArrayList;

    .line 266
    .line 267
    iput-object v8, v2, Lr0/p;->l:Ljava/util/ArrayList;

    .line 268
    .line 269
    iput-object v9, v2, Lr0/p;->m:[Lr0/b;

    .line 270
    .line 271
    iget-object v3, v0, Lr0/o;->h:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 272
    .line 273
    invoke-virtual {v3}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    .line 274
    .line 275
    .line 276
    move-result v3

    .line 277
    iput v3, v2, Lr0/p;->n:I

    .line 278
    .line 279
    iget-object v3, v0, Lr0/o;->i:Ljava/util/Map;

    .line 280
    .line 281
    invoke-interface {v3}, Ljava/util/Map;->keySet()Ljava/util/Set;

    .line 282
    .line 283
    .line 284
    move-result-object v3

    .line 285
    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 286
    .line 287
    .line 288
    iget-object v3, v0, Lr0/o;->i:Ljava/util/Map;

    .line 289
    .line 290
    invoke-interface {v3}, Ljava/util/Map;->values()Ljava/util/Collection;

    .line 291
    .line 292
    .line 293
    move-result-object v3

    .line 294
    invoke-virtual {v6, v3}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 295
    .line 296
    .line 297
    new-instance v3, Ljava/util/ArrayList;

    .line 298
    .line 299
    iget-object v4, v0, Lr0/o;->x:Ljava/util/ArrayDeque;

    .line 300
    .line 301
    invoke-direct {v3, v4}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 302
    .line 303
    .line 304
    iput-object v3, v2, Lr0/p;->r:Ljava/util/ArrayList;

    .line 305
    .line 306
    const-string v3, "state"

    .line 307
    .line 308
    invoke-virtual {v1, v3, v2}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    .line 309
    .line 310
    .line 311
    iget-object v2, v0, Lr0/o;->j:Ljava/util/Map;

    .line 312
    .line 313
    invoke-interface {v2}, Ljava/util/Map;->keySet()Ljava/util/Set;

    .line 314
    .line 315
    .line 316
    move-result-object v2

    .line 317
    invoke-interface {v2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 318
    .line 319
    .line 320
    move-result-object v2

    .line 321
    :goto_4
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 322
    .line 323
    .line 324
    move-result v3

    .line 325
    if-eqz v3, :cond_8

    .line 326
    .line 327
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 328
    .line 329
    .line 330
    move-result-object v3

    .line 331
    check-cast v3, Ljava/lang/String;

    .line 332
    .line 333
    const-string v4, "result_"

    .line 334
    .line 335
    invoke-static {v4, v3}, La0/h;->s(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 336
    .line 337
    .line 338
    move-result-object v4

    .line 339
    iget-object v6, v0, Lr0/o;->j:Ljava/util/Map;

    .line 340
    .line 341
    invoke-interface {v6, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 342
    .line 343
    .line 344
    move-result-object v3

    .line 345
    check-cast v3, Landroid/os/Bundle;

    .line 346
    .line 347
    invoke-virtual {v1, v4, v3}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    .line 348
    .line 349
    .line 350
    goto :goto_4

    .line 351
    :cond_8
    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    .line 352
    .line 353
    .line 354
    move-result v0

    .line 355
    :goto_5
    if-ge v7, v0, :cond_9

    .line 356
    .line 357
    invoke-virtual {v5, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 358
    .line 359
    .line 360
    move-result-object v2

    .line 361
    add-int/lit8 v7, v7, 0x1

    .line 362
    .line 363
    check-cast v2, Lr0/r;

    .line 364
    .line 365
    new-instance v3, Landroid/os/Bundle;

    .line 366
    .line 367
    invoke-direct {v3}, Landroid/os/Bundle;-><init>()V

    .line 368
    .line 369
    .line 370
    const-string v4, "state"

    .line 371
    .line 372
    invoke-virtual {v3, v4, v2}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    .line 373
    .line 374
    .line 375
    new-instance v4, Ljava/lang/StringBuilder;

    .line 376
    .line 377
    const-string v6, "fragment_"

    .line 378
    .line 379
    invoke-direct {v4, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 380
    .line 381
    .line 382
    iget-object v2, v2, Lr0/r;->l:Ljava/lang/String;

    .line 383
    .line 384
    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 385
    .line 386
    .line 387
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 388
    .line 389
    .line 390
    move-result-object v2

    .line 391
    invoke-virtual {v1, v2, v3}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    .line 392
    .line 393
    .line 394
    goto :goto_5

    .line 395
    :cond_9
    :goto_6
    return-object v1

    .line 396
    :cond_a
    :try_start_1
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 397
    .line 398
    .line 399
    move-result-object v0

    .line 400
    if-nez v0, :cond_b

    .line 401
    .line 402
    throw v4

    .line 403
    :cond_b
    new-instance v0, Ljava/lang/ClassCastException;

    .line 404
    .line 405
    invoke-direct {v0}, Ljava/lang/ClassCastException;-><init>()V

    .line 406
    .line 407
    .line 408
    throw v0

    .line 409
    :goto_7
    monitor-exit v7
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 410
    throw v0

    .line 411
    :cond_c
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 412
    .line 413
    .line 414
    move-result-object v0

    .line 415
    check-cast v0, Lr0/v;

    .line 416
    .line 417
    invoke-virtual {v0}, Lr0/v;->a()V

    .line 418
    .line 419
    .line 420
    throw v4

    .line 421
    :pswitch_0
    iget-object v0, p0, Lc/c;->b:Ljava/lang/Object;

    .line 422
    .line 423
    check-cast v0, Li/k;

    .line 424
    .line 425
    iget-object v1, v0, Li/k;->C:Ll6/b;

    .line 426
    .line 427
    iget-object v1, v1, Ll6/b;->k:Ljava/lang/Object;

    .line 428
    .line 429
    check-cast v1, Lr0/f;

    .line 430
    .line 431
    iget-object v1, v1, Lr0/f;->m:Lr0/o;

    .line 432
    .line 433
    iget-object v1, v1, Lr0/o;->c:Ll4/i;

    .line 434
    .line 435
    invoke-virtual {v1}, Ll4/i;->o()Ljava/util/List;

    .line 436
    .line 437
    .line 438
    move-result-object v1

    .line 439
    invoke-interface {v1}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    .line 440
    .line 441
    .line 442
    move-result-object v1

    .line 443
    :goto_8
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 444
    .line 445
    .line 446
    move-result v2

    .line 447
    if-eqz v2, :cond_e

    .line 448
    .line 449
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 450
    .line 451
    .line 452
    move-result-object v2

    .line 453
    if-nez v2, :cond_d

    .line 454
    .line 455
    goto :goto_8

    .line 456
    :cond_d
    new-instance v0, Ljava/lang/ClassCastException;

    .line 457
    .line 458
    invoke-direct {v0}, Ljava/lang/ClassCastException;-><init>()V

    .line 459
    .line 460
    .line 461
    throw v0

    .line 462
    :cond_e
    iget-object v0, v0, Li/k;->D:Landroidx/lifecycle/t;

    .line 463
    .line 464
    sget-object v1, Landroidx/lifecycle/j;->ON_STOP:Landroidx/lifecycle/j;

    .line 465
    .line 466
    invoke-virtual {v0, v1}, Landroidx/lifecycle/t;->d(Landroidx/lifecycle/j;)V

    .line 467
    .line 468
    .line 469
    new-instance v0, Landroid/os/Bundle;

    .line 470
    .line 471
    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    .line 472
    .line 473
    .line 474
    return-object v0

    .line 475
    :pswitch_1
    iget-object v0, p0, Lc/c;->b:Ljava/lang/Object;

    .line 476
    .line 477
    check-cast v0, Li/k;

    .line 478
    .line 479
    new-instance v1, Landroid/os/Bundle;

    .line 480
    .line 481
    invoke-direct {v1}, Landroid/os/Bundle;-><init>()V

    .line 482
    .line 483
    .line 484
    iget-object v0, v0, Lc/k;->u:Lc/f;

    .line 485
    .line 486
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 487
    .line 488
    .line 489
    const-string v2, "KEY_COMPONENT_ACTIVITY_REGISTERED_RCS"

    .line 490
    .line 491
    new-instance v3, Ljava/util/ArrayList;

    .line 492
    .line 493
    iget-object v4, v0, Lc/f;->c:Ljava/util/HashMap;

    .line 494
    .line 495
    invoke-virtual {v4}, Ljava/util/HashMap;->values()Ljava/util/Collection;

    .line 496
    .line 497
    .line 498
    move-result-object v5

    .line 499
    invoke-direct {v3, v5}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 500
    .line 501
    .line 502
    invoke-virtual {v1, v2, v3}, Landroid/os/Bundle;->putIntegerArrayList(Ljava/lang/String;Ljava/util/ArrayList;)V

    .line 503
    .line 504
    .line 505
    const-string v2, "KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS"

    .line 506
    .line 507
    new-instance v3, Ljava/util/ArrayList;

    .line 508
    .line 509
    invoke-virtual {v4}, Ljava/util/HashMap;->keySet()Ljava/util/Set;

    .line 510
    .line 511
    .line 512
    move-result-object v4

    .line 513
    invoke-direct {v3, v4}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 514
    .line 515
    .line 516
    invoke-virtual {v1, v2, v3}, Landroid/os/Bundle;->putStringArrayList(Ljava/lang/String;Ljava/util/ArrayList;)V

    .line 517
    .line 518
    .line 519
    const-string v2, "KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS"

    .line 520
    .line 521
    new-instance v3, Ljava/util/ArrayList;

    .line 522
    .line 523
    iget-object v4, v0, Lc/f;->e:Ljava/util/ArrayList;

    .line 524
    .line 525
    invoke-direct {v3, v4}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 526
    .line 527
    .line 528
    invoke-virtual {v1, v2, v3}, Landroid/os/Bundle;->putStringArrayList(Ljava/lang/String;Ljava/util/ArrayList;)V

    .line 529
    .line 530
    .line 531
    const-string v2, "KEY_COMPONENT_ACTIVITY_PENDING_RESULT"

    .line 532
    .line 533
    iget-object v3, v0, Lc/f;->h:Landroid/os/Bundle;

    .line 534
    .line 535
    invoke-virtual {v3}, Landroid/os/Bundle;->clone()Ljava/lang/Object;

    .line 536
    .line 537
    .line 538
    move-result-object v3

    .line 539
    check-cast v3, Landroid/os/Bundle;

    .line 540
    .line 541
    invoke-virtual {v1, v2, v3}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    .line 542
    .line 543
    .line 544
    const-string v2, "KEY_COMPONENT_ACTIVITY_RANDOM_OBJECT"

    .line 545
    .line 546
    iget-object v0, v0, Lc/f;->a:Ljava/util/Random;

    .line 547
    .line 548
    invoke-virtual {v1, v2, v0}, Landroid/os/Bundle;->putSerializable(Ljava/lang/String;Ljava/io/Serializable;)V

    .line 549
    .line 550
    .line 551
    return-object v1

    .line 552
    nop

    .line 553
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
