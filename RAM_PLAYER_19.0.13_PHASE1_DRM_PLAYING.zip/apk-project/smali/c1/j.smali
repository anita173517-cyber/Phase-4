.class public final synthetic Lc1/j;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic k:I

.field public final synthetic l:Lc1/d;


# direct methods
.method public synthetic constructor <init>(Lc1/d;I)V
    .locals 0

    .line 1
    iput p2, p0, Lc1/j;->k:I

    iput-object p1, p0, Lc1/j;->l:Lc1/d;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 1

    .line 1
    iget v0, p0, Lc1/j;->k:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, Lc1/j;->l:Lc1/d;

    invoke-interface {v0}, Lc1/d;->c()V

    return-void

    :pswitch_0
    iget-object v0, p0, Lc1/j;->l:Lc1/d;

    invoke-interface {v0}, Lc1/d;->a()V

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
