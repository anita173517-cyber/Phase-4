.class public final Lc2/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La2/t;


# instance fields
.field public final a:Ly0/w;

.field public final b:La2/d;

.field public final c:Z

.field public final d:Lx1/b;

.field public e:I

.field public f:La2/v;

.field public g:Lc2/c;

.field public h:J

.field public i:[Lc2/e;

.field public j:J

.field public k:Lc2/e;

.field public l:I

.field public m:J

.field public n:J

.field public o:I

.field public p:Z


# direct methods
.method public constructor <init>(ILx1/b;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p2, p0, Lc2/b;->d:Lx1/b;

    .line 5
    .line 6
    const/4 p2, 0x1

    .line 7
    and-int/2addr p1, p2

    .line 8
    const/4 v0, 0x0

    .line 9
    if-nez p1, :cond_0

    .line 10
    .line 11
    goto :goto_0

    .line 12
    :cond_0
    move p2, v0

    .line 13
    :goto_0
    iput-boolean p2, p0, Lc2/b;->c:Z

    .line 14
    .line 15
    new-instance p1, Ly0/w;

    .line 16
    .line 17
    const/16 p2, 0xc

    .line 18
    .line 19
    invoke-direct {p1, p2}, Ly0/w;-><init>(I)V

    .line 20
    .line 21
    .line 22
    iput-object p1, p0, Lc2/b;->a:Ly0/w;

    .line 23
    .line 24
    new-instance p1, La2/d;

    .line 25
    .line 26
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 27
    .line 28
    .line 29
    iput-object p1, p0, Lc2/b;->b:La2/d;

    .line 30
    .line 31
    new-instance p1, La2/h;

    .line 32
    .line 33
    const/4 p2, 0x2

    .line 34
    invoke-direct {p1, p2}, La2/h;-><init>(I)V

    .line 35
    .line 36
    .line 37
    iput-object p1, p0, Lc2/b;->f:La2/v;

    .line 38
    .line 39
    new-array p1, v0, [Lc2/e;

    .line 40
    .line 41
    iput-object p1, p0, Lc2/b;->i:[Lc2/e;

    .line 42
    .line 43
    const-wide/16 p1, -0x1

    .line 44
    .line 45
    iput-wide p1, p0, Lc2/b;->m:J

    .line 46
    .line 47
    iput-wide p1, p0, Lc2/b;->n:J

    .line 48
    .line 49
    const/4 p1, -0x1

    .line 50
    iput p1, p0, Lc2/b;->l:I

    .line 51
    .line 52
    const-wide p1, -0x7fffffffffffffffL    # -4.9E-324

    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    iput-wide p1, p0, Lc2/b;->h:J

    .line 58
    .line 59
    return-void
.end method


# virtual methods
.method public final a(JJ)V
    .locals 5

    .line 1
    const-wide/16 p3, -0x1

    .line 2
    .line 3
    iput-wide p3, p0, Lc2/b;->j:J

    .line 4
    .line 5
    const/4 p3, 0x0

    .line 6
    iput-object p3, p0, Lc2/b;->k:Lc2/e;

    .line 7
    .line 8
    iget-object p3, p0, Lc2/b;->i:[Lc2/e;

    .line 9
    .line 10
    array-length p4, p3

    .line 11
    const/4 v0, 0x0

    .line 12
    move v1, v0

    .line 13
    :goto_0
    if-ge v1, p4, :cond_1

    .line 14
    .line 15
    aget-object v2, p3, v1

    .line 16
    .line 17
    iget v3, v2, Lc2/e;->l:I

    .line 18
    .line 19
    if-nez v3, :cond_0

    .line 20
    .line 21
    iput v0, v2, Lc2/e;->j:I

    .line 22
    .line 23
    goto :goto_1

    .line 24
    :cond_0
    iget-object v3, v2, Lc2/e;->n:[J

    .line 25
    .line 26
    const/4 v4, 0x1

    .line 27
    invoke-static {v3, p1, p2, v4}, Ly0/k0;->f([JJZ)I

    .line 28
    .line 29
    .line 30
    move-result v3

    .line 31
    iget-object v4, v2, Lc2/e;->o:[I

    .line 32
    .line 33
    aget v3, v4, v3

    .line 34
    .line 35
    iput v3, v2, Lc2/e;->j:I

    .line 36
    .line 37
    :goto_1
    add-int/lit8 v1, v1, 0x1

    .line 38
    .line 39
    goto :goto_0

    .line 40
    :cond_1
    const-wide/16 p3, 0x0

    .line 41
    .line 42
    cmp-long p1, p1, p3

    .line 43
    .line 44
    if-nez p1, :cond_3

    .line 45
    .line 46
    iget-object p1, p0, Lc2/b;->i:[Lc2/e;

    .line 47
    .line 48
    array-length p1, p1

    .line 49
    if-nez p1, :cond_2

    .line 50
    .line 51
    iput v0, p0, Lc2/b;->e:I

    .line 52
    .line 53
    return-void

    .line 54
    :cond_2
    const/4 p1, 0x3

    .line 55
    iput p1, p0, Lc2/b;->e:I

    .line 56
    .line 57
    return-void

    .line 58
    :cond_3
    const/4 p1, 0x6

    .line 59
    iput p1, p0, Lc2/b;->e:I

    .line 60
    .line 61
    return-void
.end method

.method public final b()La2/t;
    .locals 0

    .line 1
    return-object p0
.end method

.method public final c(La2/u;La2/x;)I
    .locals 23

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    iget-wide v2, v0, Lc2/b;->j:J

    .line 6
    .line 7
    const-wide/16 v4, -0x1

    .line 8
    .line 9
    cmp-long v2, v2, v4

    .line 10
    .line 11
    const/4 v3, 0x1

    .line 12
    const/4 v6, 0x0

    .line 13
    if-eqz v2, :cond_2

    .line 14
    .line 15
    invoke-interface {v1}, La2/u;->getPosition()J

    .line 16
    .line 17
    .line 18
    move-result-wide v7

    .line 19
    iget-wide v9, v0, Lc2/b;->j:J

    .line 20
    .line 21
    cmp-long v2, v9, v7

    .line 22
    .line 23
    if-ltz v2, :cond_0

    .line 24
    .line 25
    const-wide/32 v11, 0x40000

    .line 26
    .line 27
    .line 28
    add-long/2addr v11, v7

    .line 29
    cmp-long v2, v9, v11

    .line 30
    .line 31
    if-lez v2, :cond_1

    .line 32
    .line 33
    :cond_0
    move-object/from16 v2, p2

    .line 34
    .line 35
    goto :goto_0

    .line 36
    :cond_1
    sub-long/2addr v9, v7

    .line 37
    long-to-int v2, v9

    .line 38
    invoke-interface {v1, v2}, La2/u;->q(I)V

    .line 39
    .line 40
    .line 41
    goto :goto_1

    .line 42
    :goto_0
    iput-wide v9, v2, La2/x;->a:J

    .line 43
    .line 44
    move v2, v3

    .line 45
    goto :goto_2

    .line 46
    :cond_2
    :goto_1
    move v2, v6

    .line 47
    :goto_2
    iput-wide v4, v0, Lc2/b;->j:J

    .line 48
    .line 49
    if-eqz v2, :cond_3

    .line 50
    .line 51
    return v3

    .line 52
    :cond_3
    iget v2, v0, Lc2/b;->e:I

    .line 53
    .line 54
    const/4 v8, 0x6

    .line 55
    const/16 v10, 0x10

    .line 56
    .line 57
    const v11, 0x69766f6d

    .line 58
    .line 59
    .line 60
    const/4 v12, 0x2

    .line 61
    const/4 v13, 0x4

    .line 62
    const v14, 0x5453494c

    .line 63
    .line 64
    .line 65
    const/16 v15, 0x8

    .line 66
    .line 67
    const-wide/16 v16, 0x8

    .line 68
    .line 69
    move-wide/from16 v18, v4

    .line 70
    .line 71
    const/4 v4, 0x0

    .line 72
    const/16 v5, 0xc

    .line 73
    .line 74
    const/16 p2, 0x3

    .line 75
    .line 76
    iget-object v9, v0, Lc2/b;->b:La2/d;

    .line 77
    .line 78
    iget-object v7, v0, Lc2/b;->a:Ly0/w;

    .line 79
    .line 80
    packed-switch v2, :pswitch_data_0

    .line 81
    .line 82
    .line 83
    new-instance v1, Ljava/lang/AssertionError;

    .line 84
    .line 85
    invoke-direct {v1}, Ljava/lang/AssertionError;-><init>()V

    .line 86
    .line 87
    .line 88
    throw v1

    .line 89
    :pswitch_0
    invoke-interface {v1}, La2/u;->getPosition()J

    .line 90
    .line 91
    .line 92
    move-result-wide v8

    .line 93
    iget-wide v12, v0, Lc2/b;->n:J

    .line 94
    .line 95
    cmp-long v2, v8, v12

    .line 96
    .line 97
    if-ltz v2, :cond_4

    .line 98
    .line 99
    const/4 v1, -0x1

    .line 100
    return v1

    .line 101
    :cond_4
    iget-object v2, v0, Lc2/b;->k:Lc2/e;

    .line 102
    .line 103
    if-eqz v2, :cond_b

    .line 104
    .line 105
    iget v5, v2, Lc2/e;->i:I

    .line 106
    .line 107
    iget-object v7, v2, Lc2/e;->b:La2/p0;

    .line 108
    .line 109
    invoke-interface {v7, v1, v5, v6}, La2/p0;->e(Lv0/l;IZ)I

    .line 110
    .line 111
    .line 112
    move-result v1

    .line 113
    sub-int/2addr v5, v1

    .line 114
    iput v5, v2, Lc2/e;->i:I

    .line 115
    .line 116
    if-nez v5, :cond_5

    .line 117
    .line 118
    move v1, v3

    .line 119
    goto :goto_3

    .line 120
    :cond_5
    move v1, v6

    .line 121
    :goto_3
    if-eqz v1, :cond_9

    .line 122
    .line 123
    iget v5, v2, Lc2/e;->h:I

    .line 124
    .line 125
    if-lez v5, :cond_8

    .line 126
    .line 127
    iget-object v7, v2, Lc2/e;->b:La2/p0;

    .line 128
    .line 129
    iget v5, v2, Lc2/e;->j:I

    .line 130
    .line 131
    iget-wide v8, v2, Lc2/e;->e:J

    .line 132
    .line 133
    int-to-long v10, v5

    .line 134
    mul-long/2addr v8, v10

    .line 135
    iget v10, v2, Lc2/e;->g:I

    .line 136
    .line 137
    int-to-long v10, v10

    .line 138
    div-long/2addr v8, v10

    .line 139
    iget-boolean v10, v2, Lc2/e;->f:Z

    .line 140
    .line 141
    if-nez v10, :cond_7

    .line 142
    .line 143
    iget-object v10, v2, Lc2/e;->o:[I

    .line 144
    .line 145
    invoke-static {v10, v5}, Ljava/util/Arrays;->binarySearch([II)I

    .line 146
    .line 147
    .line 148
    move-result v5

    .line 149
    if-ltz v5, :cond_6

    .line 150
    .line 151
    goto :goto_4

    .line 152
    :cond_6
    move v10, v6

    .line 153
    goto :goto_5

    .line 154
    :cond_7
    :goto_4
    move v10, v3

    .line 155
    :goto_5
    iget v11, v2, Lc2/e;->h:I

    .line 156
    .line 157
    const/4 v12, 0x0

    .line 158
    const/4 v13, 0x0

    .line 159
    invoke-interface/range {v7 .. v13}, La2/p0;->f(JIIILa2/o0;)V

    .line 160
    .line 161
    .line 162
    :cond_8
    iget v5, v2, Lc2/e;->j:I

    .line 163
    .line 164
    add-int/2addr v5, v3

    .line 165
    iput v5, v2, Lc2/e;->j:I

    .line 166
    .line 167
    :cond_9
    if-eqz v1, :cond_a

    .line 168
    .line 169
    iput-object v4, v0, Lc2/b;->k:Lc2/e;

    .line 170
    .line 171
    :cond_a
    return v6

    .line 172
    :cond_b
    invoke-interface {v1}, La2/u;->getPosition()J

    .line 173
    .line 174
    .line 175
    move-result-wide v8

    .line 176
    const-wide/16 v12, 0x1

    .line 177
    .line 178
    and-long/2addr v8, v12

    .line 179
    cmp-long v2, v8, v12

    .line 180
    .line 181
    if-nez v2, :cond_c

    .line 182
    .line 183
    invoke-interface {v1, v3}, La2/u;->q(I)V

    .line 184
    .line 185
    .line 186
    :cond_c
    iget-object v2, v7, Ly0/w;->a:[B

    .line 187
    .line 188
    invoke-interface {v1, v2, v6, v5}, La2/u;->D([BII)V

    .line 189
    .line 190
    .line 191
    invoke-virtual {v7, v6}, Ly0/w;->N(I)V

    .line 192
    .line 193
    .line 194
    invoke-virtual {v7}, Ly0/w;->o()I

    .line 195
    .line 196
    .line 197
    move-result v2

    .line 198
    if-ne v2, v14, :cond_e

    .line 199
    .line 200
    invoke-virtual {v7, v15}, Ly0/w;->N(I)V

    .line 201
    .line 202
    .line 203
    invoke-virtual {v7}, Ly0/w;->o()I

    .line 204
    .line 205
    .line 206
    move-result v2

    .line 207
    if-ne v2, v11, :cond_d

    .line 208
    .line 209
    move v15, v5

    .line 210
    :cond_d
    invoke-interface {v1, v15}, La2/u;->q(I)V

    .line 211
    .line 212
    .line 213
    invoke-interface {v1}, La2/u;->p()V

    .line 214
    .line 215
    .line 216
    return v6

    .line 217
    :cond_e
    invoke-virtual {v7}, Ly0/w;->o()I

    .line 218
    .line 219
    .line 220
    move-result v3

    .line 221
    const v5, 0x4b4e554a    # 1.352225E7f

    .line 222
    .line 223
    .line 224
    if-ne v2, v5, :cond_f

    .line 225
    .line 226
    invoke-interface {v1}, La2/u;->getPosition()J

    .line 227
    .line 228
    .line 229
    move-result-wide v1

    .line 230
    int-to-long v3, v3

    .line 231
    add-long/2addr v1, v3

    .line 232
    add-long v1, v1, v16

    .line 233
    .line 234
    iput-wide v1, v0, Lc2/b;->j:J

    .line 235
    .line 236
    return v6

    .line 237
    :cond_f
    invoke-interface {v1, v15}, La2/u;->q(I)V

    .line 238
    .line 239
    .line 240
    invoke-interface {v1}, La2/u;->p()V

    .line 241
    .line 242
    .line 243
    iget-object v5, v0, Lc2/b;->i:[Lc2/e;

    .line 244
    .line 245
    array-length v7, v5

    .line 246
    move v8, v6

    .line 247
    :goto_6
    if-ge v8, v7, :cond_12

    .line 248
    .line 249
    aget-object v9, v5, v8

    .line 250
    .line 251
    iget v10, v9, Lc2/e;->c:I

    .line 252
    .line 253
    if-eq v10, v2, :cond_11

    .line 254
    .line 255
    iget v10, v9, Lc2/e;->d:I

    .line 256
    .line 257
    if-ne v10, v2, :cond_10

    .line 258
    .line 259
    goto :goto_7

    .line 260
    :cond_10
    add-int/lit8 v8, v8, 0x1

    .line 261
    .line 262
    goto :goto_6

    .line 263
    :cond_11
    :goto_7
    move-object v4, v9

    .line 264
    :cond_12
    if-nez v4, :cond_13

    .line 265
    .line 266
    invoke-interface {v1}, La2/u;->getPosition()J

    .line 267
    .line 268
    .line 269
    move-result-wide v1

    .line 270
    int-to-long v3, v3

    .line 271
    add-long/2addr v1, v3

    .line 272
    iput-wide v1, v0, Lc2/b;->j:J

    .line 273
    .line 274
    return v6

    .line 275
    :cond_13
    iput v3, v4, Lc2/e;->h:I

    .line 276
    .line 277
    iput v3, v4, Lc2/e;->i:I

    .line 278
    .line 279
    iput-object v4, v0, Lc2/b;->k:Lc2/e;

    .line 280
    .line 281
    return v6

    .line 282
    :pswitch_1
    new-instance v2, Ly0/w;

    .line 283
    .line 284
    iget v5, v0, Lc2/b;->o:I

    .line 285
    .line 286
    invoke-direct {v2, v5}, Ly0/w;-><init>(I)V

    .line 287
    .line 288
    .line 289
    iget-object v5, v2, Ly0/w;->a:[B

    .line 290
    .line 291
    iget v7, v0, Lc2/b;->o:I

    .line 292
    .line 293
    invoke-interface {v1, v5, v6, v7}, La2/u;->readFully([BII)V

    .line 294
    .line 295
    .line 296
    invoke-virtual {v2}, Ly0/w;->a()I

    .line 297
    .line 298
    .line 299
    move-result v1

    .line 300
    const-wide/16 v20, 0x0

    .line 301
    .line 302
    if-ge v1, v10, :cond_14

    .line 303
    .line 304
    goto :goto_9

    .line 305
    :cond_14
    iget v1, v2, Ly0/w;->b:I

    .line 306
    .line 307
    invoke-virtual {v2, v15}, Ly0/w;->O(I)V

    .line 308
    .line 309
    .line 310
    invoke-virtual {v2}, Ly0/w;->o()I

    .line 311
    .line 312
    .line 313
    move-result v5

    .line 314
    int-to-long v14, v5

    .line 315
    iget-wide v4, v0, Lc2/b;->m:J

    .line 316
    .line 317
    cmp-long v7, v14, v4

    .line 318
    .line 319
    if-lez v7, :cond_15

    .line 320
    .line 321
    goto :goto_8

    .line 322
    :cond_15
    add-long v20, v4, v16

    .line 323
    .line 324
    :goto_8
    invoke-virtual {v2, v1}, Ly0/w;->N(I)V

    .line 325
    .line 326
    .line 327
    :goto_9
    invoke-virtual {v2}, Ly0/w;->a()I

    .line 328
    .line 329
    .line 330
    move-result v1

    .line 331
    if-lt v1, v10, :cond_1f

    .line 332
    .line 333
    invoke-virtual {v2}, Ly0/w;->o()I

    .line 334
    .line 335
    .line 336
    move-result v1

    .line 337
    invoke-virtual {v2}, Ly0/w;->o()I

    .line 338
    .line 339
    .line 340
    move-result v4

    .line 341
    invoke-virtual {v2}, Ly0/w;->o()I

    .line 342
    .line 343
    .line 344
    move-result v5

    .line 345
    int-to-long v14, v5

    .line 346
    add-long v14, v14, v20

    .line 347
    .line 348
    invoke-virtual {v2, v13}, Ly0/w;->O(I)V

    .line 349
    .line 350
    .line 351
    iget-object v5, v0, Lc2/b;->i:[Lc2/e;

    .line 352
    .line 353
    array-length v7, v5

    .line 354
    move v9, v6

    .line 355
    :goto_a
    if-ge v9, v7, :cond_17

    .line 356
    .line 357
    aget-object v11, v5, v9

    .line 358
    .line 359
    iget v13, v11, Lc2/e;->c:I

    .line 360
    .line 361
    if-eq v13, v1, :cond_18

    .line 362
    .line 363
    iget v13, v11, Lc2/e;->d:I

    .line 364
    .line 365
    if-ne v13, v1, :cond_16

    .line 366
    .line 367
    goto :goto_b

    .line 368
    :cond_16
    add-int/lit8 v9, v9, 0x1

    .line 369
    .line 370
    const/4 v13, 0x4

    .line 371
    goto :goto_a

    .line 372
    :cond_17
    const/4 v11, 0x0

    .line 373
    :cond_18
    :goto_b
    if-nez v11, :cond_19

    .line 374
    .line 375
    :goto_c
    const/4 v13, 0x4

    .line 376
    goto :goto_9

    .line 377
    :cond_19
    and-int/lit8 v1, v4, 0x10

    .line 378
    .line 379
    if-ne v1, v10, :cond_1a

    .line 380
    .line 381
    move v1, v3

    .line 382
    goto :goto_d

    .line 383
    :cond_1a
    move v1, v6

    .line 384
    :goto_d
    iget-wide v4, v11, Lc2/e;->m:J

    .line 385
    .line 386
    cmp-long v4, v4, v18

    .line 387
    .line 388
    if-nez v4, :cond_1b

    .line 389
    .line 390
    iput-wide v14, v11, Lc2/e;->m:J

    .line 391
    .line 392
    :cond_1b
    if-nez v1, :cond_1c

    .line 393
    .line 394
    iget-boolean v1, v11, Lc2/e;->f:Z

    .line 395
    .line 396
    if-eqz v1, :cond_1e

    .line 397
    .line 398
    :cond_1c
    iget v1, v11, Lc2/e;->l:I

    .line 399
    .line 400
    iget-object v4, v11, Lc2/e;->o:[I

    .line 401
    .line 402
    array-length v4, v4

    .line 403
    if-ne v1, v4, :cond_1d

    .line 404
    .line 405
    iget-object v1, v11, Lc2/e;->n:[J

    .line 406
    .line 407
    array-length v4, v1

    .line 408
    mul-int/lit8 v4, v4, 0x3

    .line 409
    .line 410
    div-int/2addr v4, v12

    .line 411
    invoke-static {v1, v4}, Ljava/util/Arrays;->copyOf([JI)[J

    .line 412
    .line 413
    .line 414
    move-result-object v1

    .line 415
    iput-object v1, v11, Lc2/e;->n:[J

    .line 416
    .line 417
    iget-object v1, v11, Lc2/e;->o:[I

    .line 418
    .line 419
    array-length v4, v1

    .line 420
    mul-int/lit8 v4, v4, 0x3

    .line 421
    .line 422
    div-int/2addr v4, v12

    .line 423
    invoke-static {v1, v4}, Ljava/util/Arrays;->copyOf([II)[I

    .line 424
    .line 425
    .line 426
    move-result-object v1

    .line 427
    iput-object v1, v11, Lc2/e;->o:[I

    .line 428
    .line 429
    :cond_1d
    iget-object v1, v11, Lc2/e;->n:[J

    .line 430
    .line 431
    iget v4, v11, Lc2/e;->l:I

    .line 432
    .line 433
    aput-wide v14, v1, v4

    .line 434
    .line 435
    iget-object v1, v11, Lc2/e;->o:[I

    .line 436
    .line 437
    iget v5, v11, Lc2/e;->k:I

    .line 438
    .line 439
    aput v5, v1, v4

    .line 440
    .line 441
    add-int/2addr v4, v3

    .line 442
    iput v4, v11, Lc2/e;->l:I

    .line 443
    .line 444
    :cond_1e
    iget v1, v11, Lc2/e;->k:I

    .line 445
    .line 446
    add-int/2addr v1, v3

    .line 447
    iput v1, v11, Lc2/e;->k:I

    .line 448
    .line 449
    goto :goto_c

    .line 450
    :cond_1f
    iget-object v1, v0, Lc2/b;->i:[Lc2/e;

    .line 451
    .line 452
    array-length v2, v1

    .line 453
    move v4, v6

    .line 454
    :goto_e
    if-ge v4, v2, :cond_21

    .line 455
    .line 456
    aget-object v5, v1, v4

    .line 457
    .line 458
    iget-object v7, v5, Lc2/e;->n:[J

    .line 459
    .line 460
    iget v9, v5, Lc2/e;->l:I

    .line 461
    .line 462
    invoke-static {v7, v9}, Ljava/util/Arrays;->copyOf([JI)[J

    .line 463
    .line 464
    .line 465
    move-result-object v7

    .line 466
    iput-object v7, v5, Lc2/e;->n:[J

    .line 467
    .line 468
    iget-object v7, v5, Lc2/e;->o:[I

    .line 469
    .line 470
    iget v9, v5, Lc2/e;->l:I

    .line 471
    .line 472
    invoke-static {v7, v9}, Ljava/util/Arrays;->copyOf([II)[I

    .line 473
    .line 474
    .line 475
    move-result-object v7

    .line 476
    iput-object v7, v5, Lc2/e;->o:[I

    .line 477
    .line 478
    iget-boolean v7, v5, Lc2/e;->f:Z

    .line 479
    .line 480
    if-eqz v7, :cond_20

    .line 481
    .line 482
    iget-object v7, v5, Lc2/e;->a:Lc2/d;

    .line 483
    .line 484
    iget v7, v7, Lc2/d;->f:I

    .line 485
    .line 486
    if-eqz v7, :cond_20

    .line 487
    .line 488
    iget v7, v5, Lc2/e;->l:I

    .line 489
    .line 490
    if-lez v7, :cond_20

    .line 491
    .line 492
    iput v7, v5, Lc2/e;->g:I

    .line 493
    .line 494
    :cond_20
    add-int/lit8 v4, v4, 0x1

    .line 495
    .line 496
    goto :goto_e

    .line 497
    :cond_21
    iput-boolean v3, v0, Lc2/b;->p:Z

    .line 498
    .line 499
    iget-object v1, v0, Lc2/b;->i:[Lc2/e;

    .line 500
    .line 501
    array-length v1, v1

    .line 502
    if-nez v1, :cond_22

    .line 503
    .line 504
    iget-object v1, v0, Lc2/b;->f:La2/v;

    .line 505
    .line 506
    new-instance v2, La2/y;

    .line 507
    .line 508
    iget-wide v3, v0, Lc2/b;->h:J

    .line 509
    .line 510
    invoke-direct {v2, v3, v4}, La2/y;-><init>(J)V

    .line 511
    .line 512
    .line 513
    invoke-interface {v1, v2}, La2/v;->n(La2/h0;)V

    .line 514
    .line 515
    .line 516
    goto :goto_f

    .line 517
    :cond_22
    iget-object v1, v0, Lc2/b;->f:La2/v;

    .line 518
    .line 519
    new-instance v2, La2/y;

    .line 520
    .line 521
    iget-wide v3, v0, Lc2/b;->h:J

    .line 522
    .line 523
    invoke-direct {v2, v0, v3, v4, v12}, La2/y;-><init>(Ljava/lang/Object;JI)V

    .line 524
    .line 525
    .line 526
    invoke-interface {v1, v2}, La2/v;->n(La2/h0;)V

    .line 527
    .line 528
    .line 529
    :goto_f
    iput v8, v0, Lc2/b;->e:I

    .line 530
    .line 531
    iget-wide v1, v0, Lc2/b;->m:J

    .line 532
    .line 533
    iput-wide v1, v0, Lc2/b;->j:J

    .line 534
    .line 535
    return v6

    .line 536
    :pswitch_2
    iget-object v2, v7, Ly0/w;->a:[B

    .line 537
    .line 538
    invoke-interface {v1, v2, v6, v15}, La2/u;->readFully([BII)V

    .line 539
    .line 540
    .line 541
    invoke-virtual {v7, v6}, Ly0/w;->N(I)V

    .line 542
    .line 543
    .line 544
    invoke-virtual {v7}, Ly0/w;->o()I

    .line 545
    .line 546
    .line 547
    move-result v2

    .line 548
    invoke-virtual {v7}, Ly0/w;->o()I

    .line 549
    .line 550
    .line 551
    move-result v3

    .line 552
    const v4, 0x31786469

    .line 553
    .line 554
    .line 555
    if-ne v2, v4, :cond_23

    .line 556
    .line 557
    const/4 v1, 0x5

    .line 558
    iput v1, v0, Lc2/b;->e:I

    .line 559
    .line 560
    iput v3, v0, Lc2/b;->o:I

    .line 561
    .line 562
    return v6

    .line 563
    :cond_23
    invoke-interface {v1}, La2/u;->getPosition()J

    .line 564
    .line 565
    .line 566
    move-result-wide v1

    .line 567
    int-to-long v3, v3

    .line 568
    add-long/2addr v1, v3

    .line 569
    iput-wide v1, v0, Lc2/b;->j:J

    .line 570
    .line 571
    return v6

    .line 572
    :pswitch_3
    iget-wide v12, v0, Lc2/b;->m:J

    .line 573
    .line 574
    cmp-long v2, v12, v18

    .line 575
    .line 576
    if-eqz v2, :cond_24

    .line 577
    .line 578
    invoke-interface {v1}, La2/u;->getPosition()J

    .line 579
    .line 580
    .line 581
    move-result-wide v12

    .line 582
    iget-wide v3, v0, Lc2/b;->m:J

    .line 583
    .line 584
    cmp-long v12, v12, v3

    .line 585
    .line 586
    if-eqz v12, :cond_24

    .line 587
    .line 588
    iput-wide v3, v0, Lc2/b;->j:J

    .line 589
    .line 590
    return v6

    .line 591
    :cond_24
    iget-object v3, v7, Ly0/w;->a:[B

    .line 592
    .line 593
    invoke-interface {v1, v3, v6, v5}, La2/u;->D([BII)V

    .line 594
    .line 595
    .line 596
    invoke-interface {v1}, La2/u;->p()V

    .line 597
    .line 598
    .line 599
    invoke-virtual {v7, v6}, Ly0/w;->N(I)V

    .line 600
    .line 601
    .line 602
    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 603
    .line 604
    .line 605
    invoke-virtual {v7}, Ly0/w;->o()I

    .line 606
    .line 607
    .line 608
    move-result v3

    .line 609
    iput v3, v9, La2/d;->a:I

    .line 610
    .line 611
    invoke-virtual {v7}, Ly0/w;->o()I

    .line 612
    .line 613
    .line 614
    move-result v3

    .line 615
    iput v3, v9, La2/d;->b:I

    .line 616
    .line 617
    iput v6, v9, La2/d;->c:I

    .line 618
    .line 619
    invoke-virtual {v7}, Ly0/w;->o()I

    .line 620
    .line 621
    .line 622
    move-result v3

    .line 623
    iget v4, v9, La2/d;->a:I

    .line 624
    .line 625
    const v7, 0x46464952

    .line 626
    .line 627
    .line 628
    if-ne v4, v7, :cond_25

    .line 629
    .line 630
    invoke-interface {v1, v5}, La2/u;->q(I)V

    .line 631
    .line 632
    .line 633
    return v6

    .line 634
    :cond_25
    if-ne v4, v14, :cond_29

    .line 635
    .line 636
    if-eq v3, v11, :cond_26

    .line 637
    .line 638
    goto :goto_10

    .line 639
    :cond_26
    invoke-interface {v1}, La2/u;->getPosition()J

    .line 640
    .line 641
    .line 642
    move-result-wide v3

    .line 643
    iput-wide v3, v0, Lc2/b;->m:J

    .line 644
    .line 645
    iget v5, v9, La2/d;->b:I

    .line 646
    .line 647
    int-to-long v11, v5

    .line 648
    add-long/2addr v3, v11

    .line 649
    add-long v3, v3, v16

    .line 650
    .line 651
    iput-wide v3, v0, Lc2/b;->n:J

    .line 652
    .line 653
    iget-boolean v3, v0, Lc2/b;->p:Z

    .line 654
    .line 655
    if-nez v3, :cond_28

    .line 656
    .line 657
    iget-object v3, v0, Lc2/b;->g:Lc2/c;

    .line 658
    .line 659
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 660
    .line 661
    .line 662
    iget v3, v3, Lc2/c;->b:I

    .line 663
    .line 664
    and-int/2addr v3, v10

    .line 665
    if-ne v3, v10, :cond_27

    .line 666
    .line 667
    const/4 v3, 0x4

    .line 668
    iput v3, v0, Lc2/b;->e:I

    .line 669
    .line 670
    iget-wide v1, v0, Lc2/b;->n:J

    .line 671
    .line 672
    iput-wide v1, v0, Lc2/b;->j:J

    .line 673
    .line 674
    return v6

    .line 675
    :cond_27
    iget-object v3, v0, Lc2/b;->f:La2/v;

    .line 676
    .line 677
    new-instance v4, La2/y;

    .line 678
    .line 679
    iget-wide v9, v0, Lc2/b;->h:J

    .line 680
    .line 681
    invoke-direct {v4, v9, v10}, La2/y;-><init>(J)V

    .line 682
    .line 683
    .line 684
    invoke-interface {v3, v4}, La2/v;->n(La2/h0;)V

    .line 685
    .line 686
    .line 687
    const/4 v2, 0x1

    .line 688
    iput-boolean v2, v0, Lc2/b;->p:Z

    .line 689
    .line 690
    :cond_28
    invoke-interface {v1}, La2/u;->getPosition()J

    .line 691
    .line 692
    .line 693
    move-result-wide v1

    .line 694
    const-wide/16 v3, 0xc

    .line 695
    .line 696
    add-long/2addr v1, v3

    .line 697
    iput-wide v1, v0, Lc2/b;->j:J

    .line 698
    .line 699
    iput v8, v0, Lc2/b;->e:I

    .line 700
    .line 701
    return v6

    .line 702
    :cond_29
    :goto_10
    invoke-interface {v1}, La2/u;->getPosition()J

    .line 703
    .line 704
    .line 705
    move-result-wide v1

    .line 706
    iget v3, v9, La2/d;->b:I

    .line 707
    .line 708
    int-to-long v3, v3

    .line 709
    add-long/2addr v1, v3

    .line 710
    add-long v1, v1, v16

    .line 711
    .line 712
    iput-wide v1, v0, Lc2/b;->j:J

    .line 713
    .line 714
    return v6

    .line 715
    :pswitch_4
    iget v3, v0, Lc2/b;->l:I

    .line 716
    .line 717
    const/16 v22, 0x4

    .line 718
    .line 719
    add-int/lit8 v3, v3, -0x4

    .line 720
    .line 721
    new-instance v4, Ly0/w;

    .line 722
    .line 723
    invoke-direct {v4, v3}, Ly0/w;-><init>(I)V

    .line 724
    .line 725
    .line 726
    iget-object v5, v4, Ly0/w;->a:[B

    .line 727
    .line 728
    invoke-interface {v1, v5, v6, v3}, La2/u;->readFully([BII)V

    .line 729
    .line 730
    .line 731
    const v1, 0x6c726468

    .line 732
    .line 733
    .line 734
    invoke-static {v1, v4}, Lc2/f;->c(ILy0/w;)Lc2/f;

    .line 735
    .line 736
    .line 737
    move-result-object v3

    .line 738
    iget v4, v3, Lc2/f;->b:I

    .line 739
    .line 740
    if-ne v4, v1, :cond_34

    .line 741
    .line 742
    const-class v1, Lc2/c;

    .line 743
    .line 744
    invoke-virtual {v3, v1}, Lc2/f;->b(Ljava/lang/Class;)Lc2/a;

    .line 745
    .line 746
    .line 747
    move-result-object v1

    .line 748
    check-cast v1, Lc2/c;

    .line 749
    .line 750
    if-eqz v1, :cond_33

    .line 751
    .line 752
    iput-object v1, v0, Lc2/b;->g:Lc2/c;

    .line 753
    .line 754
    iget v4, v1, Lc2/c;->c:I

    .line 755
    .line 756
    int-to-long v4, v4

    .line 757
    iget v1, v1, Lc2/c;->a:I

    .line 758
    .line 759
    int-to-long v7, v1

    .line 760
    mul-long/2addr v4, v7

    .line 761
    iput-wide v4, v0, Lc2/b;->h:J

    .line 762
    .line 763
    new-instance v1, Ljava/util/ArrayList;

    .line 764
    .line 765
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 766
    .line 767
    .line 768
    iget-object v3, v3, Lc2/f;->a:Lr5/l0;

    .line 769
    .line 770
    invoke-virtual {v3, v6}, Lr5/l0;->q(I)Lr5/j0;

    .line 771
    .line 772
    .line 773
    move-result-object v3

    .line 774
    move v4, v6

    .line 775
    :cond_2a
    :goto_11
    invoke-virtual {v3}, Lr5/a;->hasNext()Z

    .line 776
    .line 777
    .line 778
    move-result v5

    .line 779
    if-eqz v5, :cond_32

    .line 780
    .line 781
    invoke-virtual {v3}, Lr5/a;->next()Ljava/lang/Object;

    .line 782
    .line 783
    .line 784
    move-result-object v5

    .line 785
    check-cast v5, Lc2/a;

    .line 786
    .line 787
    invoke-interface {v5}, Lc2/a;->a()I

    .line 788
    .line 789
    .line 790
    move-result v7

    .line 791
    const v8, 0x6c727473

    .line 792
    .line 793
    .line 794
    if-ne v7, v8, :cond_2a

    .line 795
    .line 796
    check-cast v5, Lc2/f;

    .line 797
    .line 798
    add-int/lit8 v7, v4, 0x1

    .line 799
    .line 800
    const-class v8, Lc2/d;

    .line 801
    .line 802
    invoke-virtual {v5, v8}, Lc2/f;->b(Ljava/lang/Class;)Lc2/a;

    .line 803
    .line 804
    .line 805
    move-result-object v8

    .line 806
    check-cast v8, Lc2/d;

    .line 807
    .line 808
    const-class v9, Lc2/g;

    .line 809
    .line 810
    invoke-virtual {v5, v9}, Lc2/f;->b(Ljava/lang/Class;)Lc2/a;

    .line 811
    .line 812
    .line 813
    move-result-object v9

    .line 814
    check-cast v9, Lc2/g;

    .line 815
    .line 816
    const-string v10, "AviExtractor"

    .line 817
    .line 818
    if-nez v8, :cond_2c

    .line 819
    .line 820
    const-string v4, "Missing Stream Header"

    .line 821
    .line 822
    invoke-static {v10, v4}, Ly0/a;->l(Ljava/lang/String;Ljava/lang/String;)V

    .line 823
    .line 824
    .line 825
    :cond_2b
    :goto_12
    const/4 v10, 0x0

    .line 826
    goto :goto_13

    .line 827
    :cond_2c
    if-nez v9, :cond_2d

    .line 828
    .line 829
    const-string v4, "Missing Stream Format"

    .line 830
    .line 831
    invoke-static {v10, v4}, Ly0/a;->l(Ljava/lang/String;Ljava/lang/String;)V

    .line 832
    .line 833
    .line 834
    goto :goto_12

    .line 835
    :cond_2d
    iget v10, v8, Lc2/d;->d:I

    .line 836
    .line 837
    int-to-long v13, v10

    .line 838
    iget v10, v8, Lc2/d;->b:I

    .line 839
    .line 840
    int-to-long v10, v10

    .line 841
    const-wide/32 v15, 0xf4240

    .line 842
    .line 843
    .line 844
    mul-long/2addr v15, v10

    .line 845
    iget v10, v8, Lc2/d;->c:I

    .line 846
    .line 847
    int-to-long v10, v10

    .line 848
    sget-object v17, Ly0/k0;->a:Ljava/lang/String;

    .line 849
    .line 850
    sget-object v19, Ljava/math/RoundingMode;->DOWN:Ljava/math/RoundingMode;

    .line 851
    .line 852
    move-wide/from16 v17, v10

    .line 853
    .line 854
    invoke-static/range {v13 .. v19}, Ly0/k0;->d0(JJJLjava/math/RoundingMode;)J

    .line 855
    .line 856
    .line 857
    move-result-wide v10

    .line 858
    iget-object v9, v9, Lc2/g;->a:Lv0/t;

    .line 859
    .line 860
    invoke-virtual {v9}, Lv0/t;->a()Lv0/s;

    .line 861
    .line 862
    .line 863
    move-result-object v13

    .line 864
    invoke-static {v4}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    .line 865
    .line 866
    .line 867
    move-result-object v14

    .line 868
    iput-object v14, v13, Lv0/s;->a:Ljava/lang/String;

    .line 869
    .line 870
    iget v14, v8, Lc2/d;->e:I

    .line 871
    .line 872
    if-eqz v14, :cond_2e

    .line 873
    .line 874
    iput v14, v13, Lv0/s;->p:I

    .line 875
    .line 876
    :cond_2e
    const-class v14, Lc2/h;

    .line 877
    .line 878
    invoke-virtual {v5, v14}, Lc2/f;->b(Ljava/lang/Class;)Lc2/a;

    .line 879
    .line 880
    .line 881
    move-result-object v5

    .line 882
    check-cast v5, Lc2/h;

    .line 883
    .line 884
    if-eqz v5, :cond_2f

    .line 885
    .line 886
    iget-object v5, v5, Lc2/h;->a:Ljava/lang/String;

    .line 887
    .line 888
    iput-object v5, v13, Lv0/s;->b:Ljava/lang/String;

    .line 889
    .line 890
    :cond_2f
    iget-object v5, v9, Lv0/t;->p:Ljava/lang/String;

    .line 891
    .line 892
    invoke-static {v5}, Lv0/q0;->i(Ljava/lang/String;)I

    .line 893
    .line 894
    .line 895
    move-result v5

    .line 896
    const/4 v2, 0x1

    .line 897
    if-eq v5, v2, :cond_30

    .line 898
    .line 899
    if-ne v5, v12, :cond_2b

    .line 900
    .line 901
    :cond_30
    iget-object v9, v0, Lc2/b;->f:La2/v;

    .line 902
    .line 903
    invoke-interface {v9, v4, v5}, La2/v;->t(II)La2/p0;

    .line 904
    .line 905
    .line 906
    move-result-object v5

    .line 907
    new-instance v9, Lv0/t;

    .line 908
    .line 909
    invoke-direct {v9, v13}, Lv0/t;-><init>(Lv0/s;)V

    .line 910
    .line 911
    .line 912
    invoke-interface {v5, v9}, La2/p0;->b(Lv0/t;)V

    .line 913
    .line 914
    .line 915
    invoke-interface {v5, v10, v11}, La2/p0;->c(J)V

    .line 916
    .line 917
    .line 918
    iget-wide v13, v0, Lc2/b;->h:J

    .line 919
    .line 920
    invoke-static {v13, v14, v10, v11}, Ljava/lang/Math;->max(JJ)J

    .line 921
    .line 922
    .line 923
    move-result-wide v10

    .line 924
    iput-wide v10, v0, Lc2/b;->h:J

    .line 925
    .line 926
    new-instance v10, Lc2/e;

    .line 927
    .line 928
    iget-object v11, v9, Lv0/t;->p:Ljava/lang/String;

    .line 929
    .line 930
    iget-object v9, v9, Lv0/t;->l:Ljava/lang/String;

    .line 931
    .line 932
    invoke-static {v11, v9}, Lv0/q0;->a(Ljava/lang/String;Ljava/lang/String;)Z

    .line 933
    .line 934
    .line 935
    move-result v9

    .line 936
    invoke-direct {v10, v4, v8, v5, v9}, Lc2/e;-><init>(ILc2/d;La2/p0;Z)V

    .line 937
    .line 938
    .line 939
    :goto_13
    if-eqz v10, :cond_31

    .line 940
    .line 941
    invoke-virtual {v1, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 942
    .line 943
    .line 944
    :cond_31
    move v4, v7

    .line 945
    goto/16 :goto_11

    .line 946
    .line 947
    :cond_32
    new-array v2, v6, [Lc2/e;

    .line 948
    .line 949
    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    .line 950
    .line 951
    .line 952
    move-result-object v1

    .line 953
    check-cast v1, [Lc2/e;

    .line 954
    .line 955
    iput-object v1, v0, Lc2/b;->i:[Lc2/e;

    .line 956
    .line 957
    iget-object v1, v0, Lc2/b;->f:La2/v;

    .line 958
    .line 959
    invoke-interface {v1}, La2/v;->f()V

    .line 960
    .line 961
    .line 962
    move/from16 v1, p2

    .line 963
    .line 964
    iput v1, v0, Lc2/b;->e:I

    .line 965
    .line 966
    return v6

    .line 967
    :cond_33
    const-string v1, "AviHeader not found"

    .line 968
    .line 969
    const/4 v2, 0x0

    .line 970
    invoke-static {v1, v2}, Lv0/r0;->a(Ljava/lang/String;Ljava/lang/Exception;)Lv0/r0;

    .line 971
    .line 972
    .line 973
    move-result-object v1

    .line 974
    throw v1

    .line 975
    :cond_34
    const/4 v2, 0x0

    .line 976
    new-instance v1, Ljava/lang/StringBuilder;

    .line 977
    .line 978
    const-string v3, "Unexpected header list type "

    .line 979
    .line 980
    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 981
    .line 982
    .line 983
    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 984
    .line 985
    .line 986
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 987
    .line 988
    .line 989
    move-result-object v1

    .line 990
    invoke-static {v1, v2}, Lv0/r0;->a(Ljava/lang/String;Ljava/lang/Exception;)Lv0/r0;

    .line 991
    .line 992
    .line 993
    move-result-object v1

    .line 994
    throw v1

    .line 995
    :pswitch_5
    iget-object v2, v7, Ly0/w;->a:[B

    .line 996
    .line 997
    invoke-interface {v1, v2, v6, v5}, La2/u;->readFully([BII)V

    .line 998
    .line 999
    .line 1000
    invoke-virtual {v7, v6}, Ly0/w;->N(I)V

    .line 1001
    .line 1002
    .line 1003
    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1004
    .line 1005
    .line 1006
    invoke-virtual {v7}, Ly0/w;->o()I

    .line 1007
    .line 1008
    .line 1009
    move-result v1

    .line 1010
    iput v1, v9, La2/d;->a:I

    .line 1011
    .line 1012
    invoke-virtual {v7}, Ly0/w;->o()I

    .line 1013
    .line 1014
    .line 1015
    move-result v1

    .line 1016
    iput v1, v9, La2/d;->b:I

    .line 1017
    .line 1018
    iput v6, v9, La2/d;->c:I

    .line 1019
    .line 1020
    iget v1, v9, La2/d;->a:I

    .line 1021
    .line 1022
    if-ne v1, v14, :cond_36

    .line 1023
    .line 1024
    invoke-virtual {v7}, Ly0/w;->o()I

    .line 1025
    .line 1026
    .line 1027
    move-result v1

    .line 1028
    iput v1, v9, La2/d;->c:I

    .line 1029
    .line 1030
    const v2, 0x6c726468

    .line 1031
    .line 1032
    .line 1033
    if-ne v1, v2, :cond_35

    .line 1034
    .line 1035
    iget v1, v9, La2/d;->b:I

    .line 1036
    .line 1037
    iput v1, v0, Lc2/b;->l:I

    .line 1038
    .line 1039
    iput v12, v0, Lc2/b;->e:I

    .line 1040
    .line 1041
    return v6

    .line 1042
    :cond_35
    new-instance v1, Ljava/lang/StringBuilder;

    .line 1043
    .line 1044
    const-string v2, "hdrl expected, found: "

    .line 1045
    .line 1046
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 1047
    .line 1048
    .line 1049
    iget v2, v9, La2/d;->c:I

    .line 1050
    .line 1051
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 1052
    .line 1053
    .line 1054
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 1055
    .line 1056
    .line 1057
    move-result-object v1

    .line 1058
    const/4 v3, 0x0

    .line 1059
    invoke-static {v1, v3}, Lv0/r0;->a(Ljava/lang/String;Ljava/lang/Exception;)Lv0/r0;

    .line 1060
    .line 1061
    .line 1062
    move-result-object v1

    .line 1063
    throw v1

    .line 1064
    :cond_36
    const/4 v3, 0x0

    .line 1065
    new-instance v1, Ljava/lang/StringBuilder;

    .line 1066
    .line 1067
    const-string v2, "LIST expected, found: "

    .line 1068
    .line 1069
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 1070
    .line 1071
    .line 1072
    iget v2, v9, La2/d;->a:I

    .line 1073
    .line 1074
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 1075
    .line 1076
    .line 1077
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 1078
    .line 1079
    .line 1080
    move-result-object v1

    .line 1081
    invoke-static {v1, v3}, Lv0/r0;->a(Ljava/lang/String;Ljava/lang/Exception;)Lv0/r0;

    .line 1082
    .line 1083
    .line 1084
    move-result-object v1

    .line 1085
    throw v1

    .line 1086
    :pswitch_6
    move-object v3, v4

    .line 1087
    invoke-virtual/range {p0 .. p1}, Lc2/b;->e(La2/u;)Z

    .line 1088
    .line 1089
    .line 1090
    move-result v4

    .line 1091
    if-eqz v4, :cond_37

    .line 1092
    .line 1093
    invoke-interface {v1, v5}, La2/u;->q(I)V

    .line 1094
    .line 1095
    .line 1096
    const/4 v2, 0x1

    .line 1097
    iput v2, v0, Lc2/b;->e:I

    .line 1098
    .line 1099
    return v6

    .line 1100
    :cond_37
    const-string v1, "AVI Header List not found"

    .line 1101
    .line 1102
    invoke-static {v1, v3}, Lv0/r0;->a(Ljava/lang/String;Ljava/lang/Exception;)Lv0/r0;

    .line 1103
    .line 1104
    .line 1105
    move-result-object v1

    .line 1106
    throw v1

    .line 1107
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final d()Ljava/util/List;
    .locals 1

    .line 1
    sget-object v0, Lr5/l0;->l:Lr5/j0;

    .line 2
    .line 3
    sget-object v0, Lr5/v1;->o:Lr5/v1;

    .line 4
    .line 5
    return-object v0
.end method

.method public final e(La2/u;)Z
    .locals 4

    .line 1
    iget-object v0, p0, Lc2/b;->a:Ly0/w;

    .line 2
    .line 3
    iget-object v1, v0, Ly0/w;->a:[B

    .line 4
    .line 5
    const/16 v2, 0xc

    .line 6
    .line 7
    const/4 v3, 0x0

    .line 8
    invoke-interface {p1, v1, v3, v2}, La2/u;->D([BII)V

    .line 9
    .line 10
    .line 11
    invoke-virtual {v0, v3}, Ly0/w;->N(I)V

    .line 12
    .line 13
    .line 14
    invoke-virtual {v0}, Ly0/w;->o()I

    .line 15
    .line 16
    .line 17
    move-result p1

    .line 18
    const v1, 0x46464952

    .line 19
    .line 20
    .line 21
    if-eq p1, v1, :cond_0

    .line 22
    .line 23
    return v3

    .line 24
    :cond_0
    const/4 p1, 0x4

    .line 25
    invoke-virtual {v0, p1}, Ly0/w;->O(I)V

    .line 26
    .line 27
    .line 28
    invoke-virtual {v0}, Ly0/w;->o()I

    .line 29
    .line 30
    .line 31
    move-result p1

    .line 32
    const v0, 0x20495641

    .line 33
    .line 34
    .line 35
    if-ne p1, v0, :cond_1

    .line 36
    .line 37
    const/4 p1, 0x1

    .line 38
    return p1

    .line 39
    :cond_1
    return v3
.end method

.method public final f(La2/v;)V
    .locals 2

    .line 1
    const/4 v0, 0x0

    .line 2
    iput v0, p0, Lc2/b;->e:I

    .line 3
    .line 4
    iget-boolean v0, p0, Lc2/b;->c:Z

    .line 5
    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    new-instance v0, Lh5/r;

    .line 9
    .line 10
    iget-object v1, p0, Lc2/b;->d:Lx1/b;

    .line 11
    .line 12
    invoke-direct {v0, p1, v1}, Lh5/r;-><init>(La2/v;Lx2/k;)V

    .line 13
    .line 14
    .line 15
    move-object p1, v0

    .line 16
    :cond_0
    iput-object p1, p0, Lc2/b;->f:La2/v;

    .line 17
    .line 18
    const-wide/16 v0, -0x1

    .line 19
    .line 20
    iput-wide v0, p0, Lc2/b;->j:J

    .line 21
    .line 22
    return-void
.end method

.method public final release()V
    .locals 0

    .line 1
    return-void
.end method
