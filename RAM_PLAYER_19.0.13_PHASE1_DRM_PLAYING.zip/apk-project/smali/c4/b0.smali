.class public abstract Lc4/b0;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static final A(Lcom/harindra/iptvpro/PlayerActivity;)V
    .locals 6

    const-string v0, "<this>"

    invoke-static {p0, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, Lcom/harindra/iptvpro/PlayerActivity;->D2:Landroid/os/Handler;

    iget-object v1, p0, Lcom/harindra/iptvpro/PlayerActivity;->n3:Lm6/s1;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    invoke-virtual {p0}, Lcom/harindra/iptvpro/PlayerActivity;->x()Z

    move-result v2

    if-nez v2, :cond_0

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v2

    iget-object v3, p0, Lcom/harindra/iptvpro/PlayerActivity;->g2:Ljava/lang/String;

    invoke-virtual {v2, v3}, Lm6/m6;->n(Ljava/lang/String;)I

    move-result v2

    :try_start_0
    sget-object v3, Lcom/harindra/iptvpro/PlaylistRefreshWorker;->r:Ljava/util/concurrent/ConcurrentHashMap;

    iget-object v3, p0, Lcom/harindra/iptvpro/PlayerActivity;->g2:Ljava/lang/String;

    invoke-static {v2, p0, v3}, Ll4/f;->z(ILandroid/content/Context;Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    if-lez v2, :cond_1

    int-to-long v2, v2

    const-wide/32 v4, 0x36ee80

    mul-long/2addr v2, v4

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_1
    :goto_0
    return-void
.end method

.method public static final B(Lcom/harindra/iptvpro/PlayerActivity;)V
    .locals 23

    move-object/from16 v0, p0

    const-string v1, "<this>"

    invoke-static {v0, v1}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v1

    iget-object v2, v0, Lcom/harindra/iptvpro/PlayerActivity;->g2:Ljava/lang/String;

    invoke-virtual {v1, v2}, Lm6/m6;->n(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v2

    iget-object v3, v0, Lcom/harindra/iptvpro/PlayerActivity;->g2:Ljava/lang/String;

    invoke-virtual {v2, v3}, Lm6/m6;->z(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v3

    iget-object v4, v0, Lcom/harindra/iptvpro/PlayerActivity;->g2:Ljava/lang/String;

    invoke-virtual {v3, v4}, Lm6/m6;->C(Ljava/lang/String;)J

    move-result-wide v3

    const-wide/16 v5, 0x0

    cmp-long v5, v3, v5

    if-lez v5, :cond_0

    new-instance v5, Ljava/text/SimpleDateFormat;

    const-string v6, "dd MMM HH:mm"

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v7

    invoke-direct {v5, v6, v7}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    new-instance v6, Ljava/util/Date;

    invoke-direct {v6, v3, v4}, Ljava/util/Date;-><init>(J)V

    invoke-virtual {v5, v6}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v3

    goto :goto_0

    :cond_0
    const-string v3, "Not scheduled"

    :goto_0
    invoke-static {v0}, Lc4/b0;->n(Lcom/harindra/iptvpro/PlayerActivity;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v0}, Lc4/b0;->o(Lcom/harindra/iptvpro/PlayerActivity;)Ljava/util/List;

    move-result-object v5

    invoke-interface {v5}, Ljava/util/Collection;->isEmpty()Z

    move-result v6

    if-eqz v6, :cond_1

    const-string v5, "PCM Stereo Only"

    invoke-static {v5}, Lcom/bumptech/glide/c;->m(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v5

    :cond_1
    const/4 v6, 0x0

    const/16 v7, 0x3e

    const-string v8, ", "

    invoke-static {v5, v8, v6, v7}, Lo6/j;->b0(Ljava/lang/Iterable;Ljava/lang/String;Lz6/l;I)Ljava/lang/String;

    move-result-object v5

    invoke-static {}, Ljava/lang/Runtime;->getRuntime()Ljava/lang/Runtime;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/Runtime;->totalMemory()J

    move-result-wide v7

    invoke-virtual {v6}, Ljava/lang/Runtime;->freeMemory()J

    move-result-wide v9

    sub-long/2addr v7, v9

    const-wide/32 v9, 0x100000

    div-long/2addr v7, v9

    invoke-virtual {v6}, Ljava/lang/Runtime;->maxMemory()J

    move-result-wide v11

    div-long/2addr v11, v9

    new-instance v13, Lm6/v0;

    iget-object v6, v0, Lcom/harindra/iptvpro/PlayerActivity;->l3:Lm6/b;

    iget v6, v6, Lm6/b;->i:I

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v9

    iget-object v10, v0, Lcom/harindra/iptvpro/PlayerActivity;->g2:Ljava/lang/String;

    invoke-virtual {v9, v10}, Lm6/m6;->Q(Ljava/lang/String;)I

    move-result v9

    new-instance v10, Ljava/lang/StringBuilder;

    const-string v14, "RAM Usage: "

    invoke-direct {v10, v14}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v10, v7, v8}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v7, "/"

    invoke-virtual {v10, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v11, v12}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v7, " MB \u2022 PCM Delay: +"

    invoke-virtual {v10, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v6, "ms \u2022 Sub Delay: +"

    invoke-virtual {v10, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v6, "ms"

    invoke-virtual {v10, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v16

    new-instance v6, Lm6/a1;

    const/16 v7, 0xc

    invoke-direct {v6, v7}, Lm6/a1;-><init>(I)V

    const v14, 0x7f0800ce

    const-string v15, "Engine: RAM PLAYER v19.0.9 PATCH10 ULTRA (Build 195) \u2022 Media3 1.11.1"

    const-string v17, "HEALTHY \u2713"

    const/16 v18, 0x1

    move-object/from16 v19, v6

    invoke-direct/range {v13 .. v19}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    new-instance v14, Lm6/v0;

    iget-object v6, v0, Lcom/harindra/iptvpro/PlayerActivity;->T2:Ljava/util/List;

    invoke-interface {v6}, Ljava/util/List;->size()I

    move-result v6

    iget-object v8, v0, Lcom/harindra/iptvpro/PlayerActivity;->w1:Ljava/lang/Object;

    invoke-interface {v8}, Ljava/util/List;->size()I

    move-result v8

    iget-object v9, v0, Lcom/harindra/iptvpro/PlayerActivity;->y1:Ljava/lang/Object;

    invoke-interface {v9}, Ljava/util/List;->size()I

    move-result v9

    const-string v10, " Live \u2022 "

    const-string v11, " Movies \u2022 "

    const-string v12, "Catalogs: "

    invoke-static {v6, v8, v12, v10, v11}, La0/h;->y(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v8, " Series"

    invoke-static {v6, v9, v8}, La0/h;->v(Ljava/lang/StringBuilder;ILjava/lang/String;)Ljava/lang/String;

    move-result-object v16

    iget-object v6, v0, Lcom/harindra/iptvpro/PlayerActivity;->i1:Ljava/util/Map;

    invoke-interface {v6}, Ljava/util/Map;->size()I

    move-result v6

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v8

    iget-object v9, v0, Lcom/harindra/iptvpro/PlayerActivity;->g2:Ljava/lang/String;

    invoke-virtual {v8, v9}, Lm6/m6;->o(Ljava/lang/String;)Ljava/util/HashSet;

    move-result-object v8

    invoke-virtual {v8}, Ljava/util/HashSet;->size()I

    move-result v8

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v9

    iget-object v10, v0, Lcom/harindra/iptvpro/PlayerActivity;->g2:Ljava/lang/String;

    invoke-virtual {v9, v10}, Lm6/m6;->v(Ljava/lang/String;)Ljava/util/Set;

    move-result-object v9

    invoke-interface {v9}, Ljava/util/Set;->size()I

    move-result v9

    const-string v10, " \u2022 Blacklisted: "

    const-string v11, " \u2022 Hidden: "

    const-string v12, "EPG Channels: "

    invoke-static {v6, v8, v12, v10, v11}, La0/h;->y(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v17

    new-instance v6, Lm6/a1;

    invoke-direct {v6, v7}, Lm6/a1;-><init>(I)V

    const/16 v19, 0x0

    const v15, 0x7f0800cb

    const-string v18, "CATALOGS"

    move-object/from16 v20, v6

    invoke-direct/range {v14 .. v20}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    new-instance v15, Lm6/v0;

    const-string v6, "h"

    if-nez v1, :cond_2

    const-string v8, "OFF"

    goto :goto_1

    :cond_2
    const-string v8, "Every "

    invoke-static {v1, v8, v6}, La0/h;->p(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    :goto_1
    const-string v9, "WorkManager Auto-Refresh: "

    invoke-static {v9, v8}, La0/h;->s(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v17

    const-string v8, "Last: "

    const-string v9, " \u2022 Next: "

    invoke-static {v8, v2, v9, v3}, La0/h;->t(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v18

    if-nez v1, :cond_3

    const-string v1, "MANUAL"

    :goto_2
    move-object/from16 v19, v1

    goto :goto_3

    :cond_3
    invoke-static {v6, v1}, Lq3/e;->c(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v1

    goto :goto_2

    :goto_3
    new-instance v1, Lm6/v1;

    invoke-direct {v1, v0, v7}, Lm6/v1;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const/16 v20, 0x0

    const v16, 0x7f0800d7

    move-object/from16 v21, v1

    invoke-direct/range {v15 .. v21}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    new-instance v16, Lm6/v0;

    const-string v1, "TV HDR: "

    const-string v2, " \u2022 Bitstream Audio: "

    invoke-static {v1, v4, v2, v5}, La0/h;->t(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v19

    new-instance v1, Lm6/a1;

    invoke-direct {v1, v7}, Lm6/a1;-><init>(I)V

    const/16 v21, 0x0

    const v17, 0x7f0800db

    const-string v18, "Verified Hardware Capabilities"

    const-string v20, "HARDWARE"

    move-object/from16 v22, v1

    invoke-direct/range {v16 .. v22}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    const/4 v1, 0x4

    new-array v1, v1, [Lm6/v0;

    const/4 v2, 0x0

    aput-object v13, v1, v2

    const/4 v2, 0x1

    aput-object v14, v1, v2

    const/4 v2, 0x2

    aput-object v15, v1, v2

    const/4 v2, 0x3

    aput-object v16, v1, v2

    invoke-static {v1}, Lo6/k;->K([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v5

    const-string v4, "v19.0"

    const-string v6, "Back"

    const v1, 0x7f0800cc

    const-string v2, "RAM PLAYER App Health Dashboard"

    const-string v3, "Real-time diagnostics with zero fabricated metrics"

    invoke-static/range {v0 .. v6}, Landroid/support/v4/media/session/b;->Y(Lcom/harindra/iptvpro/PlayerActivity;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;)V

    return-void
.end method

.method public static final C(Lcom/harindra/iptvpro/PlayerActivity;)V
    .locals 14

    const-string v0, "<this>"

    invoke-static {p0, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v0

    iget-object v1, p0, Lcom/harindra/iptvpro/PlayerActivity;->g2:Ljava/lang/String;

    invoke-virtual {v0, v1}, Lm6/m6;->o(Ljava/lang/String;)Ljava/util/HashSet;

    move-result-object v0

    new-instance v6, Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/HashSet;->size()I

    move-result v1

    add-int/lit8 v1, v1, 0x2

    invoke-direct {v6, v1}, Ljava/util/ArrayList;-><init>(I)V

    invoke-virtual {v0}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_3

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    iget-object v3, p0, Lcom/harindra/iptvpro/PlayerActivity;->W2:Ljava/lang/Object;

    invoke-interface {v3, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Integer;

    if-eqz v3, :cond_0

    invoke-virtual {v3}, Ljava/lang/Number;->intValue()I

    move-result v3

    iget-object v4, p0, Lcom/harindra/iptvpro/PlayerActivity;->T2:Ljava/util/List;

    invoke-static {v3, v4}, Lo6/j;->Y(ILjava/util/List;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lm6/n;

    goto :goto_1

    :cond_0
    const/4 v3, 0x0

    :goto_1
    new-instance v7, Lm6/v0;

    if-eqz v3, :cond_2

    iget-object v3, v3, Lm6/n;->c:Ljava/lang/String;

    if-nez v3, :cond_1

    goto :goto_3

    :cond_1
    :goto_2
    move-object v9, v3

    goto :goto_4

    :cond_2
    :goto_3
    const-string v3, "Channel ID: "

    invoke-static {v3, v2}, La0/h;->s(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    goto :goto_2

    :goto_4
    new-instance v13, Lm6/m2;

    const/4 v3, 0x0

    invoke-direct {v13, p0, v2, v3}, Lm6/m2;-><init>(Lcom/harindra/iptvpro/PlayerActivity;Ljava/lang/String;I)V

    const/4 v12, 0x0

    const v8, 0x7f0800c6

    const-string v10, "Tap to unblock and restore this channel to Live TV"

    const-string v11, "UNBLOCK"

    invoke-direct/range {v7 .. v13}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    invoke-virtual {v6, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_3
    invoke-virtual {v0}, Ljava/util/HashSet;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_4

    new-instance v7, Lm6/v0;

    invoke-virtual {v0}, Ljava/util/HashSet;->size()I

    move-result v1

    const-string v2, "Clear All Blacklisted Channels ("

    const-string v3, ")"

    invoke-static {v1, v2, v3}, La0/h;->p(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    new-instance v13, Lm6/l2;

    const/16 v1, 0xa

    invoke-direct {v13, p0, v1}, Lm6/l2;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const/4 v12, 0x0

    const v8, 0x7f0800d9

    const-string v10, "Restore every blacklisted channel for the active profile"

    const-string v11, "CLEAR ALL"

    invoke-direct/range {v7 .. v13}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    invoke-virtual {v6, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_4
    invoke-virtual {v0}, Ljava/util/HashSet;->size()I

    move-result v1

    const-string v2, " blocked channels (separate from Hide/Unhide)"

    invoke-static {v2, v1}, Lq3/e;->c(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0}, Ljava/util/HashSet;->size()I

    move-result v0

    const-string v1, " BLOCKED"

    invoke-static {v1, v0}, Lq3/e;->c(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v5

    const-string v7, "Back"

    const v2, 0x7f0800c6

    const-string v3, "Persistent Channel Blacklist"

    move-object v1, p0

    invoke-static/range {v1 .. v7}, Landroid/support/v4/media/session/b;->Y(Lcom/harindra/iptvpro/PlayerActivity;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;)V

    return-void
.end method

.method public static final D(Lcom/harindra/iptvpro/PlayerActivity;)V
    .locals 16

    move-object/from16 v0, p0

    const-string v1, "<this>"

    invoke-static {v0, v1}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v1

    iget-object v2, v0, Lcom/harindra/iptvpro/PlayerActivity;->g2:Ljava/lang/String;

    invoke-virtual {v1, v2}, Lm6/m6;->y(Ljava/lang/String;)Ljava/util/List;

    move-result-object v1

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v2

    iget-object v3, v0, Lcom/harindra/iptvpro/PlayerActivity;->g2:Ljava/lang/String;

    invoke-virtual {v2, v3}, Lm6/m6;->w(Ljava/lang/String;)Ljava/util/HashSet;

    move-result-object v2

    new-instance v5, Ljava/util/ArrayList;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v3

    mul-int/lit8 v3, v3, 0x2

    add-int/lit8 v3, v3, 0x1

    invoke-direct {v5, v3}, Ljava/util/ArrayList;-><init>(I)V

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_0
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_2

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    invoke-virtual {v2, v4}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v6

    xor-int/lit8 v12, v6, 0x1

    new-instance v7, Lm6/v0;

    if-nez v6, :cond_0

    const-string v8, "\ud83d\udc41\ufe0f"

    goto :goto_1

    :cond_0
    const-string v8, "\ud83d\ude48"

    :goto_1
    const-string v9, " "

    invoke-static {v8, v9, v4}, Lq3/e;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    if-nez v6, :cond_1

    const-string v6, "VISIBLE"

    :goto_2
    move-object v11, v6

    goto :goto_3

    :cond_1
    const-string v6, "HIDDEN"

    goto :goto_2

    :goto_3
    new-instance v13, Lm6/m2;

    const/4 v6, 0x3

    invoke-direct {v13, v0, v4, v6}, Lm6/m2;-><init>(Lcom/harindra/iptvpro/PlayerActivity;Ljava/lang/String;I)V

    const v8, 0x7f0800c4

    const-string v10, "Tap to toggle visibility \u2022 Use Move Up below to reorder"

    invoke-direct/range {v7 .. v13}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    invoke-virtual {v5, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-instance v8, Lm6/v0;

    const-string v6, "\u2191 Move \'"

    const-string v7, "\' Up"

    invoke-static {v6, v4, v7}, Lq3/e;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    new-instance v14, Lm6/m2;

    const/4 v6, 0x4

    invoke-direct {v14, v0, v4, v6}, Lm6/m2;-><init>(Lcom/harindra/iptvpro/PlayerActivity;Ljava/lang/String;I)V

    const/4 v13, 0x0

    const v9, 0x7f0800ce

    const-string v11, "Move this Home row higher in Cinematic Home Hub"

    const-string v12, "MOVE UP"

    invoke-direct/range {v8 .. v14}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    invoke-virtual {v5, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_2
    new-instance v9, Lm6/v0;

    new-instance v15, Lm6/l2;

    const/16 v3, 0xd

    invoke-direct {v15, v0, v3}, Lm6/l2;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const/4 v14, 0x0

    const v10, 0x7f0800d7

    const-string v11, "Reset Home Rows to Default"

    const-string v12, "Restore default order and show all Home Hub rows"

    const-string v13, "RESET"

    invoke-direct/range {v9 .. v15}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    invoke-virtual {v5, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v3

    invoke-virtual {v2}, Ljava/util/HashSet;->size()I

    move-result v2

    sub-int/2addr v3, v2

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v3, "/"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const-string v6, "Back"

    const v1, 0x7f0800c4

    const-string v2, "Customize Home Screen Rows"

    const-string v3, "Changes apply immediately per profile"

    invoke-static/range {v0 .. v6}, Landroid/support/v4/media/session/b;->Y(Lcom/harindra/iptvpro/PlayerActivity;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;)V

    return-void
.end method

.method public static final E(Lcom/harindra/iptvpro/PlayerActivity;ILm6/p8;)V
    .locals 19

    move-object/from16 v1, p0

    move/from16 v4, p1

    const-string v0, "<this>"

    invoke-static {v1, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, v1, Lcom/harindra/iptvpro/PlayerActivity;->w1:Ljava/lang/Object;

    invoke-static {v4, v0}, Lo6/j;->Y(ILjava/util/List;)Ljava/lang/Object;

    move-result-object v0

    move-object v3, v0

    check-cast v3, Lm6/n;

    if-nez v3, :cond_0

    goto :goto_0

    :cond_0
    iget-object v0, v3, Lm6/n;->i:Lm6/c0;

    sget-object v2, Lm6/c0;->XTREAM_VOD_MOVIE:Lm6/c0;

    if-eq v0, v2, :cond_1

    :goto_0
    return-void

    :cond_1
    iput v4, v1, Lcom/harindra/iptvpro/PlayerActivity;->G1:I

    iput-object v3, v1, Lcom/harindra/iptvpro/PlayerActivity;->F1:Lm6/n;

    iget-object v2, v1, Lcom/harindra/iptvpro/PlayerActivity;->d2:Lm6/w8;

    if-nez p2, :cond_2

    if-eqz v2, :cond_2

    invoke-static {v1}, Landroidx/lifecycle/i0;->a(Landroidx/lifecycle/r;)Landroidx/lifecycle/m;

    move-result-object v6

    new-instance v0, Lj7/c;

    const/4 v5, 0x0

    invoke-direct/range {v0 .. v5}, Lj7/c;-><init>(Lcom/harindra/iptvpro/PlayerActivity;Lm6/w8;Lm6/n;ILr6/d;)V

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-static {v6, v2, v0, v1}, Lf7/v;->j(Lf7/s;Lr6/i;Lz6/p;I)Lf7/g1;

    return-void

    :cond_2
    if-nez p2, :cond_5

    iget-object v0, v3, Lm6/n;->a:Ljava/lang/String;

    const-string v2, "vod_"

    invoke-static {v0, v2}, Le7/e;->e0(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v3}, Lm6/n;->a()Ljava/lang/String;

    move-result-object v7

    iget-object v8, v3, Lm6/n;->f:Ljava/lang/String;

    iget-object v0, v3, Lm6/n;->l:Ljava/lang/String;

    invoke-static {v0}, Le7/e;->Y(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_3

    invoke-virtual {v3}, Lm6/n;->e()Ljava/lang/String;

    move-result-object v0

    :cond_3
    move-object v10, v0

    iget-object v11, v3, Lm6/n;->m:Ljava/lang/String;

    iget-object v12, v3, Lm6/n;->d:Ljava/lang/String;

    iget-object v13, v3, Lm6/n;->n:Ljava/lang/String;

    iget-object v14, v3, Lm6/n;->o:Ljava/lang/String;

    iget-object v15, v3, Lm6/n;->p:Ljava/lang/String;

    iget-object v0, v3, Lm6/n;->q:Ljava/lang/String;

    iget-object v2, v3, Lm6/n;->k:Ljava/lang/String;

    invoke-static {v2}, Le7/e;->Y(Ljava/lang/CharSequence;)Z

    move-result v5

    if-eqz v5, :cond_4

    const-string v2, "mp4"

    :cond_4
    move-object/from16 v17, v2

    iget-object v2, v3, Lm6/n;->r:Ljava/lang/String;

    new-instance v5, Lm6/p8;

    const-string v9, ""

    move-object/from16 v16, v0

    move-object/from16 v18, v2

    invoke-direct/range {v5 .. v18}, Lm6/p8;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_1

    :cond_5
    move-object/from16 v5, p2

    :goto_1
    iput-object v5, v1, Lcom/harindra/iptvpro/PlayerActivity;->H1:Lm6/p8;

    invoke-static {v1, v4, v3, v5}, Lc4/b0;->x(Lcom/harindra/iptvpro/PlayerActivity;ILm6/n;Lm6/p8;)V

    return-void
.end method

.method public static final F(Lcom/harindra/iptvpro/PlayerActivity;)V
    .locals 25

    move-object/from16 v0, p0

    const-string v1, "<this>"

    invoke-static {v0, v1}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v1, Ljava/text/SimpleDateFormat;

    const-string v2, "dd MMM HH:mm"

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v3

    invoke-direct {v1, v2, v3}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v2

    invoke-virtual {v2}, Lm6/m6;->e()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v3

    const/4 v4, 0x0

    if-eqz v3, :cond_0

    const-string v1, "No saved playlists"

    invoke-static {v0, v1, v4}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    return-void

    :cond_0
    new-instance v5, Ljava/util/ArrayList;

    const/16 v3, 0xa

    invoke-static {v2, v3}, Lo6/l;->O(Ljava/lang/Iterable;I)I

    move-result v3

    invoke-direct {v5, v3}, Ljava/util/ArrayList;-><init>(I)V

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v3

    move v6, v4

    :goto_0
    if-ge v6, v3, :cond_7

    invoke-virtual {v2, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    add-int/lit8 v6, v6, 0x1

    check-cast v7, Lm6/z5;

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v8

    iget-object v9, v7, Lm6/z5;->a:Ljava/lang/String;

    invoke-virtual {v8, v9}, Lm6/m6;->n(Ljava/lang/String;)I

    move-result v8

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v10

    invoke-virtual {v10, v9}, Lm6/m6;->g0(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    iget-object v10, v10, Lm6/m6;->b:Landroid/content/SharedPreferences;

    new-instance v12, Ljava/lang/StringBuilder;

    const-string v13, "last_refresh_success_ms_v194_"

    invoke-direct {v12, v13}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v12, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v11

    const-wide/16 v12, 0x0

    invoke-interface {v10, v11, v12, v13}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide v10

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v14

    invoke-virtual {v14, v9}, Lm6/m6;->C(Ljava/lang/String;)J

    move-result-wide v14

    new-instance v16, Lm6/v0;

    iget-object v4, v7, Lm6/z5;->b:Ljava/lang/String;

    move-wide/from16 v17, v12

    const-string v12, "h"

    const-string v13, "OFF"

    move/from16 v23, v3

    if-nez v8, :cond_1

    move-object v3, v13

    :goto_1
    move/from16 v24, v6

    goto :goto_2

    :cond_1
    const-string v3, "Every "

    invoke-static {v8, v3, v12}, La0/h;->p(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    goto :goto_1

    :goto_2
    iget-object v6, v0, Lcom/harindra/iptvpro/PlayerActivity;->g2:Ljava/lang/String;

    invoke-static {v9, v6}, La7/h;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_2

    const-string v6, " \u2022 ACTIVE"

    :goto_3
    move-object/from16 v19, v13

    goto :goto_4

    :cond_2
    const-string v6, ""

    goto :goto_3

    :goto_4
    new-instance v13, Ljava/lang/StringBuilder;

    invoke-direct {v13}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v13, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, ": "

    invoke-virtual {v13, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v13, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v13, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v13}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    cmp-long v4, v10, v17

    if-lez v4, :cond_3

    new-instance v4, Ljava/util/Date;

    invoke-direct {v4, v10, v11}, Ljava/util/Date;-><init>(J)V

    invoke-virtual {v1, v4}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v4

    goto :goto_5

    :cond_3
    const-string v4, "never"

    :goto_5
    if-lez v8, :cond_4

    cmp-long v6, v14, v17

    if-lez v6, :cond_4

    new-instance v6, Ljava/util/Date;

    invoke-direct {v6, v14, v15}, Ljava/util/Date;-><init>(J)V

    invoke-virtual {v1, v6}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v6

    goto :goto_6

    :cond_4
    const-string v6, "not scheduled"

    :goto_6
    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v10

    invoke-virtual {v10, v9}, Lm6/m6;->z(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    const/16 v10, 0x3c

    invoke-static {v9, v10}, Le7/e;->n0(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v9

    const-string v10, " \u2022 Next: "

    const-string v11, " \u2022 "

    const-string v13, "Last success: "

    invoke-static {v13, v4, v10, v6, v11}, Lq3/e;->h(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    if-nez v8, :cond_5

    move-object/from16 v20, v19

    goto :goto_7

    :cond_5
    invoke-static {v12, v8}, Lq3/e;->c(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v13

    move-object/from16 v20, v13

    :goto_7
    if-lez v8, :cond_6

    const/4 v6, 0x1

    move/from16 v21, v6

    goto :goto_8

    :cond_6
    const/16 v21, 0x0

    :goto_8
    new-instance v6, Lm6/n2;

    const/4 v9, 0x0

    invoke-direct {v6, v8, v0, v7, v9}, Lm6/n2;-><init>(ILcom/harindra/iptvpro/PlayerActivity;Ljava/lang/Object;I)V

    const v17, 0x7f0800d7

    move-object/from16 v18, v3

    move-object/from16 v19, v4

    move-object/from16 v22, v6

    invoke-direct/range {v16 .. v22}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    move-object/from16 v3, v16

    invoke-virtual {v5, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    move/from16 v3, v23

    move/from16 v6, v24

    const/4 v4, 0x0

    goto/16 :goto_0

    :cond_7
    invoke-virtual {v2}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_8

    const/4 v4, 0x0

    goto :goto_a

    :cond_8
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v3, 0x0

    const/4 v4, 0x0

    :cond_9
    :goto_9
    if-ge v3, v1, :cond_b

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    add-int/lit8 v3, v3, 0x1

    check-cast v6, Lm6/z5;

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v7

    iget-object v6, v6, Lm6/z5;->a:Ljava/lang/String;

    invoke-virtual {v7, v6}, Lm6/m6;->n(Ljava/lang/String;)I

    move-result v6

    if-lez v6, :cond_9

    add-int/lit8 v4, v4, 0x1

    if-ltz v4, :cond_a

    goto :goto_9

    :cond_a
    invoke-static {}, Lo6/k;->M()V

    const/4 v0, 0x0

    throw v0

    :cond_b
    :goto_a
    const-string v1, " ON"

    invoke-static {v1, v4}, Lq3/e;->c(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v4

    const-string v6, "Back"

    const v1, 0x7f0800cb

    const-string v2, "Auto-Refresh per Playlist"

    const-string v3, "OK cycles OFF \u2192 6h \u2192 12h \u2192 24h \u2192 72h for that playlist only \u2022 Needs network, skipped on low battery"

    invoke-static/range {v0 .. v6}, Landroid/support/v4/media/session/b;->Y(Lcom/harindra/iptvpro/PlayerActivity;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;)V

    return-void
.end method

.method public static final G(Lcom/harindra/iptvpro/PlayerActivity;)V
    .locals 26

    move-object/from16 v0, p0

    const-string v1, "<this>"

    invoke-static {v0, v1}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v1

    iget-object v2, v0, Lcom/harindra/iptvpro/PlayerActivity;->g2:Ljava/lang/String;

    invoke-virtual {v1, v2}, Lm6/m6;->n(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v2

    iget-object v3, v0, Lcom/harindra/iptvpro/PlayerActivity;->g2:Ljava/lang/String;

    invoke-virtual {v2, v3}, Lm6/m6;->g0(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    iget-object v2, v2, Lm6/m6;->b:Landroid/content/SharedPreferences;

    new-instance v4, Ljava/lang/StringBuilder;

    const-string v5, "auto_refresh_startup_v190_"

    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x0

    invoke-interface {v2, v3, v4}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v10

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v2

    iget-object v3, v0, Lcom/harindra/iptvpro/PlayerActivity;->g2:Ljava/lang/String;

    invoke-virtual {v2, v3}, Lm6/m6;->z(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    new-instance v11, Lm6/v0;

    const-string v3, "h"

    const-string v5, "OFF"

    if-nez v1, :cond_0

    move-object v6, v5

    goto :goto_0

    :cond_0
    const-string v6, "Every "

    invoke-static {v1, v6, v3}, La0/h;->p(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    :goto_0
    const-string v7, "Auto-Refresh Interval: "

    invoke-static {v7, v6}, La0/h;->s(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    if-nez v1, :cond_1

    move-object v15, v5

    goto :goto_1

    :cond_1
    invoke-static {v3, v1}, Lq3/e;->c(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v3

    move-object v15, v3

    :goto_1
    const/4 v3, 0x1

    if-lez v1, :cond_2

    move/from16 v16, v3

    goto :goto_2

    :cond_2
    move/from16 v16, v4

    :goto_2
    new-instance v6, Lm6/j2;

    invoke-direct {v6, v1, v0, v4}, Lm6/j2;-><init>(ILcom/harindra/iptvpro/PlayerActivity;I)V

    const v12, 0x7f0800d7

    const-string v14, "Tap to cycle schedule: OFF \u2192 6h \u2192 12h \u2192 24h \u2192 72h"

    move-object/from16 v17, v6

    invoke-direct/range {v11 .. v17}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    move-object v12, v11

    new-instance v13, Lm6/v0;

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v6

    invoke-virtual {v6}, Lm6/m6;->e()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    move-result v6

    const-string v7, "Auto-Refresh for Every Playlist ("

    const-string v8, ")"

    invoke-static {v6, v7, v8}, La0/h;->p(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    new-instance v6, Lm6/v1;

    const/16 v7, 0xf

    invoke-direct {v6, v0, v7}, Lm6/v1;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const/16 v18, 0x0

    const v14, 0x7f0800cb

    const-string v16, "Each playlist has its own schedule, refreshed even when another account is active"

    const-string v17, "PER PLAYLIST"

    move-object/from16 v19, v6

    invoke-direct/range {v13 .. v19}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    move-object v6, v5

    new-instance v5, Lm6/v0;

    if-eqz v10, :cond_3

    const-string v6, "ON \u2713"

    :cond_3
    move-object v9, v6

    new-instance v11, Lm6/k2;

    invoke-direct {v11, v0, v10, v4}, Lm6/k2;-><init>(Lcom/harindra/iptvpro/PlayerActivity;ZI)V

    const v6, 0x7f0800ce

    move v14, v7

    const-string v7, "Refresh Playlist on Startup"

    move-object v15, v8

    const-string v8, "Automatically refresh active playlist when RAM PLAYER launches"

    invoke-direct/range {v5 .. v11}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    new-instance v16, Lm6/v0;

    const-string v6, "Last status: "

    invoke-virtual {v6, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v19

    iget-boolean v6, v0, Lcom/harindra/iptvpro/PlayerActivity;->j3:Z

    if-eqz v6, :cond_4

    const-string v6, "RUNNING"

    :goto_3
    move-object/from16 v20, v6

    goto :goto_4

    :cond_4
    const-string v6, "SYNC"

    goto :goto_3

    :goto_4
    new-instance v6, Lm6/l2;

    const/4 v7, 0x6

    invoke-direct {v6, v0, v7}, Lm6/l2;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const/16 v21, 0x0

    const v17, 0x7f0800d7

    const-string v18, "\u25b6 Manual Refresh Now"

    move-object/from16 v22, v6

    invoke-direct/range {v16 .. v22}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    new-instance v17, Lm6/v0;

    new-instance v6, Lm6/l2;

    const/16 v8, 0xc

    invoke-direct {v6, v0, v8}, Lm6/l2;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const/16 v22, 0x0

    const v18, 0x7f0800d9

    const-string v19, "\u23f9 Cancel Active / Scheduled Refresh"

    const-string v20, "Stop active fetch and clear pending auto-refresh timer"

    const-string v21, "CANCEL"

    move-object/from16 v23, v6

    invoke-direct/range {v17 .. v23}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    new-instance v18, Lm6/v0;

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v6

    iget-object v8, v0, Lcom/harindra/iptvpro/PlayerActivity;->g2:Ljava/lang/String;

    invoke-virtual {v6, v8}, Lm6/m6;->o(Ljava/lang/String;)Ljava/util/HashSet;

    move-result-object v6

    invoke-virtual {v6}, Ljava/util/HashSet;->size()I

    move-result v6

    const-string v8, "\ud83d\udee1\ufe0f Manage Channel Blacklist ("

    invoke-static {v6, v8, v15}, La0/h;->p(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v20

    new-instance v6, Lm6/l2;

    const/16 v8, 0xe

    invoke-direct {v6, v0, v8}, Lm6/l2;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const/16 v23, 0x0

    const v19, 0x7f0800c6

    const-string v21, "View or unblock blacklisted channels separately from Hide/Unhide"

    const-string v22, "BLACKLIST"

    move-object/from16 v24, v6

    invoke-direct/range {v18 .. v24}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    new-instance v19, Lm6/v0;

    new-instance v6, Lm6/l2;

    invoke-direct {v6, v0, v14}, Lm6/l2;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const/16 v24, 0x0

    const v20, 0x7f0800cb

    const-string v21, "\ud83e\ude7a Playlist Health & Smart Duplicate Detector"

    const-string v22, "Inspect channel health, missing logos, backup streams & duplicate channels"

    const-string v23, "HEALTH"

    move-object/from16 v25, v6

    invoke-direct/range {v19 .. v25}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    const/4 v6, 0x7

    new-array v6, v6, [Lm6/v0;

    aput-object v12, v6, v4

    aput-object v13, v6, v3

    const/4 v3, 0x2

    aput-object v5, v6, v3

    const/4 v3, 0x3

    aput-object v16, v6, v3

    const/4 v3, 0x4

    aput-object v17, v6, v3

    const/4 v3, 0x5

    aput-object v18, v6, v3

    aput-object v19, v6, v7

    invoke-static {v6}, Lo6/k;->K([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v5

    const-string v3, "Last Refresh: "

    invoke-virtual {v3, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    if-nez v1, :cond_5

    const-string v1, "MANUAL"

    :goto_5
    move-object v4, v1

    goto :goto_6

    :cond_5
    const-string v2, "h AUTO"

    invoke-static {v2, v1}, Lq3/e;->c(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v1

    goto :goto_5

    :goto_6
    const-string v6, "Back"

    const v1, 0x7f0800cb

    const-string v2, "Playlist Auto-Refresh, Blacklist & Health"

    invoke-static/range {v0 .. v6}, Landroid/support/v4/media/session/b;->Y(Lcom/harindra/iptvpro/PlayerActivity;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;)V

    return-void
.end method

.method public static final H(Lcom/harindra/iptvpro/PlayerActivity;)V
    .locals 12

    const-string v0, "<this>"

    invoke-static {p0, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v1, Lm6/v0;

    new-instance v7, Lm6/v1;

    const/4 v0, 0x5

    invoke-direct {v7, p0, v0}, Lm6/v1;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const/4 v6, 0x0

    const v2, 0x7f0800d9

    const-string v3, "Clear Unified Search History"

    const-string v4, "Deletes all recent search queries on this device"

    const-string v5, "CLEAR"

    invoke-direct/range {v1 .. v7}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    new-instance v2, Lm6/v0;

    new-instance v8, Lm6/v1;

    const/4 v0, 0x6

    invoke-direct {v8, p0, v0}, Lm6/v1;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const/4 v7, 0x0

    const v3, 0x7f0800d9

    const-string v4, "Clear Watched History (Active Profile)"

    const-string v5, "Clears watched episode/movie markers for active profile only"

    const-string v6, "CLEAR"

    invoke-direct/range {v2 .. v8}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    new-instance v3, Lm6/v0;

    new-instance v9, Lm6/v1;

    const/4 v0, 0x7

    invoke-direct {v9, p0, v0}, Lm6/v1;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const/4 v8, 0x0

    const v4, 0x7f0800d9

    const-string v5, "Clear Continue Watching (Active Profile)"

    const-string v6, "Clears saved playback resume timestamps for active profile only"

    const-string v7, "CLEAR"

    invoke-direct/range {v3 .. v9}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    new-instance v4, Lm6/v0;

    new-instance v10, Lm6/v1;

    const/16 v0, 0x8

    invoke-direct {v10, p0, v0}, Lm6/v1;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const/4 v9, 0x0

    const v5, 0x7f0800bd

    const-string v6, "Manage Saved Profiles & Credentials"

    const-string v7, "View, edit, or delete encrypted M3U/Xtream accounts (AES-256 protected)"

    const-string v8, "ACCOUNTS"

    invoke-direct/range {v4 .. v10}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    const/4 v0, 0x4

    new-array v0, v0, [Lm6/v0;

    const/4 v5, 0x0

    aput-object v1, v0, v5

    const/4 v1, 0x1

    aput-object v2, v0, v1

    const/4 v1, 0x2

    aput-object v3, v0, v1

    const/4 v1, 0x3

    aput-object v4, v0, v1

    invoke-static {v0}, Lo6/k;->K([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v10

    const-string v9, "PRIVACY"

    const-string v11, "Back"

    const v6, 0x7f0800c6

    const-string v7, "Privacy Controls & Data Management"

    const-string v8, "Zero third-party telemetry \u2022 All data stays encrypted locally"

    move-object v5, p0

    invoke-static/range {v5 .. v11}, Landroid/support/v4/media/session/b;->Y(Lcom/harindra/iptvpro/PlayerActivity;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;)V

    return-void
.end method

.method public static final I(Lcom/harindra/iptvpro/PlayerActivity;)V
    .locals 16

    move-object/from16 v0, p0

    const-string v1, "<this>"

    invoke-static {v0, v1}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v1

    iget-object v2, v0, Lcom/harindra/iptvpro/PlayerActivity;->g2:Ljava/lang/String;

    invoke-virtual {v1, v2}, Lm6/m6;->P(Ljava/lang/String;)Ljava/util/List;

    move-result-object v1

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v2

    iget-object v3, v0, Lcom/harindra/iptvpro/PlayerActivity;->g2:Ljava/lang/String;

    invoke-virtual {v2, v3}, Lm6/m6;->x(Ljava/lang/String;)Ljava/util/HashSet;

    move-result-object v2

    new-instance v5, Ljava/util/ArrayList;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v3

    mul-int/lit8 v3, v3, 0x2

    add-int/lit8 v3, v3, 0x1

    invoke-direct {v5, v3}, Ljava/util/ArrayList;-><init>(I)V

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_0
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_2

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    invoke-virtual {v2, v4}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v6

    xor-int/lit8 v12, v6, 0x1

    new-instance v7, Lm6/v0;

    if-nez v6, :cond_0

    const-string v8, "\ud83d\udc41\ufe0f"

    goto :goto_1

    :cond_0
    const-string v8, "\ud83d\ude48"

    :goto_1
    const-string v9, " Nav Icon: "

    invoke-static {v8, v9, v4}, Lq3/e;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    if-nez v6, :cond_1

    const-string v6, "SHOWN"

    :goto_2
    move-object v11, v6

    goto :goto_3

    :cond_1
    const-string v6, "HIDDEN"

    goto :goto_2

    :goto_3
    new-instance v13, Lm6/m2;

    const/4 v6, 0x1

    invoke-direct {v13, v0, v4, v6}, Lm6/m2;-><init>(Lcom/harindra/iptvpro/PlayerActivity;Ljava/lang/String;I)V

    const v8, 0x7f0800c1

    const-string v10, "Tap to show/hide in navigation bar (Home & Settings stay visible)"

    invoke-direct/range {v7 .. v13}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    invoke-virtual {v5, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-instance v8, Lm6/v0;

    const-string v6, "\u2190 Move \'"

    const-string v7, "\' Left"

    invoke-static {v6, v4, v7}, Lq3/e;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    new-instance v14, Lm6/m2;

    const/4 v6, 0x2

    invoke-direct {v14, v0, v4, v6}, Lm6/m2;-><init>(Lcom/harindra/iptvpro/PlayerActivity;Ljava/lang/String;I)V

    const/4 v13, 0x0

    const v9, 0x7f0800ce

    const-string v11, "Move this navigation icon earlier in the bar"

    const-string v12, "MOVE"

    invoke-direct/range {v8 .. v14}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    invoke-virtual {v5, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_2
    new-instance v9, Lm6/v0;

    new-instance v15, Lm6/l2;

    const/16 v3, 0xb

    invoke-direct {v15, v0, v3}, Lm6/l2;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const/4 v14, 0x0

    const v10, 0x7f0800d7

    const-string v11, "Reset Navigation Bar to Default"

    const-string v12, "Restore default icon order and show all buttons"

    const-string v13, "RESET"

    invoke-direct/range {v9 .. v15}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    invoke-virtual {v5, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v3

    invoke-virtual {v2}, Ljava/util/HashSet;->size()I

    move-result v2

    sub-int/2addr v3, v2

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v3, "/"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const-string v6, "Back"

    const v1, 0x7f0800c1

    const-string v2, "Customize Navigation / Sidebar"

    const-string v3, "Per-profile visibility & order"

    invoke-static/range {v0 .. v6}, Landroid/support/v4/media/session/b;->Y(Lcom/harindra/iptvpro/PlayerActivity;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;)V

    return-void
.end method

.method public static J(La2/u;Z)Z
    .locals 12

    new-instance v0, Ly0/w;

    const/16 v1, 0x10

    invoke-direct {v0, v1}, Ly0/w;-><init>(I)V

    const/4 v2, 0x1

    move v3, v2

    :cond_0
    :goto_0
    const/16 v4, 0x8

    invoke-virtual {v0, v4}, Ly0/w;->K(I)V

    iget-object v5, v0, Ly0/w;->a:[B

    const/4 v6, 0x0

    invoke-interface {p0, v5, v6, v4, v2}, La2/u;->y([BIIZ)Z

    move-result v5

    if-nez v5, :cond_1

    goto :goto_2

    :cond_1
    invoke-virtual {v0}, Ly0/w;->C()J

    move-result-wide v7

    invoke-virtual {v0}, Ly0/w;->m()I

    move-result v5

    const-wide/16 v9, 0x1

    cmp-long v9, v7, v9

    if-nez v9, :cond_3

    iget-object v7, v0, Ly0/w;->a:[B

    invoke-interface {p0, v7, v4, v4, v2}, La2/u;->y([BIIZ)Z

    move-result v7

    if-nez v7, :cond_2

    goto :goto_2

    :cond_2
    invoke-virtual {v0, v1}, Ly0/w;->M(I)V

    invoke-virtual {v0}, Ly0/w;->G()J

    move-result-wide v7

    move v9, v1

    goto :goto_1

    :cond_3
    move v9, v4

    :goto_1
    int-to-long v9, v9

    cmp-long v11, v7, v9

    if-gez v11, :cond_4

    goto :goto_2

    :cond_4
    sub-long/2addr v7, v9

    long-to-int v7, v7

    if-eqz v3, :cond_9

    const v3, 0x66747970

    if-ne v5, v3, :cond_8

    if-ge v7, v4, :cond_5

    goto :goto_2

    :cond_5
    const/4 v3, 0x4

    invoke-virtual {v0, v3}, Ly0/w;->K(I)V

    iget-object v4, v0, Ly0/w;->a:[B

    invoke-interface {p0, v4, v6, v3}, La2/u;->D([BII)V

    invoke-virtual {v0}, Ly0/w;->m()I

    move-result v3

    const v4, 0x68656963

    if-eq v3, v4, :cond_6

    goto :goto_2

    :cond_6
    if-nez p1, :cond_7

    goto :goto_3

    :cond_7
    add-int/lit8 v7, v7, -0x4

    invoke-interface {p0, v7}, La2/u;->E(I)V

    move v3, v6

    goto :goto_0

    :cond_8
    :goto_2
    return v6

    :cond_9
    const v4, 0x6d707664

    if-ne v5, v4, :cond_a

    :goto_3
    return v2

    :cond_a
    if-eqz v7, :cond_0

    invoke-interface {p0, v7}, La2/u;->E(I)V

    goto :goto_0
.end method

.method public static final K(Lcom/harindra/iptvpro/PlayerActivity;ILm6/n;Lm6/p8;J)V
    .locals 3

    const-string v0, "<this>"

    invoke-static {p0, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "movie"

    invoke-static {p2, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "detail"

    invoke-static {p3, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {p0}, Landroid/support/v4/media/session/b;->T(Lcom/harindra/iptvpro/PlayerActivity;)V

    iput p1, p0, Lcom/harindra/iptvpro/PlayerActivity;->G1:I

    iput-object p2, p0, Lcom/harindra/iptvpro/PlayerActivity;->F1:Lm6/n;

    iput-object p3, p0, Lcom/harindra/iptvpro/PlayerActivity;->H1:Lm6/p8;

    sget-object p1, Lm6/x1;->VOD_MOVIE:Lm6/x1;

    invoke-virtual {p0, p1}, Lcom/harindra/iptvpro/PlayerActivity;->R(Lm6/x1;)V

    iput-wide p4, p0, Lcom/harindra/iptvpro/PlayerActivity;->r2:J

    invoke-virtual {p0}, Lcom/harindra/iptvpro/PlayerActivity;->L()Landroid/view/View;

    move-result-object p1

    const/16 v0, 0x8

    invoke-virtual {p1, v0}, Landroid/view/View;->setVisibility(I)V

    invoke-virtual {p0}, Lcom/harindra/iptvpro/PlayerActivity;->y()Landroid/view/View;

    move-result-object p1

    invoke-virtual {p1, v0}, Landroid/view/View;->setVisibility(I)V

    const/4 p1, 0x0

    iput p1, p0, Lcom/harindra/iptvpro/PlayerActivity;->e3:I

    iput p1, p0, Lcom/harindra/iptvpro/PlayerActivity;->N2:I

    iput-boolean p1, p0, Lcom/harindra/iptvpro/PlayerActivity;->s2:Z

    invoke-virtual {p0}, Lcom/harindra/iptvpro/PlayerActivity;->I()Landroid/widget/TextView;

    move-result-object p1

    const-string v0, "VOD"

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {p0}, Lcom/harindra/iptvpro/PlayerActivity;->H()Landroid/widget/TextView;

    move-result-object p1

    iget-object v0, p3, Lm6/p8;->b:Ljava/lang/String;

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {p0}, Lcom/harindra/iptvpro/PlayerActivity;->G()Landroid/widget/TextView;

    move-result-object p1

    iget-object v0, p3, Lm6/p8;->g:Ljava/lang/String;

    invoke-static {v0}, Le7/e;->Y(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_0

    iget-object v0, p2, Lm6/n;->d:Ljava/lang/String;

    :cond_0
    iget-object p3, p3, Lm6/p8;->l:Ljava/lang/String;

    sget-object v1, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    const-string v2, "ROOT"

    invoke-static {v1, v2}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p3, v1}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object p3

    const-string v1, "toUpperCase(...)"

    invoke-static {p3, v1}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v0, " \u2022 "

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p3

    invoke-virtual {p1, p3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {p0}, Lcom/harindra/iptvpro/PlayerActivity;->J()Landroid/widget/TextView;

    move-result-object p1

    const-string p3, "Playing Movie \u2022 Press BACK for Movie Details"

    invoke-virtual {p1, p3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {p0}, Lcom/harindra/iptvpro/PlayerActivity;->A()Landroid/widget/ProgressBar;

    move-result-object p1

    const-wide/16 v0, 0x0

    cmp-long p3, p4, v0

    if-lez p3, :cond_1

    const/16 p3, 0x32

    goto :goto_0

    :cond_1
    const/16 p3, 0x64

    :goto_0
    invoke-virtual {p1, p3}, Landroid/widget/ProgressBar;->setProgress(I)V

    invoke-virtual {p0}, Lcom/harindra/iptvpro/PlayerActivity;->x()Z

    move-result p1

    if-eqz p1, :cond_2

    invoke-virtual {p0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object p1

    invoke-virtual {p1}, Lm6/m6;->S()F

    move-result p1

    goto :goto_1

    :cond_2
    const/high16 p1, 0x3f800000    # 1.0f

    :goto_1
    iget-object p3, p0, Lcom/harindra/iptvpro/PlayerActivity;->I:Ld1/k0;

    if-eqz p3, :cond_3

    invoke-virtual {p3, p1}, Le6/e;->f(F)V

    :cond_3
    iget-object p1, p2, Lm6/n;->e:Ljava/lang/String;

    const/4 p2, 0x1

    invoke-static {p0, p1, p2}, Lcom/bumptech/glide/c;->r(Lcom/harindra/iptvpro/PlayerActivity;Ljava/lang/String;Z)V

    invoke-static {p0}, Lcom/bumptech/glide/c;->z(Lcom/harindra/iptvpro/PlayerActivity;)V

    return-void
.end method

.method public static L(Lb7/c;I)Lb7/a;
    .locals 2

    const-string v0, "<this>"

    invoke-static {p0, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    if-lez p1, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    if-eqz v0, :cond_2

    iget v0, p0, Lb7/a;->k:I

    iget v1, p0, Lb7/a;->l:I

    iget p0, p0, Lb7/a;->m:I

    if-lez p0, :cond_1

    goto :goto_1

    :cond_1
    neg-int p1, p1

    :goto_1
    new-instance p0, Lb7/a;

    invoke-direct {p0, v0, v1, p1}, Lb7/a;-><init>(III)V

    return-object p0

    :cond_2
    new-instance p0, Ljava/lang/IllegalArgumentException;

    new-instance p1, Ljava/lang/StringBuilder;

    const-string v0, "Step must be positive, was: "

    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/16 v0, 0x2e

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static final M(Lcom/harindra/iptvpro/PlayerActivity;Ljava/lang/String;)V
    .locals 13

    const-string v0, "<this>"

    invoke-static {p0, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "targetSectionName"

    invoke-static {p1, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x18

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-lt v0, v1, :cond_0

    invoke-static {p0}, Li/w;->t(Lcom/harindra/iptvpro/PlayerActivity;)Z

    move-result v0

    if-eqz v0, :cond_0

    move v0, v2

    goto :goto_0

    :cond_0
    move v0, v3

    :goto_0
    invoke-virtual {p0}, Lcom/harindra/iptvpro/PlayerActivity;->x()Z

    move-result v1

    if-eqz v1, :cond_2

    invoke-virtual {p0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v1

    iget-object v1, v1, Lm6/m6;->b:Landroid/content/SharedPreferences;

    const-string v4, "stop_live_tv_in_background_v190"

    invoke-interface {v1, v4, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v1

    if-eqz v1, :cond_1

    goto :goto_1

    :cond_1
    move v1, v3

    goto :goto_2

    :cond_2
    :goto_1
    move v1, v2

    :goto_2
    sget-object v4, Lm6/z0;->a:Lm6/y0;

    iget-object v4, p0, Lcom/harindra/iptvpro/PlayerActivity;->E1:Lm6/x1;

    sget-object v5, Lm6/x1;->LIVE_TV:Lm6/x1;

    if-ne v4, v5, :cond_3

    goto :goto_3

    :cond_3
    move v2, v3

    :goto_3
    if-eqz v0, :cond_4

    :goto_4
    move v2, v3

    goto :goto_5

    :cond_4
    if-nez v1, :cond_5

    goto :goto_4

    :cond_5
    :goto_5
    if-nez v2, :cond_6

    return-void

    :cond_6
    iget-object v0, p0, Lcom/harindra/iptvpro/PlayerActivity;->T2:Ljava/util/List;

    iget v1, p0, Lcom/harindra/iptvpro/PlayerActivity;->c3:I

    invoke-static {v1, v0}, Lo6/j;->Y(ILjava/util/List;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lm6/n;

    iget v1, p0, Lcom/harindra/iptvpro/PlayerActivity;->c3:I

    if-eqz v0, :cond_7

    iget-object v2, v0, Lm6/n;->a:Ljava/lang/String;

    goto :goto_6

    :cond_7
    const/4 v2, 0x0

    :goto_6
    const-string v4, ""

    if-nez v2, :cond_8

    move-object v8, v4

    goto :goto_7

    :cond_8
    move-object v8, v2

    :goto_7
    if-eqz v0, :cond_a

    iget-object v0, v0, Lm6/n;->c:Ljava/lang/String;

    if-nez v0, :cond_9

    goto :goto_9

    :cond_9
    :goto_8
    move-object v9, v0

    goto :goto_a

    :cond_a
    :goto_9
    const-string v0, "Live TV"

    goto :goto_8

    :goto_a
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v11

    new-instance v5, Lm6/y0;

    if-gez v1, :cond_b

    move v7, v3

    goto :goto_b

    :cond_b
    move v7, v1

    :goto_b
    const/4 v6, 0x1

    move-object v10, p1

    invoke-direct/range {v5 .. v12}, Lm6/y0;-><init>(ZILjava/lang/String;Ljava/lang/String;Ljava/lang/String;J)V

    sput-object v5, Lm6/z0;->a:Lm6/y0;

    sget-object p1, Lm6/y7;->a:Lk7/e;

    invoke-static {}, Lm6/y7;->f()V

    iget-object p1, p0, Lcom/harindra/iptvpro/PlayerActivity;->D2:Landroid/os/Handler;

    iget-object v0, p0, Lcom/harindra/iptvpro/PlayerActivity;->P2:Lm6/d2;

    invoke-virtual {p1, v0}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-object p1, p0, Lcom/harindra/iptvpro/PlayerActivity;->D2:Landroid/os/Handler;

    iget-object v0, p0, Lcom/harindra/iptvpro/PlayerActivity;->K2:Lm6/s1;

    invoke-virtual {p1, v0}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-object p1, p0, Lcom/harindra/iptvpro/PlayerActivity;->I:Ld1/k0;

    if-eqz p1, :cond_d

    invoke-virtual {p1}, Le6/e;->J()Z

    move-result v0

    if-nez v0, :cond_c

    invoke-virtual {p1}, Ld1/k0;->D()I

    move-result v0

    const/4 v1, 0x2

    if-eq v0, v1, :cond_c

    invoke-virtual {p1}, Ld1/k0;->D()I

    move-result v0

    const/4 v1, 0x3

    if-ne v0, v1, :cond_d

    :cond_c
    invoke-virtual {p1, v3}, Ld1/k0;->i(Z)V

    invoke-virtual {p1}, Ld1/k0;->stop()V

    invoke-virtual {p1}, Le6/e;->z()V

    :cond_d
    iput-object v4, p0, Lcom/harindra/iptvpro/PlayerActivity;->q2:Ljava/lang/String;

    new-instance p1, Ljava/lang/StringBuilder;

    const-string v0, "\u23f8 Live TV Stopped ("

    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, ")"

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const-string v0, "<set-?>"

    invoke-static {p1, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iput-object p1, p0, Lcom/harindra/iptvpro/PlayerActivity;->j2:Ljava/lang/String;

    return-void
.end method

.method public static final N(Lcom/harindra/iptvpro/PlayerActivity;Lm6/h0;)V
    .locals 8

    const-string v0, "<this>"

    invoke-static {p0, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "section"

    invoke-static {p1, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {p0, p1}, Ll3/e;->V(Lcom/harindra/iptvpro/PlayerActivity;Lm6/h0;)V

    sget-object v0, Lm6/t5;->a:[I

    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    move-result p1

    aget p1, v0, p1

    const/4 v0, 0x1

    const/16 v1, 0x8

    const-string v2, ""

    const/4 v3, 0x0

    if-eq p1, v0, :cond_4

    const/4 v0, 0x0

    const-string v4, "vodPosterSearch"

    const-string v5, "RECENTLY ADDED"

    const-string v6, "RECENT_ADDED"

    const/4 v7, 0x2

    if-eq p1, v7, :cond_2

    const/4 v7, 0x3

    if-ne p1, v7, :cond_1

    const-string p1, "Series"

    invoke-static {p0, p1}, Lc4/b0;->M(Lcom/harindra/iptvpro/PlayerActivity;Ljava/lang/String;)V

    invoke-virtual {p0}, Lcom/harindra/iptvpro/PlayerActivity;->y()Landroid/view/View;

    move-result-object p1

    invoke-virtual {p1, v1}, Landroid/view/View;->setVisibility(I)V

    invoke-virtual {p0}, Lcom/harindra/iptvpro/PlayerActivity;->E()Landroid/view/View;

    move-result-object p1

    invoke-virtual {p1, v3}, Landroid/view/View;->setVisibility(I)V

    iput-object v6, p0, Lcom/harindra/iptvpro/PlayerActivity;->n1:Ljava/lang/String;

    iput-object v5, p0, Lcom/harindra/iptvpro/PlayerActivity;->l1:Ljava/lang/String;

    iget-object p1, p0, Lcom/harindra/iptvpro/PlayerActivity;->x0:Landroid/widget/EditText;

    if-eqz p1, :cond_0

    invoke-virtual {p1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iput-object v2, p0, Lcom/harindra/iptvpro/PlayerActivity;->k1:Ljava/lang/String;

    sget-object p1, Lm6/h0;->SERIES:Lm6/h0;

    invoke-static {p0, p1, v3}, Lc4/b0;->v(Lcom/harindra/iptvpro/PlayerActivity;Lm6/h0;I)V

    return-void

    :cond_0
    invoke-static {v4}, La7/h;->h(Ljava/lang/String;)V

    throw v0

    :cond_1
    new-instance p0, Lb5/f0;

    invoke-direct {p0}, Ljava/lang/RuntimeException;-><init>()V

    throw p0

    :cond_2
    const-string p1, "Movies"

    invoke-static {p0, p1}, Lc4/b0;->M(Lcom/harindra/iptvpro/PlayerActivity;Ljava/lang/String;)V

    invoke-virtual {p0}, Lcom/harindra/iptvpro/PlayerActivity;->y()Landroid/view/View;

    move-result-object p1

    invoke-virtual {p1, v1}, Landroid/view/View;->setVisibility(I)V

    invoke-virtual {p0}, Lcom/harindra/iptvpro/PlayerActivity;->E()Landroid/view/View;

    move-result-object p1

    invoke-virtual {p1, v3}, Landroid/view/View;->setVisibility(I)V

    iput-object v6, p0, Lcom/harindra/iptvpro/PlayerActivity;->n1:Ljava/lang/String;

    iput-object v5, p0, Lcom/harindra/iptvpro/PlayerActivity;->l1:Ljava/lang/String;

    iget-object p1, p0, Lcom/harindra/iptvpro/PlayerActivity;->x0:Landroid/widget/EditText;

    if-eqz p1, :cond_3

    invoke-virtual {p1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iput-object v2, p0, Lcom/harindra/iptvpro/PlayerActivity;->k1:Ljava/lang/String;

    sget-object p1, Lm6/h0;->MOVIES:Lm6/h0;

    invoke-static {p0, p1, v3}, Lc4/b0;->v(Lcom/harindra/iptvpro/PlayerActivity;Lm6/h0;I)V

    return-void

    :cond_3
    invoke-static {v4}, La7/h;->h(Ljava/lang/String;)V

    throw v0

    :cond_4
    invoke-virtual {p0}, Lcom/harindra/iptvpro/PlayerActivity;->L()Landroid/view/View;

    move-result-object p1

    invoke-virtual {p1, v1}, Landroid/view/View;->setVisibility(I)V

    iget-object p1, p0, Lcom/harindra/iptvpro/PlayerActivity;->E1:Lm6/x1;

    sget-object v0, Lm6/x1;->LIVE_TV:Lm6/x1;

    if-eq p1, v0, :cond_6

    iget-object p1, p0, Lcom/harindra/iptvpro/PlayerActivity;->I:Ld1/k0;

    if-eqz p1, :cond_5

    invoke-virtual {p1, v3}, Ld1/k0;->i(Z)V

    invoke-virtual {p1}, Ld1/k0;->stop()V

    invoke-virtual {p1}, Le6/e;->z()V

    :cond_5
    iput-object v2, p0, Lcom/harindra/iptvpro/PlayerActivity;->q2:Ljava/lang/String;

    invoke-virtual {p0, v0}, Lcom/harindra/iptvpro/PlayerActivity;->R(Lm6/x1;)V

    :cond_6
    invoke-static {p0}, Lc4/b0;->z(Lcom/harindra/iptvpro/PlayerActivity;)V

    invoke-virtual {p0}, Lcom/harindra/iptvpro/PlayerActivity;->F()Landroid/widget/TextView;

    move-result-object p1

    iget-object v0, p0, Lcom/harindra/iptvpro/PlayerActivity;->T2:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "RAM PLAYER v19.0 \u2022 LIVE TV ("

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v0, ")"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-static {p0}, La/a;->z(Lcom/harindra/iptvpro/PlayerActivity;)V

    return-void
.end method

.method public static O(Ljava/lang/Class;Ljava/lang/ReflectiveOperationException;)V
    .locals 3

    new-instance v0, Ljava/lang/RuntimeException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Unable to instantiate GlideModule implementation for "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v0
.end method

.method public static P(I)Ljava/lang/String;
    .locals 7

    invoke-static {p0}, Landroid/graphics/Color;->red(I)I

    move-result v0

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-static {p0}, Landroid/graphics/Color;->green(I)I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-static {p0}, Landroid/graphics/Color;->blue(I)I

    move-result v2

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-static {p0}, Landroid/graphics/Color;->alpha(I)I

    move-result p0

    int-to-double v3, p0

    const-wide v5, 0x406fe00000000000L    # 255.0

    div-double/2addr v3, v5

    invoke-static {v3, v4}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object p0

    const/4 v3, 0x4

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v4, 0x0

    aput-object v0, v3, v4

    const/4 v0, 0x1

    aput-object v1, v3, v0

    const/4 v0, 0x2

    aput-object v2, v3, v0

    const/4 v0, 0x3

    aput-object p0, v3, v0

    sget-object p0, Ly0/k0;->a:Ljava/lang/String;

    sget-object p0, Ljava/util/Locale;->US:Ljava/util/Locale;

    const-string v0, "rgba(%d,%d,%d,%.3f)"

    invoke-static {p0, v0, v3}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static final Q(Lcom/harindra/iptvpro/PlayerActivity;Z)V
    .locals 8

    const-string v0, "<this>"

    invoke-static {p0, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v0

    invoke-virtual {v0}, Lm6/m6;->a()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v1

    invoke-virtual {v1}, Lm6/m6;->e()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v2

    const/4 v3, 0x0

    move v4, v3

    :cond_0
    if-ge v4, v2, :cond_1

    invoke-virtual {v1, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    add-int/lit8 v4, v4, 0x1

    move-object v6, v5

    check-cast v6, Lm6/z5;

    iget-object v6, v6, Lm6/z5;->a:Ljava/lang/String;

    invoke-static {v6, v0}, La7/h;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_0

    goto :goto_0

    :cond_1
    const/4 v5, 0x0

    :goto_0
    check-cast v5, Lm6/z5;

    if-nez v5, :cond_2

    invoke-virtual {p0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object p1

    const-string v0, "No active profile"

    iget-object p0, p0, Lcom/harindra/iptvpro/PlayerActivity;->g2:Ljava/lang/String;

    invoke-virtual {p1, v0, p0, v3}, Lm6/m6;->o0(Ljava/lang/String;Ljava/lang/String;Z)V

    return-void

    :cond_2
    iget-object v0, v5, Lm6/z5;->a:Ljava/lang/String;

    iget-object v1, v5, Lm6/z5;->d:Ljava/lang/String;

    iget-object v2, v5, Lm6/z5;->b:Ljava/lang/String;

    const/4 v4, 0x1

    iput-boolean v4, p0, Lcom/harindra/iptvpro/PlayerActivity;->j3:Z

    :try_start_0
    iget-object v6, v5, Lm6/z5;->c:Lm6/n6;

    sget-object v7, Lm6/r2;->a:[I

    invoke-virtual {v6}, Ljava/lang/Enum;->ordinal()I

    move-result v6

    aget v6, v7, v6

    if-eq v6, v4, :cond_4

    const/4 v7, 0x2

    if-ne v6, v7, :cond_3

    new-instance v6, Lm6/w8;

    iget-object v7, v5, Lm6/z5;->e:Ljava/lang/String;

    iget-object v5, v5, Lm6/z5;->f:Ljava/lang/String;

    invoke-direct {v6, v2, v1, v7, v5}, Lm6/w8;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {p0, v6, v4, v0}, Lw7/d;->p(Lcom/harindra/iptvpro/PlayerActivity;Lm6/w8;ZLjava/lang/String;)V

    goto :goto_1

    :catchall_0
    move-exception p1

    goto :goto_5

    :catch_0
    move-exception p1

    goto :goto_4

    :cond_3
    new-instance p1, Lb5/f0;

    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    throw p1

    :cond_4
    invoke-static {p0, v1, v2, v4, v0}, Lcom/bumptech/glide/c;->n(Lcom/harindra/iptvpro/PlayerActivity;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;)V

    :goto_1
    invoke-virtual {p0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v0

    if-eqz p1, :cond_5

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "Auto-refreshed "

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :goto_2
    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    goto :goto_3

    :cond_5
    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "Refreshed "

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_2

    :goto_3
    iget-object v1, p0, Lcom/harindra/iptvpro/PlayerActivity;->g2:Ljava/lang/String;

    invoke-virtual {v0, p1, v1, v4}, Lm6/m6;->o0(Ljava/lang/String;Ljava/lang/String;Z)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    iput-boolean v3, p0, Lcom/harindra/iptvpro/PlayerActivity;->j3:Z

    invoke-static {p0}, Lc4/b0;->A(Lcom/harindra/iptvpro/PlayerActivity;)V

    return-void

    :goto_4
    :try_start_1
    invoke-virtual {p0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v0

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    if-nez p1, :cond_6

    const-string p1, "Refresh error"

    :cond_6
    iget-object v1, p0, Lcom/harindra/iptvpro/PlayerActivity;->g2:Ljava/lang/String;

    invoke-virtual {v0, p1, v1, v3}, Lm6/m6;->o0(Ljava/lang/String;Ljava/lang/String;Z)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    iput-boolean v3, p0, Lcom/harindra/iptvpro/PlayerActivity;->j3:Z

    invoke-static {p0}, Lc4/b0;->A(Lcom/harindra/iptvpro/PlayerActivity;)V

    return-void

    :goto_5
    iput-boolean v3, p0, Lcom/harindra/iptvpro/PlayerActivity;->j3:Z

    invoke-static {p0}, Lc4/b0;->A(Lcom/harindra/iptvpro/PlayerActivity;)V

    throw p1
.end method

.method public static final R(Lcom/harindra/iptvpro/PlayerActivity;)V
    .locals 5

    const-string v0, "NetworkCallback unregister warning: "

    iget-boolean v1, p0, Lcom/harindra/iptvpro/PlayerActivity;->b2:Z

    if-nez v1, :cond_0

    return-void

    :cond_0
    const/4 v1, 0x0

    :try_start_0
    iget-object v2, p0, Lcom/harindra/iptvpro/PlayerActivity;->a2:Landroid/net/ConnectivityManager;

    if-eqz v2, :cond_1

    iget-object v3, p0, Lcom/harindra/iptvpro/PlayerActivity;->S2:Lh5/q;

    invoke-virtual {v2, v3}, Landroid/net/ConnectivityManager;->unregisterNetworkCallback(Landroid/net/ConnectivityManager$NetworkCallback;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception v0

    goto :goto_2

    :catch_0
    move-exception v2

    goto :goto_1

    :cond_1
    :goto_0
    iput-boolean v1, p0, Lcom/harindra/iptvpro/PlayerActivity;->b2:Z

    return-void

    :goto_1
    :try_start_1
    const-string v3, "StreamX"

    invoke-virtual {v2}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v2

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v3, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    iput-boolean v1, p0, Lcom/harindra/iptvpro/PlayerActivity;->b2:Z

    return-void

    :goto_2
    iput-boolean v1, p0, Lcom/harindra/iptvpro/PlayerActivity;->b2:Z

    throw v0
.end method

.method public static S(II)Lb7/c;
    .locals 2

    const/high16 v0, -0x80000000

    if-gt p1, v0, :cond_0

    sget-object p0, Lb7/c;->n:Lb7/c;

    sget-object p0, Lb7/c;->n:Lb7/c;

    return-object p0

    :cond_0
    new-instance v0, Lb7/c;

    const/4 v1, 0x1

    sub-int/2addr p1, v1

    invoke-direct {v0, p0, p1, v1}, Lb7/a;-><init>(III)V

    return-object v0
.end method

.method public static a(Landroid/text/SpannableStringBuilder;Ljava/lang/Object;II)V
    .locals 6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-interface {p0, p2, p3, v0}, Landroid/text/Spanned;->getSpans(IILjava/lang/Class;)[Ljava/lang/Object;

    move-result-object v0

    array-length v1, v0

    const/4 v2, 0x0

    :goto_0
    const/16 v3, 0x21

    if-ge v2, v1, :cond_1

    aget-object v4, v0, v2

    invoke-interface {p0, v4}, Landroid/text/Spanned;->getSpanStart(Ljava/lang/Object;)I

    move-result v5

    if-ne v5, p2, :cond_0

    invoke-interface {p0, v4}, Landroid/text/Spanned;->getSpanEnd(Ljava/lang/Object;)I

    move-result v5

    if-ne v5, p3, :cond_0

    invoke-interface {p0, v4}, Landroid/text/Spanned;->getSpanFlags(Ljava/lang/Object;)I

    move-result v5

    if-ne v5, v3, :cond_0

    invoke-interface {p0, v4}, Landroid/text/Spannable;->removeSpan(Ljava/lang/Object;)V

    :cond_0
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_1
    invoke-interface {p0, p1, p2, p3, v3}, Landroid/text/Spannable;->setSpan(Ljava/lang/Object;III)V

    return-void
.end method

.method public static final b(Lcom/harindra/iptvpro/PlayerActivity;)V
    .locals 17

    move-object/from16 v0, p0

    const-string v1, "<this>"

    invoke-static {v0, v1}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->x()Z

    move-result v1

    if-nez v1, :cond_0

    goto/16 :goto_3

    :cond_0
    const v1, 0x7f0a0053

    invoke-virtual {v0, v1}, Li/k;->findViewById(I)Landroid/view/View;

    move-result-object v1

    new-instance v2, Ln6/d;

    const-string v3, "CHANNELS"

    invoke-direct {v2, v3, v1}, Ln6/d;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const v1, 0x7f0a004d

    invoke-virtual {v0, v1}, Li/k;->findViewById(I)Landroid/view/View;

    move-result-object v1

    new-instance v3, Ln6/d;

    const-string v4, "LIVE_TV"

    invoke-direct {v3, v4, v1}, Ln6/d;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const v1, 0x7f0a004e

    invoke-virtual {v0, v1}, Li/k;->findViewById(I)Landroid/view/View;

    move-result-object v1

    new-instance v4, Ln6/d;

    const-string v5, "MOVIES"

    invoke-direct {v4, v5, v1}, Ln6/d;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const v1, 0x7f0a004f

    invoke-virtual {v0, v1}, Li/k;->findViewById(I)Landroid/view/View;

    move-result-object v1

    new-instance v5, Ln6/d;

    const-string v6, "SERIES"

    invoke-direct {v5, v6, v1}, Ln6/d;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const v1, 0x7f0a0055

    invoke-virtual {v0, v1}, Li/k;->findViewById(I)Landroid/view/View;

    move-result-object v1

    new-instance v6, Ln6/d;

    const-string v7, "SEARCH"

    invoke-direct {v6, v7, v1}, Ln6/d;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const v1, 0x7f0a004a

    invoke-virtual {v0, v1}, Li/k;->findViewById(I)Landroid/view/View;

    move-result-object v1

    new-instance v7, Ln6/d;

    const-string v8, "ACCOUNTS"

    invoke-direct {v7, v8, v1}, Ln6/d;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const v1, 0x7f0a005a

    invoke-virtual {v0, v1}, Li/k;->findViewById(I)Landroid/view/View;

    move-result-object v1

    new-instance v8, Ln6/d;

    const-string v9, "XTREAM"

    invoke-direct {v8, v9, v1}, Ln6/d;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const v1, 0x7f0a0049

    invoke-virtual {v0, v1}, Li/k;->findViewById(I)Landroid/view/View;

    move-result-object v1

    new-instance v9, Ln6/d;

    const-string v10, "PLAYLIST"

    invoke-direct {v9, v10, v1}, Ln6/d;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const v1, 0x7f0a004c

    invoke-virtual {v0, v1}, Li/k;->findViewById(I)Landroid/view/View;

    move-result-object v1

    new-instance v10, Ln6/d;

    const-string v11, "SYNC"

    invoke-direct {v10, v11, v1}, Ln6/d;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const v1, 0x7f0a0045

    invoke-virtual {v0, v1}, Li/k;->findViewById(I)Landroid/view/View;

    move-result-object v1

    new-instance v11, Ln6/d;

    const-string v12, "AUDIO_HD"

    invoke-direct {v11, v12, v1}, Ln6/d;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const v1, 0x7f0a0052

    invoke-virtual {v0, v1}, Li/k;->findViewById(I)Landroid/view/View;

    move-result-object v1

    new-instance v12, Ln6/d;

    const-string v13, "STUDIO_4D"

    invoke-direct {v12, v13, v1}, Ln6/d;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const v1, 0x7f0a0047

    invoke-virtual {v0, v1}, Li/k;->findViewById(I)Landroid/view/View;

    move-result-object v1

    new-instance v13, Ln6/d;

    const-string v14, "EPG"

    invoke-direct {v13, v14, v1}, Ln6/d;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const v1, 0x7f0a0051

    invoke-virtual {v0, v1}, Li/k;->findViewById(I)Landroid/view/View;

    move-result-object v1

    new-instance v14, Ln6/d;

    const-string v15, "SLEEP"

    invoke-direct {v14, v15, v1}, Ln6/d;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const v1, 0x7f0a0044

    invoke-virtual {v0, v1}, Li/k;->findViewById(I)Landroid/view/View;

    move-result-object v1

    new-instance v15, Ln6/d;

    move-object/from16 v16, v2

    const-string v2, "ASPECT"

    invoke-direct {v15, v2, v1}, Ln6/d;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/16 v1, 0xe

    new-array v1, v1, [Ln6/d;

    const/4 v2, 0x0

    aput-object v16, v1, v2

    const/16 v16, 0x1

    aput-object v3, v1, v16

    const/4 v3, 0x2

    aput-object v4, v1, v3

    const/4 v3, 0x3

    aput-object v5, v1, v3

    const/4 v3, 0x4

    aput-object v6, v1, v3

    const/4 v3, 0x5

    aput-object v7, v1, v3

    const/4 v3, 0x6

    aput-object v8, v1, v3

    const/4 v3, 0x7

    aput-object v9, v1, v3

    const/16 v3, 0x8

    aput-object v10, v1, v3

    const/16 v4, 0x9

    aput-object v11, v1, v4

    const/16 v4, 0xa

    aput-object v12, v1, v4

    const/16 v4, 0xb

    aput-object v13, v1, v4

    const/16 v4, 0xc

    aput-object v14, v1, v4

    const/16 v4, 0xd

    aput-object v15, v1, v4

    invoke-static {v1}, Lo6/v;->N([Ln6/d;)Ljava/util/Map;

    move-result-object v1

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v4

    iget-object v5, v0, Lcom/harindra/iptvpro/PlayerActivity;->g2:Ljava/lang/String;

    invoke-virtual {v4, v5}, Lm6/m6;->x(Ljava/lang/String;)Ljava/util/HashSet;

    move-result-object v4

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v5

    iget-object v6, v0, Lcom/harindra/iptvpro/PlayerActivity;->g2:Ljava/lang/String;

    invoke-virtual {v5, v6}, Lm6/m6;->P(Ljava/lang/String;)Ljava/util/List;

    move-result-object v5

    const v6, 0x7f0a0048

    invoke-virtual {v0, v6}, Li/k;->findViewById(I)Landroid/view/View;

    move-result-object v6

    const/4 v7, 0x0

    if-eqz v6, :cond_1

    invoke-virtual {v6}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v6

    goto :goto_0

    :cond_1
    move-object v6, v7

    :goto_0
    instance-of v8, v6, Landroid/view/ViewGroup;

    if-eqz v8, :cond_2

    move-object v7, v6

    check-cast v7, Landroid/view/ViewGroup;

    :cond_2
    if-eqz v7, :cond_7

    invoke-interface {v5}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :cond_3
    :goto_1
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_6

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    invoke-interface {v1, v6}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Landroid/view/View;

    if-nez v8, :cond_4

    goto :goto_1

    :cond_4
    invoke-virtual {v4, v6}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_5

    move v6, v3

    goto :goto_2

    :cond_5
    move v6, v2

    :goto_2
    invoke-virtual {v8, v6}, Landroid/view/View;->setVisibility(I)V

    invoke-virtual {v8}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v6

    if-ne v6, v7, :cond_3

    invoke-virtual {v7, v8}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    invoke-virtual {v7, v8}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    goto :goto_1

    :cond_6
    const v1, 0x7f0a0050

    invoke-virtual {v0, v1}, Li/k;->findViewById(I)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_7

    invoke-virtual {v0, v2}, Landroid/view/View;->setVisibility(I)V

    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v1

    if-ne v1, v7, :cond_7

    invoke-virtual {v7, v0}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    invoke-virtual {v7, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    :cond_7
    :goto_3
    return-void
.end method

.method public static final c(Lcom/harindra/iptvpro/PlayerActivity;)Ljava/util/List;
    .locals 48

    move-object/from16 v0, p0

    const-string v1, "<this>"

    invoke-static {v0, v1}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v1, Ln6/h;

    new-instance v2, Lm6/v1;

    const/16 v3, 0xd

    invoke-direct {v2, v0, v3}, Lm6/v1;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const-string v4, "General & Startup"

    const-string v5, "startup wizard boot resume screensaver"

    invoke-direct {v1, v4, v5, v2}, Ln6/h;-><init>(Ljava/io/Serializable;Ljava/io/Serializable;Ljava/lang/Object;)V

    new-instance v2, Ln6/h;

    new-instance v4, Lm6/v1;

    const/16 v5, 0x19

    invoke-direct {v4, v0, v5}, Lm6/v1;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const-string v6, "Player & Background Playback"

    const-string v7, "player playback seek speed lock external osd queue up next play later"

    invoke-direct {v2, v6, v7, v4}, Ln6/h;-><init>(Ljava/io/Serializable;Ljava/io/Serializable;Ljava/lang/Object;)V

    new-instance v4, Ln6/h;

    new-instance v6, Lm6/l2;

    const/4 v7, 0x1

    invoke-direct {v6, v0, v7}, Lm6/l2;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const-string v8, "Audio, Delay & Passthrough"

    const-string v9, "audio delay passthrough offload boost track"

    invoke-direct {v4, v8, v9, v6}, Ln6/h;-><init>(Ljava/io/Serializable;Ljava/io/Serializable;Ljava/lang/Object;)V

    new-instance v6, Ln6/h;

    new-instance v8, Lm6/l2;

    const/4 v9, 0x2

    invoke-direct {v8, v0, v9}, Lm6/l2;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const-string v10, "Subtitles & Delay"

    const-string v11, "subtitle caption delay sync external srt vtt ass ttml import file url"

    invoke-direct {v6, v10, v11, v8}, Ln6/h;-><init>(Ljava/io/Serializable;Ljava/io/Serializable;Ljava/lang/Object;)V

    new-instance v8, Ln6/h;

    new-instance v10, Lm6/l2;

    const/4 v11, 0x3

    invoke-direct {v10, v0, v11}, Lm6/l2;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const-string v12, "Video & HDR Format"

    const-string v13, "video quality resolution hdr 4k aspect"

    invoke-direct {v8, v12, v13, v10}, Ln6/h;-><init>(Ljava/io/Serializable;Ljava/io/Serializable;Ljava/lang/Object;)V

    new-instance v10, Ln6/h;

    new-instance v12, Lm6/l2;

    const/4 v13, 0x4

    invoke-direct {v12, v0, v13}, Lm6/l2;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const-string v14, "Live TV & Blacklist"

    const-string v15, "live tv channel sort hide blacklist preview"

    invoke-direct {v10, v14, v15, v12}, Ln6/h;-><init>(Ljava/io/Serializable;Ljava/io/Serializable;Ljava/lang/Object;)V

    new-instance v12, Ln6/h;

    new-instance v14, Lm6/l2;

    const/4 v15, 0x5

    invoke-direct {v14, v0, v15}, Lm6/l2;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    move/from16 v16, v3

    const-string v3, "Movies & VOD"

    move/from16 v17, v7

    const-string v7, "movies vod poster watchlist"

    invoke-direct {v12, v3, v7, v14}, Ln6/h;-><init>(Ljava/io/Serializable;Ljava/io/Serializable;Ljava/lang/Object;)V

    new-instance v3, Ln6/h;

    new-instance v7, Lm6/l2;

    const/4 v14, 0x7

    invoke-direct {v7, v0, v14}, Lm6/l2;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    move/from16 v18, v9

    const-string v9, "Series & Auto-Next"

    move/from16 v19, v11

    const-string v11, "series seasons episodes auto next"

    invoke-direct {v3, v9, v11, v7}, Ln6/h;-><init>(Ljava/io/Serializable;Ljava/io/Serializable;Ljava/lang/Object;)V

    new-instance v7, Ln6/h;

    new-instance v9, Lm6/l2;

    const/16 v11, 0x8

    invoke-direct {v9, v0, v11}, Lm6/l2;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    move/from16 v20, v11

    const-string v11, "EPG TV Guide"

    move/from16 v21, v13

    const-string v13, "epg guide xmltv reminder timeline programme schedule conflict overlap"

    invoke-direct {v7, v11, v13, v9}, Ln6/h;-><init>(Ljava/io/Serializable;Ljava/io/Serializable;Ljava/lang/Object;)V

    new-instance v9, Ln6/h;

    new-instance v11, Lm6/l2;

    const/16 v13, 0x9

    invoke-direct {v11, v0, v13}, Lm6/l2;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    move/from16 v22, v13

    const-string v13, "Playlists & WorkManager Auto-Refresh"

    move/from16 v23, v14

    const-string v14, "playlist refresh schedule interval duplicate health"

    invoke-direct {v9, v13, v14, v11}, Ln6/h;-><init>(Ljava/io/Serializable;Ljava/io/Serializable;Ljava/lang/Object;)V

    new-instance v11, Ln6/h;

    new-instance v13, Lm6/v1;

    const/16 v14, 0xe

    invoke-direct {v13, v0, v14}, Lm6/v1;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    move/from16 v24, v14

    const-string v14, "Network & Connectivity"

    move/from16 v25, v15

    const-string v15, "network dns buffer timeout recovery"

    invoke-direct {v11, v14, v15, v13}, Ln6/h;-><init>(Ljava/io/Serializable;Ljava/io/Serializable;Ljava/lang/Object;)V

    new-instance v13, Ln6/h;

    new-instance v14, Lm6/v1;

    const/16 v15, 0x10

    invoke-direct {v14, v0, v15}, Lm6/v1;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    move/from16 v26, v15

    const-string v15, "Performance & 512MB Guard"

    const-string v5, "performance ram memory low adaptive benchmark 4gb high"

    invoke-direct {v13, v15, v5, v14}, Ln6/h;-><init>(Ljava/io/Serializable;Ljava/io/Serializable;Ljava/lang/Object;)V

    new-instance v5, Ln6/h;

    new-instance v14, Lm6/v1;

    const/16 v15, 0x11

    invoke-direct {v14, v0, v15}, Lm6/v1;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    move/from16 v27, v15

    const-string v15, "Recycle Bin"

    move-object/from16 v28, v1

    const-string v1, "recycle bin trash deleted restore undo account profile playlist collection"

    invoke-direct {v5, v15, v1, v14}, Ln6/h;-><init>(Ljava/io/Serializable;Ljava/io/Serializable;Ljava/lang/Object;)V

    new-instance v1, Ln6/h;

    new-instance v14, Lm6/v1;

    const/16 v15, 0x12

    invoke-direct {v14, v0, v15}, Lm6/v1;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    move/from16 v29, v15

    const-string v15, "Remote Control Shortcuts"

    move-object/from16 v30, v2

    const-string v2, "remote key red green yellow blue long press ok"

    invoke-direct {v1, v15, v2, v14}, Ln6/h;-><init>(Ljava/io/Serializable;Ljava/io/Serializable;Ljava/lang/Object;)V

    new-instance v2, Ln6/h;

    new-instance v14, Lm6/v1;

    const/16 v15, 0x13

    invoke-direct {v14, v0, v15}, Lm6/v1;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    move/from16 v31, v15

    const-string v15, "Interface, 4D Themes & Overscan"

    move-object/from16 v32, v1

    const-string v1, "interface theme amoled density overscan clock"

    invoke-direct {v2, v15, v1, v14}, Ln6/h;-><init>(Ljava/io/Serializable;Ljava/io/Serializable;Ljava/lang/Object;)V

    new-instance v1, Ln6/h;

    new-instance v14, Lm6/v1;

    const/16 v15, 0x14

    invoke-direct {v14, v0, v15}, Lm6/v1;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    move/from16 v33, v15

    const-string v15, "Home Screen Rows"

    move-object/from16 v34, v2

    const-string v2, "home rows customize reorder hide"

    invoke-direct {v1, v15, v2, v14}, Ln6/h;-><init>(Ljava/io/Serializable;Ljava/io/Serializable;Ljava/lang/Object;)V

    new-instance v2, Ln6/h;

    new-instance v14, Lm6/v1;

    const/16 v15, 0x15

    invoke-direct {v14, v0, v15}, Lm6/v1;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    move/from16 v35, v15

    const-string v15, "Navigation / Sidebar Icons"

    move-object/from16 v36, v1

    const-string v1, "sidebar navigation bar icons reorder hide"

    invoke-direct {v2, v15, v1, v14}, Ln6/h;-><init>(Ljava/io/Serializable;Ljava/io/Serializable;Ljava/lang/Object;)V

    new-instance v1, Ln6/h;

    new-instance v14, Lm6/v1;

    const/16 v15, 0x16

    invoke-direct {v14, v0, v15}, Lm6/v1;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    move/from16 v37, v15

    const-string v15, "Profiles & Multi-Account"

    move-object/from16 v38, v2

    const-string v2, "profiles account isolation xtream m3u"

    invoke-direct {v1, v15, v2, v14}, Ln6/h;-><init>(Ljava/io/Serializable;Ljava/io/Serializable;Ljava/lang/Object;)V

    new-instance v2, Ln6/h;

    new-instance v14, Lm6/v1;

    const/16 v15, 0x17

    invoke-direct {v14, v0, v15}, Lm6/v1;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    move/from16 v39, v15

    const-string v15, "Parental Controls & PIN"

    move-object/from16 v40, v1

    const-string v1, "parental pin lock category"

    invoke-direct {v2, v15, v1, v14}, Ln6/h;-><init>(Ljava/io/Serializable;Ljava/io/Serializable;Ljava/lang/Object;)V

    new-instance v1, Ln6/h;

    new-instance v14, Lm6/v1;

    const/16 v15, 0x18

    invoke-direct {v14, v0, v15}, Lm6/v1;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    move/from16 v41, v15

    const-string v15, "Privacy & History"

    move-object/from16 v42, v2

    const-string v2, "privacy clear search watch history credentials"

    invoke-direct {v1, v15, v2, v14}, Ln6/h;-><init>(Ljava/io/Serializable;Ljava/io/Serializable;Ljava/lang/Object;)V

    new-instance v2, Ln6/h;

    new-instance v14, Lm6/v1;

    const/16 v15, 0x1a

    invoke-direct {v14, v0, v15}, Lm6/v1;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const-string v15, "Storage & Cache Manager"

    move-object/from16 v43, v1

    const-string v1, "storage cache sxb2 epg image clear"

    invoke-direct {v2, v15, v1, v14}, Ln6/h;-><init>(Ljava/io/Serializable;Ljava/io/Serializable;Ljava/lang/Object;)V

    new-instance v1, Ln6/h;

    new-instance v14, Lm6/v1;

    const/16 v15, 0x1b

    invoke-direct {v14, v0, v15}, Lm6/v1;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const-string v15, "Backup & Restore (SXBK_V20 / AES-256)"

    move-object/from16 v44, v2

    const-string v2, "backup restore password export import reset"

    invoke-direct {v1, v15, v2, v14}, Ln6/h;-><init>(Ljava/io/Serializable;Ljava/io/Serializable;Ljava/lang/Object;)V

    new-instance v2, Ln6/h;

    new-instance v14, Lm6/v1;

    const/16 v15, 0x1c

    invoke-direct {v14, v0, v15}, Lm6/v1;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const-string v15, "Accessibility & Viewing Comfort"

    move-object/from16 v45, v1

    const-string v1, "accessibility contrast reduced motion"

    invoke-direct {v2, v15, v1, v14}, Ln6/h;-><init>(Ljava/io/Serializable;Ljava/io/Serializable;Ljava/lang/Object;)V

    new-instance v1, Ln6/h;

    new-instance v14, Lm6/v1;

    const/16 v15, 0x1d

    invoke-direct {v14, v0, v15}, Lm6/v1;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const-string v15, "App Health & Diagnostics"

    move-object/from16 v46, v2

    const-string v2, "health diagnostics telemetry capabilities"

    invoke-direct {v1, v15, v2, v14}, Ln6/h;-><init>(Ljava/io/Serializable;Ljava/io/Serializable;Ljava/lang/Object;)V

    new-instance v2, Ln6/h;

    new-instance v14, Lm6/l2;

    const/4 v15, 0x0

    invoke-direct {v14, v0, v15}, Lm6/l2;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const-string v0, "About & Legal Disclaimer"

    move/from16 v47, v15

    const-string v15, "about version legal disclaimer"

    invoke-direct {v2, v0, v15, v14}, Ln6/h;-><init>(Ljava/io/Serializable;Ljava/io/Serializable;Ljava/lang/Object;)V

    const/16 v0, 0x19

    new-array v0, v0, [Ln6/h;

    aput-object v28, v0, v47

    aput-object v30, v0, v17

    aput-object v4, v0, v18

    aput-object v6, v0, v19

    aput-object v8, v0, v21

    aput-object v10, v0, v25

    const/4 v4, 0x6

    aput-object v12, v0, v4

    aput-object v3, v0, v23

    aput-object v7, v0, v20

    aput-object v9, v0, v22

    const/16 v3, 0xa

    aput-object v11, v0, v3

    const/16 v3, 0xb

    aput-object v13, v0, v3

    const/16 v3, 0xc

    aput-object v5, v0, v3

    aput-object v32, v0, v16

    aput-object v34, v0, v24

    const/16 v3, 0xf

    aput-object v36, v0, v3

    aput-object v38, v0, v26

    aput-object v40, v0, v27

    aput-object v42, v0, v29

    aput-object v43, v0, v31

    aput-object v44, v0, v33

    aput-object v45, v0, v35

    aput-object v46, v0, v37

    aput-object v1, v0, v39

    aput-object v2, v0, v41

    invoke-static {v0}, Lo6/k;->K([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public static final d(Lcom/harindra/iptvpro/PlayerActivity;Lm6/h0;)Ljava/util/List;
    .locals 13

    const-string v0, "<this>"

    invoke-static {p0, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "section"

    invoke-static {p1, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, Lcom/harindra/iptvpro/PlayerActivity;->c2:Lm6/n6;

    sget-object v1, Lm6/n6;->XTREAM:Lm6/n6;

    const-string v2, "CONTINUE WATCHING"

    const-string v3, "RECENTLY ADDED"

    const-string v4, "FAVORITES / WATCHLIST"

    const/4 v5, 0x0

    const/4 v6, 0x1

    if-eq v0, v1, :cond_0

    new-instance p0, Lm6/o8;

    invoke-direct {p0, v5, v4, v6}, Lm6/o8;-><init>(ILjava/lang/String;Z)V

    new-instance p1, Lm6/o8;

    invoke-direct {p1, v5, v3, v6}, Lm6/o8;-><init>(ILjava/lang/String;Z)V

    new-instance v0, Lm6/o8;

    invoke-direct {v0, v5, v2, v6}, Lm6/o8;-><init>(ILjava/lang/String;Z)V

    const/4 v1, 0x3

    new-array v1, v1, [Lm6/o8;

    aput-object p0, v1, v5

    aput-object p1, v1, v6

    const/4 p0, 0x2

    aput-object v0, v1, p0

    invoke-static {v1}, Lo6/k;->K([Ljava/lang/Object;)Ljava/util/List;

    move-result-object p0

    return-object p0

    :cond_0
    invoke-virtual {p0}, Lcom/harindra/iptvpro/PlayerActivity;->x()Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-virtual {p0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v0

    iget-object v1, p0, Lcom/harindra/iptvpro/PlayerActivity;->g2:Ljava/lang/String;

    invoke-virtual {v0, v1}, Lm6/m6;->p(Ljava/lang/String;)Ljava/util/List;

    move-result-object v0

    goto :goto_0

    :cond_1
    sget-object v0, Lo6/r;->k:Lo6/r;

    :goto_0
    sget-object v1, Lm6/h0;->MOVIES:Lm6/h0;

    const/16 v7, 0x40

    sget-object v8, Lo6/t;->k:Lo6/t;

    const/4 v9, 0x0

    if-ne p1, v1, :cond_11

    invoke-virtual {p0}, Lcom/harindra/iptvpro/PlayerActivity;->x()Z

    move-result p1

    if-eqz p1, :cond_2

    invoke-virtual {p0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object p1

    iget-object v1, p0, Lcom/harindra/iptvpro/PlayerActivity;->g2:Ljava/lang/String;

    invoke-virtual {p1, v1}, Lm6/m6;->B(Ljava/lang/String;)Ljava/util/Set;

    move-result-object v8

    :cond_2
    iget-object p1, p0, Lcom/harindra/iptvpro/PlayerActivity;->w1:Ljava/lang/Object;

    if-eqz p1, :cond_3

    invoke-interface {p1}, Ljava/util/Collection;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_3

    move v1, v5

    goto :goto_2

    :cond_3
    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    move v1, v5

    :cond_4
    :goto_1
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_7

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Lm6/n;

    iget-object v11, v10, Lm6/n;->a:Ljava/lang/String;

    invoke-interface {v8, v11}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v11

    if-nez v11, :cond_5

    iget-object v11, p0, Lcom/harindra/iptvpro/PlayerActivity;->Z2:Ljava/util/Set;

    iget-object v10, v10, Lm6/n;->a:Ljava/lang/String;

    invoke-interface {v11, v10}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_4

    :cond_5
    add-int/lit8 v1, v1, 0x1

    if-ltz v1, :cond_6

    goto :goto_1

    :cond_6
    invoke-static {}, Lo6/k;->M()V

    throw v9

    :cond_7
    :goto_2
    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    move-result p1

    if-eqz p1, :cond_8

    move v0, v5

    goto :goto_4

    :cond_8
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    move v0, v5

    :cond_9
    :goto_3
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_b

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lm6/n1;

    iget-object v10, v8, Lm6/n1;->e:Lm6/c0;

    sget-object v11, Lm6/c0;->XTREAM_VOD_MOVIE:Lm6/c0;

    if-ne v10, v11, :cond_9

    iget-object v10, p0, Lcom/harindra/iptvpro/PlayerActivity;->x1:Ljava/lang/Object;

    iget-object v8, v8, Lm6/n1;->a:Ljava/lang/String;

    invoke-interface {v10, v8}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_9

    add-int/lit8 v0, v0, 0x1

    if-ltz v0, :cond_a

    goto :goto_3

    :cond_a
    invoke-static {}, Lo6/k;->M()V

    throw v9

    :cond_b
    :goto_4
    new-instance p1, Ljava/util/LinkedHashMap;

    invoke-direct {p1, v7}, Ljava/util/LinkedHashMap;-><init>(I)V

    iget-object v7, p0, Lcom/harindra/iptvpro/PlayerActivity;->w1:Ljava/lang/Object;

    invoke-interface {v7}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v7

    :cond_c
    :goto_5
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_f

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lm6/n;

    iget-object v9, v8, Lm6/n;->i:Lm6/c0;

    sget-object v10, Lm6/c0;->XTREAM_VOD_MOVIE:Lm6/c0;

    if-ne v9, v10, :cond_c

    iget-object v8, v8, Lm6/n;->d:Ljava/lang/String;

    invoke-static {v8}, Le7/e;->o0(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-static {v8}, Le7/e;->Y(Ljava/lang/CharSequence;)Z

    move-result v9

    if-eqz v9, :cond_d

    const-string v8, "Movies"

    :cond_d
    invoke-virtual {p1, v8}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/Integer;

    if-eqz v9, :cond_e

    invoke-virtual {v9}, Ljava/lang/Integer;->intValue()I

    move-result v9

    goto :goto_6

    :cond_e
    move v9, v5

    :goto_6
    add-int/2addr v9, v6

    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    invoke-interface {p1, v8, v9}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_5

    :cond_f
    new-instance v7, Ljava/util/ArrayList;

    invoke-virtual {p1}, Ljava/util/AbstractMap;->size()I

    move-result v8

    add-int/lit8 v8, v8, 0x4

    invoke-direct {v7, v8}, Ljava/util/ArrayList;-><init>(I)V

    new-instance v8, Lm6/o8;

    invoke-direct {v8, v1, v4, v6}, Lm6/o8;-><init>(ILjava/lang/String;Z)V

    invoke-virtual {v7, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-instance v1, Lm6/o8;

    iget-object v4, p0, Lcom/harindra/iptvpro/PlayerActivity;->w1:Ljava/lang/Object;

    invoke-interface {v4}, Ljava/util/List;->size()I

    move-result v4

    invoke-direct {v1, v4, v3, v6}, Lm6/o8;-><init>(ILjava/lang/String;Z)V

    invoke-virtual {v7, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-instance v1, Lm6/o8;

    invoke-direct {v1, v0, v2, v6}, Lm6/o8;-><init>(ILjava/lang/String;Z)V

    invoke-virtual {v7, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-instance v0, Lm6/o8;

    iget-object p0, p0, Lcom/harindra/iptvpro/PlayerActivity;->w1:Ljava/lang/Object;

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result p0

    const-string v1, "ALL MOVIES"

    invoke-direct {v0, p0, v1, v6}, Lm6/o8;-><init>(ILjava/lang/String;Z)V

    invoke-virtual {v7, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {p1}, Ljava/util/LinkedHashMap;->entrySet()Ljava/util/Set;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_7
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result p1

    if-eqz p1, :cond_10

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/util/Map$Entry;

    invoke-interface {p1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    invoke-interface {p1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Number;

    invoke-virtual {p1}, Ljava/lang/Number;->intValue()I

    move-result p1

    new-instance v1, Lm6/o8;

    invoke-direct {v1, p1, v0, v5}, Lm6/o8;-><init>(ILjava/lang/String;Z)V

    invoke-virtual {v7, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_7

    :cond_10
    return-object v7

    :cond_11
    invoke-virtual {p0}, Lcom/harindra/iptvpro/PlayerActivity;->x()Z

    move-result p1

    if-eqz p1, :cond_12

    invoke-virtual {p0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object p1

    iget-object v1, p0, Lcom/harindra/iptvpro/PlayerActivity;->g2:Ljava/lang/String;

    invoke-virtual {p1, v1}, Lm6/m6;->O(Ljava/lang/String;)Ljava/util/Set;

    move-result-object v8

    :cond_12
    iget-object p1, p0, Lcom/harindra/iptvpro/PlayerActivity;->y1:Ljava/lang/Object;

    if-eqz p1, :cond_13

    invoke-interface {p1}, Ljava/util/Collection;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_13

    move v1, v5

    goto :goto_9

    :cond_13
    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    move v1, v5

    :cond_14
    :goto_8
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_17

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Lm6/m7;

    iget-object v11, v10, Lm6/m7;->a:Ljava/lang/String;

    invoke-interface {v8, v11}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v11

    if-nez v11, :cond_15

    iget-object v10, v10, Lm6/m7;->b:Ljava/lang/String;

    invoke-interface {v8, v10}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_14

    :cond_15
    add-int/lit8 v1, v1, 0x1

    if-ltz v1, :cond_16

    goto :goto_8

    :cond_16
    invoke-static {}, Lo6/k;->M()V

    throw v9

    :cond_17
    :goto_9
    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_18
    :goto_a
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_19

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    move-object v10, v8

    check-cast v10, Lm6/n1;

    iget-object v10, v10, Lm6/n1;->e:Lm6/c0;

    sget-object v11, Lm6/c0;->XTREAM_SERIES_EPISODE:Lm6/c0;

    if-ne v10, v11, :cond_18

    invoke-virtual {p1, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_a

    :cond_19
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result v8

    move v10, v5

    :cond_1a
    :goto_b
    if-ge v10, v8, :cond_1c

    invoke-virtual {p1, v10}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v11

    add-int/lit8 v10, v10, 0x1

    check-cast v11, Lm6/n1;

    iget-object v11, v11, Lm6/n1;->f:Ljava/lang/String;

    invoke-static {v11}, Le7/e;->Y(Ljava/lang/CharSequence;)Z

    move-result v12

    if-nez v12, :cond_1b

    goto :goto_c

    :cond_1b
    move-object v11, v9

    :goto_c
    if-eqz v11, :cond_1a

    invoke-virtual {v0, v11}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_b

    :cond_1c
    invoke-static {v0}, Lo6/j;->n0(Ljava/lang/Iterable;)Ljava/util/Set;

    move-result-object p1

    iget-object v0, p0, Lcom/harindra/iptvpro/PlayerActivity;->y1:Ljava/lang/Object;

    if-eqz v0, :cond_1d

    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    move-result v8

    if-eqz v8, :cond_1d

    move v8, v5

    goto :goto_e

    :cond_1d
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v0

    move v8, v5

    :cond_1e
    :goto_d
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_20

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Lm6/m7;

    iget-object v10, v10, Lm6/m7;->a:Ljava/lang/String;

    invoke-interface {p1, v10}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_1e

    add-int/lit8 v8, v8, 0x1

    if-ltz v8, :cond_1f

    goto :goto_d

    :cond_1f
    invoke-static {}, Lo6/k;->M()V

    throw v9

    :cond_20
    :goto_e
    new-instance p1, Ljava/util/LinkedHashMap;

    invoke-direct {p1, v7}, Ljava/util/LinkedHashMap;-><init>(I)V

    iget-object v0, p0, Lcom/harindra/iptvpro/PlayerActivity;->y1:Ljava/lang/Object;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_f
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_23

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lm6/m7;

    iget-object v7, v7, Lm6/m7;->d:Ljava/lang/String;

    invoke-static {v7}, Le7/e;->o0(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-static {v7}, Le7/e;->Y(Ljava/lang/CharSequence;)Z

    move-result v9

    if-eqz v9, :cond_21

    const-string v7, "Series"

    :cond_21
    invoke-virtual {p1, v7}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/Integer;

    if-eqz v9, :cond_22

    invoke-virtual {v9}, Ljava/lang/Integer;->intValue()I

    move-result v9

    goto :goto_10

    :cond_22
    move v9, v5

    :goto_10
    add-int/2addr v9, v6

    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    invoke-interface {p1, v7, v9}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_f

    :cond_23
    new-instance v0, Ljava/util/ArrayList;

    invoke-virtual {p1}, Ljava/util/AbstractMap;->size()I

    move-result v7

    add-int/lit8 v7, v7, 0x4

    invoke-direct {v0, v7}, Ljava/util/ArrayList;-><init>(I)V

    new-instance v7, Lm6/o8;

    invoke-direct {v7, v1, v4, v6}, Lm6/o8;-><init>(ILjava/lang/String;Z)V

    invoke-virtual {v0, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-instance v1, Lm6/o8;

    iget-object v4, p0, Lcom/harindra/iptvpro/PlayerActivity;->y1:Ljava/lang/Object;

    invoke-interface {v4}, Ljava/util/List;->size()I

    move-result v4

    invoke-direct {v1, v4, v3, v6}, Lm6/o8;-><init>(ILjava/lang/String;Z)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-instance v1, Lm6/o8;

    invoke-direct {v1, v8, v2, v6}, Lm6/o8;-><init>(ILjava/lang/String;Z)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-instance v1, Lm6/o8;

    iget-object p0, p0, Lcom/harindra/iptvpro/PlayerActivity;->y1:Ljava/lang/Object;

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result p0

    const-string v2, "ALL SERIES"

    invoke-direct {v1, p0, v2, v6}, Lm6/o8;-><init>(ILjava/lang/String;Z)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {p1}, Ljava/util/LinkedHashMap;->entrySet()Ljava/util/Set;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_11
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result p1

    if-eqz p1, :cond_24

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/util/Map$Entry;

    invoke-interface {p1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-interface {p1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Number;

    invoke-virtual {p1}, Ljava/lang/Number;->intValue()I

    move-result p1

    new-instance v2, Lm6/o8;

    invoke-direct {v2, p1, v1, v5}, Lm6/o8;-><init>(ILjava/lang/String;Z)V

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_11

    :cond_24
    return-object v0
.end method

.method public static e(ZIIJJIZJJJJ)J
    .locals 3

    const-string v0, "backoffPolicy"

    invoke-static {v0, p2}, La0/h;->B(Ljava/lang/String;I)V

    const-wide v0, 0x7fffffffffffffffL

    cmp-long v2, p15, v0

    if-eqz v2, :cond_2

    if-eqz p8, :cond_2

    if-nez p7, :cond_0

    goto :goto_0

    :cond_0
    const-wide/32 p0, 0xdbba0

    add-long/2addr p5, p0

    cmp-long p0, p15, p5

    if-gez p0, :cond_1

    return-wide p5

    :cond_1
    :goto_0
    return-wide p15

    :cond_2
    if-eqz p0, :cond_5

    const/4 p0, 0x2

    if-ne p2, p0, :cond_3

    int-to-long p0, p1

    mul-long/2addr p3, p0

    goto :goto_1

    :cond_3
    long-to-float p0, p3

    add-int/lit8 p1, p1, -0x1

    invoke-static {p0, p1}, Ljava/lang/Math;->scalb(FI)F

    move-result p0

    float-to-long p3, p0

    :goto_1
    const-wide/32 p0, 0x112a880

    cmp-long p2, p3, p0

    if-lez p2, :cond_4

    move-wide p3, p0

    :cond_4
    add-long/2addr p5, p3

    return-wide p5

    :cond_5
    if-eqz p8, :cond_8

    if-nez p7, :cond_6

    add-long/2addr p5, p9

    goto :goto_2

    :cond_6
    add-long p5, p5, p13

    :goto_2
    cmp-long p0, p11, p13

    if-eqz p0, :cond_7

    if-nez p7, :cond_7

    sub-long p0, p13, p11

    add-long/2addr p0, p5

    return-wide p0

    :cond_7
    return-wide p5

    :cond_8
    const-wide/16 p0, -0x1

    cmp-long p0, p5, p0

    if-nez p0, :cond_9

    return-wide v0

    :cond_9
    add-long/2addr p5, p9

    return-wide p5
.end method

.method public static final f(Lcom/harindra/iptvpro/PlayerActivity;)V
    .locals 4

    const-string v0, "<this>"

    invoke-static {p0, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-wide v0, p0, Lcom/harindra/iptvpro/PlayerActivity;->m3:J

    const-wide/16 v2, 0x1

    add-long/2addr v0, v2

    iput-wide v0, p0, Lcom/harindra/iptvpro/PlayerActivity;->m3:J

    iget-object p0, p0, Lcom/harindra/iptvpro/PlayerActivity;->k3:Landroid/widget/TextView;

    if-eqz p0, :cond_0

    const/16 v0, 0x8

    invoke-virtual {p0, v0}, Landroid/view/View;->setVisibility(I)V

    :cond_0
    return-void
.end method

.method public static final g(Lcom/harindra/iptvpro/PlayerActivity;)V
    .locals 4

    invoke-virtual {p0}, Lcom/harindra/iptvpro/PlayerActivity;->L()Landroid/view/View;

    move-result-object v0

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    sget-object v0, Lm6/h0;->LIVE_TV:Lm6/h0;

    invoke-static {p0, v0}, Ll3/e;->V(Lcom/harindra/iptvpro/PlayerActivity;Lm6/h0;)V

    invoke-virtual {p0}, Lcom/harindra/iptvpro/PlayerActivity;->F()Landroid/widget/TextView;

    move-result-object v0

    iget-object v1, p0, Lcom/harindra/iptvpro/PlayerActivity;->T2:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "RAM PLAYER v19.0 \u2022 LIVE TV ("

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ")"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v0, p0, Lcom/harindra/iptvpro/PlayerActivity;->E1:Lm6/x1;

    sget-object v1, Lm6/x1;->LIVE_TV:Lm6/x1;

    if-eq v0, v1, :cond_1

    iget-object v0, p0, Lcom/harindra/iptvpro/PlayerActivity;->I:Ld1/k0;

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    invoke-virtual {v0, v2}, Ld1/k0;->i(Z)V

    invoke-virtual {v0}, Ld1/k0;->stop()V

    invoke-virtual {v0}, Le6/e;->z()V

    :cond_0
    const-string v0, ""

    iput-object v0, p0, Lcom/harindra/iptvpro/PlayerActivity;->q2:Ljava/lang/String;

    invoke-virtual {p0, v1}, Lcom/harindra/iptvpro/PlayerActivity;->R(Lm6/x1;)V

    :cond_1
    invoke-static {p0}, Lc4/b0;->z(Lcom/harindra/iptvpro/PlayerActivity;)V

    invoke-virtual {p0}, Lcom/harindra/iptvpro/PlayerActivity;->C()Landroidx/media3/ui/PlayerView;

    move-result-object p0

    invoke-virtual {p0}, Landroid/view/View;->requestFocus()Z

    return-void
.end method

.method public static h(F)F
    .locals 2

    const/high16 v0, 0x3f000000    # 0.5f

    cmpg-float v1, p0, v0

    if-gez v1, :cond_0

    return v0

    :cond_0
    const/high16 v0, 0x40000000    # 2.0f

    cmpl-float v1, p0, v0

    if-lez v1, :cond_1

    return v0

    :cond_1
    return p0
.end method

.method public static i(III)I
    .locals 2

    if-gt p1, p2, :cond_2

    if-ge p0, p1, :cond_0

    return p1

    :cond_0
    if-le p0, p2, :cond_1

    return p2

    :cond_1
    return p0

    :cond_2
    new-instance p0, Ljava/lang/IllegalArgumentException;

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Cannot coerce value to an empty range: maximum "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p2, " is less than minimum "

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/16 p1, 0x2e

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static j(JJJ)J
    .locals 1

    cmp-long v0, p2, p4

    if-gtz v0, :cond_2

    cmp-long v0, p0, p2

    if-gez v0, :cond_0

    return-wide p2

    :cond_0
    cmp-long p2, p0, p4

    if-lez p2, :cond_1

    return-wide p4

    :cond_1
    return-wide p0

    :cond_2
    new-instance p0, Ljava/lang/IllegalArgumentException;

    new-instance p1, Ljava/lang/StringBuilder;

    const-string v0, "Cannot coerce value to an empty range: maximum "

    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, p4, p5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string p4, " is less than minimum "

    invoke-virtual {p1, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, p2, p3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/16 p2, 0x2e

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static final k(Lcom/harindra/iptvpro/PlayerActivity;Ljava/lang/String;)V
    .locals 5

    const-string v0, "<this>"

    invoke-static {p0, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {p1}, Ll4/f;->F(Ljava/lang/String;)Lm6/f;

    move-result-object v0

    iget-object v1, v0, Lm6/f;->i:Ljava/lang/String;

    iget-boolean v2, v0, Lm6/f;->a:Z

    if-nez v2, :cond_0

    const-string p1, "\u274c Backup rejected: "

    const/4 v0, 0x1

    invoke-static {v0, p0, p1, v1}, La0/h;->A(ILcom/harindra/iptvpro/PlayerActivity;Ljava/lang/String;Ljava/lang/String;)V

    return-void

    :cond_0
    new-instance v2, Li/g;

    const v3, 0x7f11012f

    invoke-direct {v2, p0, v3}, Li/g;-><init>(Landroid/content/Context;I)V

    const-string v3, "Confirm Backup Restore"

    invoke-virtual {v2, v3}, Li/g;->setTitle(Ljava/lang/CharSequence;)Li/g;

    move-result-object v2

    const-string v3, "Validated: "

    const-string v4, "\n\nRestore this backup into active profile? Existing data is preserved if restore fails."

    invoke-static {v3, v1, v4}, Lq3/e;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    iget-object v3, v2, Li/g;->a:Li/c;

    iput-object v1, v3, Li/c;->f:Ljava/lang/String;

    new-instance v1, Lm6/p2;

    const/4 v4, 0x0

    invoke-direct {v1, v4, p0, p1, v0}, Lm6/p2;-><init>(ILcom/harindra/iptvpro/PlayerActivity;Ljava/lang/Object;Ljava/lang/Object;)V

    const-string p0, "Restore Now"

    iput-object p0, v3, Li/c;->g:Ljava/lang/CharSequence;

    iput-object v1, v3, Li/c;->h:Landroid/content/DialogInterface$OnClickListener;

    const-string p0, "Cancel"

    iput-object p0, v3, Li/c;->i:Ljava/lang/CharSequence;

    const/4 p0, 0x0

    iput-object p0, v3, Li/c;->j:Landroid/content/DialogInterface$OnClickListener;

    invoke-virtual {v2}, Li/g;->create()Li/h;

    move-result-object p0

    invoke-virtual {p0}, Landroid/app/Dialog;->show()V

    return-void
.end method

.method public static final l(II)V
    .locals 4

    if-gt p0, p1, :cond_0

    return-void

    :cond_0
    new-instance v0, Ljava/lang/IndexOutOfBoundsException;

    const-string v1, ") is greater than size ("

    const-string v2, ")."

    const-string v3, "toIndex ("

    invoke-static {p0, p1, v3, v1, v2}, La0/h;->o(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/IndexOutOfBoundsException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public static final m(Lcom/harindra/iptvpro/PlayerActivity;Lv0/t;)Ljava/lang/String;
    .locals 3

    const-string v0, "<this>"

    invoke-static {p0, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p0, "SDR"

    if-nez p1, :cond_0

    return-object p0

    :cond_0
    iget-object v0, p1, Lv0/t;->p:Ljava/lang/String;

    if-nez v0, :cond_1

    const-string v0, ""

    :cond_1
    const-string v1, "dolby-vision"

    const/4 v2, 0x1

    invoke-static {v0, v1, v2}, Le7/e;->Q(Ljava/lang/CharSequence;Ljava/lang/CharSequence;Z)Z

    move-result v0

    if-eqz v0, :cond_2

    const-string p0, "Dolby Vision"

    return-object p0

    :cond_2
    iget-object p1, p1, Lv0/t;->H:Lv0/k;

    if-nez p1, :cond_3

    return-object p0

    :cond_3
    iget p1, p1, Lv0/k;->c:I

    const/4 v0, 0x6

    if-eq p1, v0, :cond_5

    const/4 v0, 0x7

    if-eq p1, v0, :cond_4

    return-object p0

    :cond_4
    const-string p0, "HLG HDR"

    return-object p0

    :cond_5
    const-string p0, "HDR10"

    return-object p0
.end method

.method public static final n(Lcom/harindra/iptvpro/PlayerActivity;)Ljava/lang/String;
    .locals 8

    const-string v0, "<this>"

    invoke-static {p0, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x18

    const-string v2, "SDR"

    if-ge v0, v1, :cond_0

    goto :goto_1

    :cond_0
    const/4 v0, 0x0

    :try_start_0
    invoke-virtual {p0}, Landroid/app/Activity;->getWindowManager()Landroid/view/WindowManager;

    move-result-object p0

    invoke-interface {p0}, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;

    move-result-object p0

    if-eqz p0, :cond_1

    invoke-static {p0}, Li/w;->e(Landroid/view/Display;)Landroid/view/Display$HdrCapabilities;

    move-result-object p0

    if-eqz p0, :cond_1

    invoke-static {p0}, Li/w;->v(Landroid/view/Display$HdrCapabilities;)[I

    move-result-object p0

    if-nez p0, :cond_2

    :cond_1
    new-array p0, v0, [I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    new-array p0, v0, [I

    :cond_2
    :goto_0
    array-length v1, p0

    if-nez v1, :cond_3

    :goto_1
    return-object v2

    :cond_3
    new-instance v1, Ljava/util/ArrayList;

    const/4 v3, 0x4

    invoke-direct {v1, v3}, Ljava/util/ArrayList;-><init>(I)V

    array-length v4, p0

    :goto_2
    if-ge v0, v4, :cond_8

    aget v5, p0, v0

    const/4 v6, 0x1

    if-eq v5, v6, :cond_6

    const/4 v6, 0x2

    if-eq v5, v6, :cond_5

    const/4 v6, 0x3

    if-eq v5, v6, :cond_4

    sget v6, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v7, 0x1d

    if-lt v6, v7, :cond_7

    if-ne v5, v3, :cond_7

    const-string v5, "HDR10+"

    invoke-virtual {v1, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_3

    :cond_4
    const-string v5, "HLG"

    invoke-virtual {v1, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_3

    :cond_5
    const-string v5, "HDR10"

    invoke-virtual {v1, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_3

    :cond_6
    const-string v5, "DV"

    invoke-virtual {v1, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_7
    :goto_3
    add-int/lit8 v0, v0, 0x1

    goto :goto_2

    :cond_8
    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result p0

    if-eqz p0, :cond_9

    goto :goto_4

    :cond_9
    invoke-static {v1}, Lo6/j;->T(Ljava/util/ArrayList;)Ljava/util/List;

    move-result-object p0

    const/4 v0, 0x0

    const/16 v1, 0x3e

    const-string v2, "/"

    invoke-static {p0, v2, v0, v1}, Lo6/j;->b0(Ljava/lang/Iterable;Ljava/lang/String;Lz6/l;I)Ljava/lang/String;

    move-result-object v2

    :goto_4
    return-object v2
.end method

.method public static final o(Lcom/harindra/iptvpro/PlayerActivity;)Ljava/util/List;
    .locals 9

    const-string v0, "<this>"

    invoke-static {p0, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "audio"

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    instance-of v0, p0, Landroid/media/AudioManager;

    if-eqz v0, :cond_0

    check-cast p0, Landroid/media/AudioManager;

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    sget-object v0, Lo6/r;->k:Lo6/r;

    if-nez p0, :cond_1

    return-object v0

    :cond_1
    new-instance v1, Ljava/util/HashSet;

    invoke-direct {v1}, Ljava/util/HashSet;-><init>()V

    const/4 v2, 0x2

    :try_start_0
    invoke-virtual {p0, v2}, Landroid/media/AudioManager;->getDevices(I)[Landroid/media/AudioDeviceInfo;

    move-result-object p0

    const-string v2, "getDevices(...)"

    invoke-static {p0, v2}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    array-length v2, p0

    const/4 v3, 0x0

    move v4, v3

    :goto_1
    if-ge v4, v2, :cond_3

    aget-object v5, p0, v4

    invoke-virtual {v5}, Landroid/media/AudioDeviceInfo;->getEncodings()[I

    move-result-object v5

    const-string v6, "getEncodings(...)"

    invoke-static {v5, v6}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    array-length v6, v5

    move v7, v3

    :goto_2
    if-ge v7, v6, :cond_2

    aget v8, v5, v7

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    invoke-virtual {v1, v8}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    add-int/lit8 v7, v7, 0x1

    goto :goto_2

    :cond_2
    add-int/lit8 v4, v4, 0x1

    goto :goto_1

    :cond_3
    new-instance p0, Ljava/util/ArrayList;

    const/4 v0, 0x4

    invoke-direct {p0, v0}, Ljava/util/ArrayList;-><init>(I)V

    const/4 v0, 0x5

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_4

    const-string v0, "AC3"

    invoke-virtual {p0, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_4
    const/4 v0, 0x6

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_5

    const-string v0, "E-AC3"

    invoke-virtual {p0, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_5
    const/4 v0, 0x7

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_6

    const-string v0, "DTS"

    invoke-virtual {p0, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_6
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x1c

    if-lt v0, v2, :cond_7

    const/16 v0, 0xe

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_7

    const-string v0, "TrueHD"

    invoke-virtual {p0, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_7
    return-object p0

    :catch_0
    return-object v0
.end method

.method public static final p(Lcom/harindra/iptvpro/PlayerActivity;Ljava/lang/String;)V
    .locals 1

    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result v0

    sparse-switch v0, :sswitch_data_0

    goto :goto_0

    :sswitch_0
    const-string v0, "AUDIO_QUALITY"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_0

    goto :goto_0

    :cond_0
    invoke-static {p0}, Lcom/bumptech/glide/c;->w(Lcom/harindra/iptvpro/PlayerActivity;)V

    return-void

    :sswitch_1
    const-string v0, "SLEEP_TIMER"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_1

    goto :goto_0

    :cond_1
    invoke-static {p0}, Lw7/l;->q(Lcom/harindra/iptvpro/PlayerActivity;)V

    return-void

    :sswitch_2
    const-string v0, "EPG_GUIDE"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_2

    goto :goto_0

    :cond_2
    invoke-static {p0}, Lw7/d;->z(Lcom/harindra/iptvpro/PlayerActivity;)V

    return-void

    :sswitch_3
    const-string v0, "PLAYER_LOCK"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_3

    goto :goto_0

    :cond_3
    invoke-static {p0}, Lcom/bumptech/glide/c;->G(Lcom/harindra/iptvpro/PlayerActivity;)V

    return-void

    :sswitch_4
    const-string v0, "FAVORITE_TOGGLE"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_4

    goto :goto_0

    :cond_4
    invoke-static {p0}, Lcom/bumptech/glide/d;->I(Lcom/harindra/iptvpro/PlayerActivity;)V

    invoke-static {p0}, Lcom/bumptech/glide/c;->z(Lcom/harindra/iptvpro/PlayerActivity;)V

    return-void

    :sswitch_5
    const-string v0, "CHANNEL_INFO"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_5

    goto :goto_0

    :cond_5
    invoke-static {p0}, Lb4/a;->O(Lcom/harindra/iptvpro/PlayerActivity;)V

    return-void

    :sswitch_6
    const-string v0, "SETTINGS"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_6

    :goto_0
    invoke-static {p0}, Lw7/l;->o(Lcom/harindra/iptvpro/PlayerActivity;)V

    return-void

    :cond_6
    invoke-static {p0}, Lb4/a;->K(Lcom/harindra/iptvpro/PlayerActivity;)V

    return-void

    nop

    :sswitch_data_0
    .sparse-switch
        -0x7bd753dd -> :sswitch_6
        -0x78f8dd76 -> :sswitch_5
        -0x5f40d4a9 -> :sswitch_4
        -0x5cb7f437 -> :sswitch_3
        -0x4128fa27 -> :sswitch_2
        -0xf187c63 -> :sswitch_1
        -0xdc47eaa -> :sswitch_0
    .end sparse-switch
.end method

.method public static q(Ljava/lang/String;)Lo7/c0;
    .locals 2

    const-string v0, "javaName"

    invoke-static {p0, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    move-result v0

    const v1, 0x4b88569

    if-eq v0, v1, :cond_1

    const v1, 0x4c38896

    if-eq v0, v1, :cond_0

    packed-switch v0, :pswitch_data_0

    goto :goto_0

    :pswitch_0
    const-string v0, "TLSv1.3"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    sget-object p0, Lo7/c0;->l:Lo7/c0;

    return-object p0

    :pswitch_1
    const-string v0, "TLSv1.2"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    sget-object p0, Lo7/c0;->m:Lo7/c0;

    return-object p0

    :pswitch_2
    const-string v0, "TLSv1.1"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    sget-object p0, Lo7/c0;->n:Lo7/c0;

    return-object p0

    :cond_0
    const-string v0, "TLSv1"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    sget-object p0, Lo7/c0;->o:Lo7/c0;

    return-object p0

    :cond_1
    const-string v0, "SSLv3"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    sget-object p0, Lo7/c0;->p:Lo7/c0;

    return-object p0

    :cond_2
    :goto_0
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "Unexpected TLS version: "

    invoke-virtual {v1, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :pswitch_data_0
    .packed-switch -0x1dfc3f27
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public static r(Ljava/lang/String;)I
    .locals 24

    const/4 v0, -0x1

    if-nez p0, :cond_0

    return v0

    :cond_0
    invoke-static/range {p0 .. p0}, Lv0/q0;->p(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v2

    const/16 v3, 0x15

    const/16 v4, 0x14

    const/16 v5, 0x13

    const/16 v6, 0x12

    const/16 v7, 0x11

    const/16 v8, 0x10

    const/16 v9, 0xf

    const/16 v10, 0xe

    const/16 v11, 0xd

    const/16 v12, 0xc

    const/16 v13, 0xb

    const/16 v14, 0xa

    const/16 v15, 0x9

    const/16 v16, 0x8

    const/16 v17, 0x7

    const/16 v18, 0x6

    const/16 v19, 0x5

    const/16 v20, 0x4

    const/16 v21, 0x3

    const/16 v22, 0x1

    const/16 v23, 0x0

    sparse-switch v2, :sswitch_data_0

    :goto_0
    move v1, v0

    goto/16 :goto_1

    :sswitch_0
    const-string v2, "video/x-matroska"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1

    goto :goto_0

    :cond_1
    const/16 v1, 0x1f

    goto/16 :goto_1

    :sswitch_1
    const-string v2, "audio/webm"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2

    goto :goto_0

    :cond_2
    const/16 v1, 0x1e

    goto/16 :goto_1

    :sswitch_2
    const-string v2, "audio/mpeg"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3

    goto :goto_0

    :cond_3
    const/16 v1, 0x1d

    goto/16 :goto_1

    :sswitch_3
    const-string v2, "audio/midi"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_4

    goto :goto_0

    :cond_4
    const/16 v1, 0x1c

    goto/16 :goto_1

    :sswitch_4
    const-string v2, "audio/flac"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_5

    goto :goto_0

    :cond_5
    const/16 v1, 0x1b

    goto/16 :goto_1

    :sswitch_5
    const-string v2, "audio/eac3"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_6

    goto :goto_0

    :cond_6
    const/16 v1, 0x1a

    goto/16 :goto_1

    :sswitch_6
    const-string v2, "audio/3gpp"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_7

    goto :goto_0

    :cond_7
    const/16 v1, 0x19

    goto/16 :goto_1

    :sswitch_7
    const-string v2, "video/mp4"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_8

    goto :goto_0

    :cond_8
    const/16 v1, 0x18

    goto/16 :goto_1

    :sswitch_8
    const-string v2, "audio/wav"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_9

    goto :goto_0

    :cond_9
    const/16 v1, 0x17

    goto/16 :goto_1

    :sswitch_9
    const-string v2, "audio/ogg"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_a

    goto/16 :goto_0

    :cond_a
    const/16 v1, 0x16

    goto/16 :goto_1

    :sswitch_a
    const-string v2, "audio/mp4"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_b

    goto/16 :goto_0

    :cond_b
    move v1, v3

    goto/16 :goto_1

    :sswitch_b
    const-string v2, "audio/amr"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_c

    goto/16 :goto_0

    :cond_c
    move v1, v4

    goto/16 :goto_1

    :sswitch_c
    const-string v2, "audio/ac4"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_d

    goto/16 :goto_0

    :cond_d
    move v1, v5

    goto/16 :goto_1

    :sswitch_d
    const-string v2, "audio/ac3"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_e

    goto/16 :goto_0

    :cond_e
    move v1, v6

    goto/16 :goto_1

    :sswitch_e
    const-string v2, "video/x-flv"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_f

    goto/16 :goto_0

    :cond_f
    move v1, v7

    goto/16 :goto_1

    :sswitch_f
    const-string v2, "application/webm"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_10

    goto/16 :goto_0

    :cond_10
    move v1, v8

    goto/16 :goto_1

    :sswitch_10
    const-string v2, "audio/x-matroska"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_11

    goto/16 :goto_0

    :cond_11
    move v1, v9

    goto/16 :goto_1

    :sswitch_11
    const-string v2, "image/png"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_12

    goto/16 :goto_0

    :cond_12
    move v1, v10

    goto/16 :goto_1

    :sswitch_12
    const-string v2, "image/bmp"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_13

    goto/16 :goto_0

    :cond_13
    move v1, v11

    goto/16 :goto_1

    :sswitch_13
    const-string v2, "text/vtt"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_14

    goto/16 :goto_0

    :cond_14
    move v1, v12

    goto/16 :goto_1

    :sswitch_14
    const-string v2, "video/x-msvideo"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_15

    goto/16 :goto_0

    :cond_15
    move v1, v13

    goto/16 :goto_1

    :sswitch_15
    const-string v2, "application/mp4"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_16

    goto/16 :goto_0

    :cond_16
    move v1, v14

    goto/16 :goto_1

    :sswitch_16
    const-string v2, "image/webp"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_17

    goto/16 :goto_0

    :cond_17
    move v1, v15

    goto/16 :goto_1

    :sswitch_17
    const-string v2, "image/jpeg"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_18

    goto/16 :goto_0

    :cond_18
    move/from16 v1, v16

    goto/16 :goto_1

    :sswitch_18
    const-string v2, "image/heif"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_19

    goto/16 :goto_0

    :cond_19
    move/from16 v1, v17

    goto :goto_1

    :sswitch_19
    const-string v2, "image/heic"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1a

    goto/16 :goto_0

    :cond_1a
    move/from16 v1, v18

    goto :goto_1

    :sswitch_1a
    const-string v2, "image/avif"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1b

    goto/16 :goto_0

    :cond_1b
    move/from16 v1, v19

    goto :goto_1

    :sswitch_1b
    const-string v2, "audio/amr-wb"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1c

    goto/16 :goto_0

    :cond_1c
    move/from16 v1, v20

    goto :goto_1

    :sswitch_1c
    const-string v2, "video/webm"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1d

    goto/16 :goto_0

    :cond_1d
    move/from16 v1, v21

    goto :goto_1

    :sswitch_1d
    const-string v2, "video/mp2t"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1e

    goto/16 :goto_0

    :cond_1e
    const/4 v1, 0x2

    goto :goto_1

    :sswitch_1e
    const-string v2, "video/mp2p"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1f

    goto/16 :goto_0

    :cond_1f
    move/from16 v1, v22

    goto :goto_1

    :sswitch_1f
    const-string v2, "audio/eac3-joc"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_20

    goto/16 :goto_0

    :cond_20
    move/from16 v1, v23

    :goto_1
    packed-switch v1, :pswitch_data_0

    return v0

    :pswitch_0
    return v17

    :pswitch_1
    return v9

    :pswitch_2
    return v20

    :pswitch_3
    return v12

    :pswitch_4
    return v15

    :pswitch_5
    return v22

    :pswitch_6
    return v19

    :pswitch_7
    return v7

    :pswitch_8
    return v5

    :pswitch_9
    return v11

    :pswitch_a
    return v8

    :pswitch_b
    return v16

    :pswitch_c
    return v6

    :pswitch_d
    return v10

    :pswitch_e
    return v4

    :pswitch_f
    return v3

    :pswitch_10
    return v21

    :pswitch_11
    return v18

    :pswitch_12
    return v13

    :pswitch_13
    return v14

    :pswitch_14
    return v23

    :sswitch_data_0
    .sparse-switch
        -0x7e929daa -> :sswitch_1f
        -0x6315f78b -> :sswitch_1e
        -0x6315f787 -> :sswitch_1d
        -0x63118f53 -> :sswitch_1c
        -0x5fc6f775 -> :sswitch_1b
        -0x58abd7ba -> :sswitch_1a
        -0x58a8e8f5 -> :sswitch_19
        -0x58a8e8f2 -> :sswitch_18
        -0x58a7d764 -> :sswitch_17
        -0x58a21830 -> :sswitch_16
        -0x4a681e4e -> :sswitch_15
        -0x405dba54 -> :sswitch_14
        -0x3be2f26c -> :sswitch_13
        -0x3468a12f -> :sswitch_12
        -0x34686c8b -> :sswitch_11
        -0x17118226 -> :sswitch_10
        -0x2974308 -> :sswitch_f
        0xd45707 -> :sswitch_e
        0xb269698 -> :sswitch_d
        0xb269699 -> :sswitch_c
        0xb26980d -> :sswitch_b
        0xb26c538 -> :sswitch_a
        0xb26cbd6 -> :sswitch_9
        0xb26e933 -> :sswitch_8
        0x4f62635d -> :sswitch_7
        0x59976a2d -> :sswitch_6
        0x59ae0c65 -> :sswitch_5
        0x59aeaa01 -> :sswitch_4
        0x59b1cdba -> :sswitch_3
        0x59b1e81e -> :sswitch_2
        0x59b64a32 -> :sswitch_1
        0x79909c15 -> :sswitch_0
    .end sparse-switch

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_11
        :pswitch_11
        :pswitch_6
        :pswitch_14
        :pswitch_5
        :pswitch_10
        :pswitch_b
        :pswitch_4
        :pswitch_3
        :pswitch_b
        :pswitch_10
        :pswitch_14
        :pswitch_2
        :pswitch_1
        :pswitch_0
        :pswitch_11
        :pswitch_11
    .end packed-switch
.end method

.method public static s(Landroid/net/Uri;)I
    .locals 6

    invoke-virtual {p0}, Landroid/net/Uri;->getLastPathSegment()Ljava/lang/String;

    move-result-object p0

    const/4 v0, -0x1

    if-nez p0, :cond_0

    return v0

    :cond_0
    const-string v1, ".ac3"

    invoke-virtual {p0, v1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_23

    const-string v1, ".ec3"

    invoke-virtual {p0, v1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_1

    goto/16 :goto_c

    :cond_1
    const-string v1, ".ac4"

    invoke-virtual {p0, v1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_2

    const/4 p0, 0x1

    return p0

    :cond_2
    const-string v1, ".adts"

    invoke-virtual {p0, v1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_22

    const-string v1, ".aac"

    invoke-virtual {p0, v1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_3

    goto/16 :goto_b

    :cond_3
    const-string v1, ".amr"

    invoke-virtual {p0, v1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_4

    const/4 p0, 0x3

    return p0

    :cond_4
    const-string v1, ".flac"

    invoke-virtual {p0, v1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v1

    const/4 v2, 0x4

    if-eqz v1, :cond_5

    return v2

    :cond_5
    const-string v1, ".flv"

    invoke-virtual {p0, v1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v1

    const/4 v3, 0x5

    if-eqz v1, :cond_6

    return v3

    :cond_6
    const-string v1, ".mid"

    invoke-virtual {p0, v1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_21

    const-string v1, ".midi"

    invoke-virtual {p0, v1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_21

    const-string v1, ".smf"

    invoke-virtual {p0, v1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_7

    goto/16 :goto_a

    :cond_7
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v1

    sub-int/2addr v1, v2

    const-string v4, ".mk"

    invoke-virtual {p0, v4, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;I)Z

    move-result v1

    if-nez v1, :cond_20

    const-string v1, ".webm"

    invoke-virtual {p0, v1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_8

    goto/16 :goto_9

    :cond_8
    const-string v1, ".mp3"

    invoke-virtual {p0, v1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_9

    const/4 p0, 0x7

    return p0

    :cond_9
    const-string v1, ".mp4"

    invoke-virtual {p0, v1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v4

    if-nez v4, :cond_1f

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v4

    sub-int/2addr v4, v2

    const-string v5, ".m4"

    invoke-virtual {p0, v5, v4}, Ljava/lang/String;->startsWith(Ljava/lang/String;I)Z

    move-result v4

    if-nez v4, :cond_1f

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v4

    sub-int/2addr v4, v3

    invoke-virtual {p0, v1, v4}, Ljava/lang/String;->startsWith(Ljava/lang/String;I)Z

    move-result v1

    if-nez v1, :cond_1f

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v1

    sub-int/2addr v1, v3

    const-string v3, ".cmf"

    invoke-virtual {p0, v3, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;I)Z

    move-result v1

    if-eqz v1, :cond_a

    goto/16 :goto_8

    :cond_a
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v1

    sub-int/2addr v1, v2

    const-string v3, ".og"

    invoke-virtual {p0, v3, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;I)Z

    move-result v1

    if-nez v1, :cond_1e

    const-string v1, ".opus"

    invoke-virtual {p0, v1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_b

    goto/16 :goto_7

    :cond_b
    const-string v1, ".ps"

    invoke-virtual {p0, v1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_1d

    const-string v1, ".mpeg"

    invoke-virtual {p0, v1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_1d

    const-string v1, ".mpg"

    invoke-virtual {p0, v1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_1d

    const-string v1, ".m2p"

    invoke-virtual {p0, v1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_c

    goto/16 :goto_6

    :cond_c
    const-string v1, ".ts"

    invoke-virtual {p0, v1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v3

    if-nez v3, :cond_1c

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v3

    sub-int/2addr v3, v2

    invoke-virtual {p0, v1, v3}, Ljava/lang/String;->startsWith(Ljava/lang/String;I)Z

    move-result v1

    if-eqz v1, :cond_d

    goto/16 :goto_5

    :cond_d
    const-string v1, ".wav"

    invoke-virtual {p0, v1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_1b

    const-string v1, ".wave"

    invoke-virtual {p0, v1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_e

    goto/16 :goto_4

    :cond_e
    const-string v1, ".vtt"

    invoke-virtual {p0, v1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_1a

    const-string v1, ".webvtt"

    invoke-virtual {p0, v1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_f

    goto :goto_3

    :cond_f
    const-string v1, ".jpg"

    invoke-virtual {p0, v1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_19

    const-string v1, ".jpeg"

    invoke-virtual {p0, v1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_10

    goto :goto_2

    :cond_10
    const-string v1, ".avi"

    invoke-virtual {p0, v1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_11

    const/16 p0, 0x10

    return p0

    :cond_11
    const-string v1, ".png"

    invoke-virtual {p0, v1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_12

    const/16 p0, 0x11

    return p0

    :cond_12
    const-string v1, ".webp"

    invoke-virtual {p0, v1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_13

    const/16 p0, 0x12

    return p0

    :cond_13
    const-string v1, ".bmp"

    invoke-virtual {p0, v1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_18

    const-string v1, ".dib"

    invoke-virtual {p0, v1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_14

    goto :goto_1

    :cond_14
    const-string v1, ".heic"

    invoke-virtual {p0, v1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_17

    const-string v1, ".heif"

    invoke-virtual {p0, v1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_15

    goto :goto_0

    :cond_15
    const-string v1, ".avif"

    invoke-virtual {p0, v1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result p0

    if-eqz p0, :cond_16

    const/16 p0, 0x15

    return p0

    :cond_16
    return v0

    :cond_17
    :goto_0
    const/16 p0, 0x14

    return p0

    :cond_18
    :goto_1
    const/16 p0, 0x13

    return p0

    :cond_19
    :goto_2
    const/16 p0, 0xe

    return p0

    :cond_1a
    :goto_3
    const/16 p0, 0xd

    return p0

    :cond_1b
    :goto_4
    const/16 p0, 0xc

    return p0

    :cond_1c
    :goto_5
    const/16 p0, 0xb

    return p0

    :cond_1d
    :goto_6
    const/16 p0, 0xa

    return p0

    :cond_1e
    :goto_7
    const/16 p0, 0x9

    return p0

    :cond_1f
    :goto_8
    const/16 p0, 0x8

    return p0

    :cond_20
    :goto_9
    const/4 p0, 0x6

    return p0

    :cond_21
    :goto_a
    const/16 p0, 0xf

    return p0

    :cond_22
    :goto_b
    const/4 p0, 0x2

    return p0

    :cond_23
    :goto_c
    const/4 p0, 0x0

    return p0
.end method

.method public static t(Lr6/d;)Lr6/d;
    .locals 2

    const-string v0, "<this>"

    invoke-static {p0, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    instance-of v0, p0, Lt6/c;

    if-eqz v0, :cond_0

    move-object v0, p0

    check-cast v0, Lt6/c;

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    if-eqz v0, :cond_2

    iget-object p0, v0, Lt6/c;->m:Lr6/d;

    if-nez p0, :cond_2

    iget-object p0, v0, Lt6/c;->l:Lr6/i;

    invoke-static {p0}, La7/h;->b(Ljava/lang/Object;)V

    sget-object v1, Lr6/e;->k:Lr6/e;

    invoke-interface {p0, v1}, Lr6/i;->e(Lr6/h;)Lr6/g;

    move-result-object p0

    check-cast p0, Lr6/f;

    if-eqz p0, :cond_1

    check-cast p0, Lf7/q;

    new-instance v1, Lk7/h;

    invoke-direct {v1, p0, v0}, Lk7/h;-><init>(Lf7/q;Lt6/c;)V

    goto :goto_1

    :cond_1
    move-object v1, v0

    :goto_1
    iput-object v1, v0, Lt6/c;->m:Lr6/d;

    return-object v1

    :cond_2
    return-object p0
.end method

.method public static u(Lq5/u;)Lq5/u;
    .locals 1

    instance-of v0, p0, Lq5/w;

    if-nez v0, :cond_2

    instance-of v0, p0, Lq5/v;

    if-eqz v0, :cond_0

    return-object p0

    :cond_0
    instance-of v0, p0, Ljava/io/Serializable;

    if-eqz v0, :cond_1

    new-instance v0, Lq5/v;

    invoke-direct {v0, p0}, Lq5/v;-><init>(Lq5/u;)V

    return-object v0

    :cond_1
    new-instance v0, Lq5/w;

    invoke-direct {v0, p0}, Lq5/w;-><init>(Lq5/u;)V

    return-object v0

    :cond_2
    return-object p0
.end method

.method public static final v(Lcom/harindra/iptvpro/PlayerActivity;Lm6/h0;I)V
    .locals 9

    const-string v0, "<this>"

    invoke-static {p0, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "section"

    invoke-static {p1, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p1}, Lm6/h0;->a()Ljava/lang/String;

    move-result-object v0

    invoke-static {p0, v0}, Lc4/b0;->M(Lcom/harindra/iptvpro/PlayerActivity;Ljava/lang/String;)V

    invoke-static {p0}, Ll3/e;->o(Lcom/harindra/iptvpro/PlayerActivity;)I

    move-result v0

    invoke-virtual {p0}, Lcom/harindra/iptvpro/PlayerActivity;->M()Landroidx/recyclerview/widget/RecyclerView;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/recyclerview/widget/RecyclerView;->getLayoutManager()Lp3/l0;

    move-result-object v1

    instance-of v2, v1, Landroidx/recyclerview/widget/GridLayoutManager;

    const/4 v3, 0x0

    if-eqz v2, :cond_0

    check-cast v1, Landroidx/recyclerview/widget/GridLayoutManager;

    goto :goto_0

    :cond_0
    move-object v1, v3

    :goto_0
    if-eqz v1, :cond_1

    invoke-virtual {v1, v0}, Landroidx/recyclerview/widget/GridLayoutManager;->d1(I)V

    :cond_1
    invoke-static {p0}, Ll3/e;->X(Lcom/harindra/iptvpro/PlayerActivity;)V

    invoke-virtual {p0}, Lcom/harindra/iptvpro/PlayerActivity;->L()Landroid/view/View;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/view/View;->setAlpha(F)V

    invoke-virtual {p0}, Lcom/harindra/iptvpro/PlayerActivity;->L()Landroid/view/View;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    invoke-virtual {p0}, Lcom/harindra/iptvpro/PlayerActivity;->L()Landroid/view/View;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    const/high16 v2, 0x3f800000    # 1.0f

    invoke-virtual {v0, v2}, Landroid/view/ViewPropertyAnimator;->alpha(F)Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    iget-object v2, p0, Lcom/harindra/iptvpro/PlayerActivity;->n2:Lm6/l1;

    invoke-virtual {v2}, Lm6/l1;->p()Z

    move-result v2

    if-eqz v2, :cond_2

    const-wide/16 v4, 0x3c

    goto :goto_1

    :cond_2
    const-wide/16 v4, 0x82

    :goto_1
    invoke-virtual {v0, v4, v5}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/ViewPropertyAnimator;->withLayer()Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/ViewPropertyAnimator;->start()V

    sget-object v0, Lm6/h0;->MOVIES:Lm6/h0;

    const/4 v2, 0x1

    if-ne p1, v0, :cond_3

    move v0, v2

    goto :goto_2

    :cond_3
    move v0, v1

    :goto_2
    iget-object v4, p0, Lcom/harindra/iptvpro/PlayerActivity;->r0:Landroid/widget/TextView;

    if-eqz v4, :cond_f

    if-eqz v0, :cond_4

    const v5, 0x7f0800c7

    goto :goto_3

    :cond_4
    const v5, 0x7f0800d0

    :goto_3
    invoke-virtual {v4, v5, v1, v1, v1}, Landroid/widget/TextView;->setCompoundDrawablesWithIntrinsicBounds(IIII)V

    invoke-static {p0, p1}, Lc4/b0;->d(Lcom/harindra/iptvpro/PlayerActivity;Lm6/h0;)Ljava/util/List;

    move-result-object p1

    invoke-virtual {p0}, Lcom/harindra/iptvpro/PlayerActivity;->N()Lm3/o;

    move-result-object v4

    iget-object v5, p0, Lcom/harindra/iptvpro/PlayerActivity;->l1:Ljava/lang/String;

    invoke-virtual {v4, v5, p1}, Lm3/o;->j(Ljava/lang/String;Ljava/util/List;)V

    new-instance v4, Ljava/util/ArrayList;

    const/16 v5, 0xa

    invoke-static {p1, v5}, Lo6/l;->O(Ljava/lang/Iterable;I)I

    move-result v5

    invoke-direct {v4, v5}, Ljava/util/ArrayList;-><init>(I)V

    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_4
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_6

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lm6/o8;

    iget-boolean v7, v6, Lm6/o8;->c:Z

    iget-object v8, v6, Lm6/o8;->a:Ljava/lang/String;

    if-eqz v7, :cond_5

    goto :goto_5

    :cond_5
    iget v6, v6, Lm6/o8;->b:I

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v8, " ("

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v6, ")"

    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    :goto_5
    invoke-virtual {v4, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_4

    :cond_6
    iput-boolean v2, p0, Lcom/harindra/iptvpro/PlayerActivity;->m1:Z

    iget-object v5, p0, Lcom/harindra/iptvpro/PlayerActivity;->y0:Landroid/widget/Spinner;

    const-string v6, "vodCategorySpinner"

    if-eqz v5, :cond_e

    if-eqz v0, :cond_7

    const-string v7, "Movies"

    goto :goto_6

    :cond_7
    const-string v7, "Series"

    :goto_6
    new-instance v8, Lm6/h4;

    invoke-direct {v8, p0, v4, v7}, Lm6/h4;-><init>(Lcom/harindra/iptvpro/PlayerActivity;Ljava/util/ArrayList;Ljava/lang/String;)V

    invoke-virtual {v5, v8}, Landroid/widget/Spinner;->setAdapter(Landroid/widget/SpinnerAdapter;)V

    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    move v4, v1

    :goto_7
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_9

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lm6/o8;

    iget-object v5, v5, Lm6/o8;->a:Ljava/lang/String;

    iget-object v7, p0, Lcom/harindra/iptvpro/PlayerActivity;->l1:Ljava/lang/String;

    invoke-static {v5, v7}, La7/h;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_8

    goto :goto_8

    :cond_8
    add-int/lit8 v4, v4, 0x1

    goto :goto_7

    :cond_9
    const/4 v4, -0x1

    :goto_8
    if-gez v4, :cond_a

    move v4, v1

    :cond_a
    iget-object p1, p0, Lcom/harindra/iptvpro/PlayerActivity;->y0:Landroid/widget/Spinner;

    if-eqz p1, :cond_d

    invoke-virtual {p1, v4, v1}, Landroid/widget/AbsSpinner;->setSelection(IZ)V

    iput-boolean v1, p0, Lcom/harindra/iptvpro/PlayerActivity;->m1:Z

    invoke-static {p2, p0, v2}, Lc4/b0;->y(ILcom/harindra/iptvpro/PlayerActivity;I)V

    iget-object p1, p0, Lcom/harindra/iptvpro/PlayerActivity;->d2:Lm6/w8;

    iget-object p2, p0, Lcom/harindra/iptvpro/PlayerActivity;->c2:Lm6/n6;

    sget-object v2, Lm6/n6;->XTREAM:Lm6/n6;

    if-ne p2, v2, :cond_c

    if-eqz p1, :cond_c

    if-eqz v0, :cond_b

    iget-object p2, p0, Lcom/harindra/iptvpro/PlayerActivity;->w1:Ljava/lang/Object;

    invoke-interface {p2}, Ljava/util/List;->isEmpty()Z

    move-result p2

    if-eqz p2, :cond_b

    invoke-static {p0, p1, v1}, Lw7/d;->r(Lcom/harindra/iptvpro/PlayerActivity;Lm6/w8;Z)V

    return-void

    :cond_b
    if-nez v0, :cond_c

    iget-object p2, p0, Lcom/harindra/iptvpro/PlayerActivity;->y1:Ljava/lang/Object;

    invoke-interface {p2}, Ljava/util/List;->isEmpty()Z

    move-result p2

    if-eqz p2, :cond_c

    invoke-static {p0, p1, v1}, Lw7/d;->q(Lcom/harindra/iptvpro/PlayerActivity;Lm6/w8;Z)V

    :cond_c
    return-void

    :cond_d
    invoke-static {v6}, La7/h;->h(Ljava/lang/String;)V

    throw v3

    :cond_e
    invoke-static {v6}, La7/h;->h(Ljava/lang/String;)V

    throw v3

    :cond_f
    const-string p0, "tvVodGridHeaderTitle"

    invoke-static {p0}, La7/h;->h(Ljava/lang/String;)V

    throw v3
.end method

.method public static w(Ljava/lang/String;)V
    .locals 3

    :try_start_0
    invoke-static {p0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_0} :catch_4

    const/4 v0, 0x0

    :try_start_1
    invoke-virtual {p0, v0}, Ljava/lang/Class;->getDeclaredConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0
    :try_end_1
    .catch Ljava/lang/InstantiationException; {:try_start_1 .. :try_end_1} :catch_3
    .catch Ljava/lang/IllegalAccessException; {:try_start_1 .. :try_end_1} :catch_2
    .catch Ljava/lang/NoSuchMethodException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_1 .. :try_end_1} :catch_0

    new-instance v0, Ljava/lang/RuntimeException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Expected instanceof GlideModule, but found: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw v0

    :catch_0
    move-exception v1

    goto :goto_0

    :catch_1
    move-exception v1

    goto :goto_1

    :catch_2
    move-exception v1

    goto :goto_2

    :catch_3
    move-exception v1

    goto :goto_3

    :goto_0
    invoke-static {p0, v1}, Lc4/b0;->O(Ljava/lang/Class;Ljava/lang/ReflectiveOperationException;)V

    throw v0

    :goto_1
    invoke-static {p0, v1}, Lc4/b0;->O(Ljava/lang/Class;Ljava/lang/ReflectiveOperationException;)V

    throw v0

    :goto_2
    invoke-static {p0, v1}, Lc4/b0;->O(Ljava/lang/Class;Ljava/lang/ReflectiveOperationException;)V

    throw v0

    :goto_3
    invoke-static {p0, v1}, Lc4/b0;->O(Ljava/lang/Class;Ljava/lang/ReflectiveOperationException;)V

    throw v0

    :catch_4
    move-exception p0

    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "Unable to find GlideModule implementation"

    invoke-direct {v0, v1, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v0
.end method

.method public static final x(Lcom/harindra/iptvpro/PlayerActivity;ILm6/n;Lm6/p8;)V
    .locals 22

    move-object/from16 v2, p0

    move-object/from16 v3, p2

    move-object/from16 v4, p3

    const-string v0, "<this>"

    invoke-static {v2, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "movie"

    invoke-static {v3, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v8, v3, Lm6/n;->a:Ljava/lang/String;

    const-string v0, "detail"

    invoke-static {v4, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, v4, Lm6/p8;->j:Ljava/lang/String;

    iget-object v1, v4, Lm6/p8;->h:Ljava/lang/String;

    iget-object v5, v4, Lm6/p8;->i:Ljava/lang/String;

    iget-object v6, v4, Lm6/p8;->f:Ljava/lang/String;

    iget-object v7, v4, Lm6/p8;->e:Ljava/lang/String;

    iget-object v9, v4, Lm6/p8;->c:Ljava/lang/String;

    iget-object v10, v4, Lm6/p8;->b:Ljava/lang/String;

    new-instance v11, La7/m;

    const/4 v12, 0x0

    invoke-direct {v11, v12}, La7/m;-><init>(Z)V

    invoke-virtual {v2}, Lcom/harindra/iptvpro/PlayerActivity;->x()Z

    move-result v12

    if-eqz v12, :cond_0

    invoke-virtual {v2}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v12

    iget-object v14, v2, Lcom/harindra/iptvpro/PlayerActivity;->g2:Ljava/lang/String;

    invoke-virtual {v12, v8, v14}, Lm6/m6;->H(Ljava/lang/String;Ljava/lang/String;)Lm6/n1;

    move-result-object v12

    goto :goto_0

    :cond_0
    const/4 v12, 0x0

    :goto_0
    invoke-virtual {v2}, Lcom/harindra/iptvpro/PlayerActivity;->x()Z

    move-result v14

    if-eqz v14, :cond_2

    invoke-virtual {v2}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v14

    iget-object v13, v2, Lcom/harindra/iptvpro/PlayerActivity;->g2:Ljava/lang/String;

    const-string v15, "movieId"

    invoke-static {v8, v15}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v8}, Le7/e;->Y(Ljava/lang/CharSequence;)Z

    move-result v15

    if-eqz v15, :cond_1

    goto :goto_1

    :cond_1
    invoke-virtual {v14, v13}, Lm6/m6;->B(Ljava/lang/String;)Ljava/util/Set;

    move-result-object v13

    invoke-interface {v13, v8}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v13

    goto :goto_2

    :cond_2
    :goto_1
    const/4 v13, 0x0

    :goto_2
    new-instance v14, Landroid/widget/LinearLayout;

    invoke-direct {v14, v2}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v15, 0x1

    invoke-virtual {v14, v15}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const v15, 0x7f080059

    invoke-virtual {v14, v15}, Landroid/view/View;->setBackgroundResource(I)V

    const/16 v15, 0x16

    move-object/from16 v16, v12

    invoke-virtual {v2, v15}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    move-result v12

    move/from16 v17, v13

    const/16 v13, 0x12

    move-object/from16 v18, v8

    invoke-virtual {v2, v13}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    move-result v8

    invoke-virtual {v2, v15}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    move-result v15

    move-object/from16 v19, v11

    invoke-virtual {v2, v13}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    move-result v11

    invoke-virtual {v14, v12, v8, v15, v11}, Landroid/view/View;->setPadding(IIII)V

    new-instance v8, Landroid/widget/LinearLayout;

    invoke-direct {v8, v2}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v11, 0x0

    invoke-virtual {v8, v11}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v11, 0x30

    invoke-virtual {v8, v11}, Landroid/widget/LinearLayout;->setGravity(I)V

    new-instance v11, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v12, -0x1

    const/4 v15, -0x2

    invoke-direct {v11, v12, v15}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v8, v11}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v11, Landroid/widget/ImageView;

    invoke-direct {v11, v2}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    sget-object v12, Landroid/widget/ImageView$ScaleType;->CENTER_CROP:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v11, v12}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    const v12, 0x7f080057

    invoke-virtual {v11, v12}, Landroid/view/View;->setBackgroundResource(I)V

    const/4 v12, 0x4

    invoke-virtual {v2, v12}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    move-result v15

    invoke-virtual {v2, v12}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    move-result v13

    move-object/from16 v20, v14

    invoke-virtual {v2, v12}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    move-result v14

    move-object/from16 v21, v0

    invoke-virtual {v2, v12}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    move-result v0

    invoke-virtual {v11, v15, v13, v14, v0}, Landroid/view/View;->setPadding(IIII)V

    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v13, 0x91

    invoke-virtual {v2, v13}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    move-result v13

    const/16 v14, 0xd4

    invoke-virtual {v2, v14}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    move-result v14

    invoke-direct {v0, v13, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/16 v13, 0x12

    invoke-virtual {v2, v13}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    move-result v14

    invoke-virtual {v0, v14}, Landroid/view/ViewGroup$MarginLayoutParams;->setMarginEnd(I)V

    invoke-virtual {v11, v0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    invoke-static {v9}, Le7/e;->Y(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_3

    invoke-static {v2}, Lcom/bumptech/glide/b;->c(Landroid/content/Context;)Lh5/l;

    move-result-object v0

    invoke-virtual {v0, v2}, Lh5/l;->c(Li/k;)Lcom/bumptech/glide/m;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v13, Lcom/bumptech/glide/j;

    iget-object v14, v0, Lcom/bumptech/glide/m;->k:Lcom/bumptech/glide/b;

    iget-object v15, v0, Lcom/bumptech/glide/m;->l:Landroid/content/Context;

    const-class v12, Landroid/graphics/drawable/Drawable;

    invoke-direct {v13, v14, v0, v12, v15}, Lcom/bumptech/glide/j;-><init>(Lcom/bumptech/glide/b;Lcom/bumptech/glide/m;Ljava/lang/Class;Landroid/content/Context;)V

    invoke-virtual {v13, v9}, Lcom/bumptech/glide/j;->A(Ljava/lang/Object;)Lcom/bumptech/glide/j;

    move-result-object v0

    invoke-virtual {v2}, Lcom/harindra/iptvpro/PlayerActivity;->p()Lk5/e;

    move-result-object v9

    invoke-virtual {v0, v9}, Lcom/bumptech/glide/j;->v(Lk5/a;)Lcom/bumptech/glide/j;

    move-result-object v0

    invoke-virtual {v0, v11}, Lcom/bumptech/glide/j;->y(Landroid/widget/ImageView;)V

    goto :goto_3

    :cond_3
    sget-object v0, Landroid/widget/ImageView$ScaleType;->FIT_CENTER:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v11, v0}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    const v0, 0x7f0800c7

    invoke-virtual {v11, v0}, Landroid/widget/ImageView;->setImageResource(I)V

    :goto_3
    invoke-virtual {v8, v11}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, v2}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v9, 0x1

    invoke-virtual {v0, v9}, Landroid/widget/LinearLayout;->setOrientation(I)V

    new-instance v9, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v11, 0x3f800000    # 1.0f

    const/4 v12, -0x2

    const/4 v13, 0x0

    invoke-direct {v9, v13, v12, v11}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v0, v9}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v3}, Lm6/n;->e()Ljava/lang/String;

    move-result-object v9

    invoke-static {v9}, Le7/e;->Y(Ljava/lang/CharSequence;)Z

    move-result v12

    if-eqz v12, :cond_7

    const/4 v12, 0x4

    invoke-static {v7, v12}, Le7/e;->n0(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/String;->length()I

    move-result v13

    if-ne v13, v12, :cond_5

    const/4 v12, 0x0

    :goto_4
    invoke-virtual {v9}, Ljava/lang/String;->length()I

    move-result v13

    if-ge v12, v13, :cond_6

    invoke-virtual {v9, v12}, Ljava/lang/String;->charAt(I)C

    move-result v13

    invoke-static {v13}, Ljava/lang/Character;->isDigit(C)Z

    move-result v13

    if-nez v13, :cond_4

    goto :goto_5

    :cond_4
    add-int/lit8 v12, v12, 0x1

    goto :goto_4

    :cond_5
    :goto_5
    const/4 v9, 0x0

    :cond_6
    if-nez v9, :cond_7

    const-string v9, ""

    :cond_7
    invoke-static {v9}, Le7/e;->Y(Ljava/lang/CharSequence;)Z

    move-result v12

    const-string v13, ")"

    if-nez v12, :cond_8

    new-instance v12, Ljava/lang/StringBuilder;

    const-string v14, "("

    invoke-direct {v12, v14}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v12, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v12

    const/4 v14, 0x0

    invoke-static {v10, v12, v14}, Le7/e;->Q(Ljava/lang/CharSequence;Ljava/lang/CharSequence;Z)Z

    move-result v12

    if-nez v12, :cond_8

    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v12, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v10, " ("

    invoke-virtual {v12, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v12, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    :cond_8
    new-instance v9, Landroid/widget/TextView;

    invoke-direct {v9, v2}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    invoke-virtual {v9, v10}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/high16 v10, 0x41a80000    # 21.0f

    invoke-virtual {v9, v10}, Landroid/widget/TextView;->setTextSize(F)V

    invoke-virtual {v9}, Landroid/widget/TextView;->getTypeface()Landroid/graphics/Typeface;

    move-result-object v10

    const/4 v12, 0x1

    invoke-virtual {v9, v10, v12}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    const/4 v10, -0x1

    invoke-virtual {v9, v10}, Landroid/widget/TextView;->setTextColor(I)V

    const/4 v10, 0x2

    invoke-virtual {v9, v10}, Landroid/widget/TextView;->setMaxLines(I)V

    sget-object v12, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    invoke-virtual {v9, v12}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    invoke-virtual {v0, v9}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    invoke-static {v6}, Le7/e;->Y(Ljava/lang/CharSequence;)Z

    move-result v9

    const/high16 v14, 0x41500000    # 13.0f

    if-nez v9, :cond_9

    new-instance v9, Landroid/widget/TextView;

    invoke-direct {v9, v2}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    new-instance v15, Ljava/lang/StringBuilder;

    const-string v11, "\u2605\u2605\u2605\u2605\u2605 ("

    invoke-direct {v15, v11}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v15, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v15, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v9, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {v9, v14}, Landroid/widget/TextView;->setTextSize(F)V

    invoke-virtual {v9}, Landroid/widget/TextView;->getTypeface()Landroid/graphics/Typeface;

    move-result-object v6

    const/4 v11, 0x1

    invoke-virtual {v9, v6, v11}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    const-string v6, "#FBBF24"

    invoke-static {v6}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v6

    invoke-virtual {v9, v6}, Landroid/widget/TextView;->setTextColor(I)V

    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v11, -0x2

    invoke-direct {v6, v11, v11}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/4 v11, 0x4

    invoke-virtual {v2, v11}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    move-result v13

    iput v13, v6, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    invoke-virtual {v9, v6}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v0, v9}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    :cond_9
    invoke-static {v7}, Le7/e;->Y(Ljava/lang/CharSequence;)Z

    move-result v6

    if-nez v6, :cond_a

    goto :goto_6

    :cond_a
    const/4 v7, 0x0

    :goto_6
    iget-object v6, v4, Lm6/p8;->k:Ljava/lang/String;

    invoke-static {v6}, Le7/e;->Y(Ljava/lang/CharSequence;)Z

    move-result v9

    if-nez v9, :cond_b

    goto :goto_7

    :cond_b
    const/4 v6, 0x0

    :goto_7
    iget-object v9, v4, Lm6/p8;->l:Ljava/lang/String;

    sget-object v11, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    const-string v13, "ROOT"

    invoke-static {v11, v13}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v9, v11}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v9

    const-string v11, "toUpperCase(...)"

    invoke-static {v9, v11}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v9}, Le7/e;->Y(Ljava/lang/CharSequence;)Z

    move-result v11

    if-nez v11, :cond_c

    goto :goto_8

    :cond_c
    const/4 v9, 0x0

    :goto_8
    filled-new-array {v7, v6, v9}, [Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Lo6/i;->Z([Ljava/lang/Object;)Ljava/util/ArrayList;

    move-result-object v6

    const-string v7, "  \u2022  "

    const/16 v9, 0x3e

    const/4 v11, 0x0

    invoke-static {v6, v7, v11, v9}, Lo6/j;->b0(Ljava/lang/Iterable;Ljava/lang/String;Lz6/l;I)Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Le7/e;->Y(Ljava/lang/CharSequence;)Z

    move-result v7

    const/high16 v9, 0x41400000    # 12.0f

    if-nez v7, :cond_d

    new-instance v7, Landroid/widget/TextView;

    invoke-direct {v7, v2}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    invoke-virtual {v7, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {v7, v9}, Landroid/widget/TextView;->setTextSize(F)V

    const-string v6, "#38BDF8"

    invoke-static {v6}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v6

    invoke-virtual {v7, v6}, Landroid/widget/TextView;->setTextColor(I)V

    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v11, -0x2

    invoke-direct {v6, v11, v11}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/4 v11, 0x4

    invoke-virtual {v2, v11}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    move-result v13

    iput v13, v6, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    invoke-virtual {v7, v6}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v0, v7}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    :cond_d
    new-instance v6, Landroid/widget/TextView;

    invoke-direct {v6, v2}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    iget-object v7, v4, Lm6/p8;->g:Ljava/lang/String;

    invoke-static {v7}, Le7/e;->Y(Ljava/lang/CharSequence;)Z

    move-result v11

    if-eqz v11, :cond_e

    iget-object v7, v3, Lm6/n;->d:Ljava/lang/String;

    :cond_e
    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {v6, v14}, Landroid/widget/TextView;->setTextSize(F)V

    invoke-virtual {v6}, Landroid/widget/TextView;->getTypeface()Landroid/graphics/Typeface;

    move-result-object v7

    const/4 v11, 0x1

    invoke-virtual {v6, v7, v11}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    const-string v7, "#F8FAFC"

    invoke-static {v7}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v7

    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setTextColor(I)V

    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v11, -0x2

    invoke-direct {v7, v11, v11}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/4 v11, 0x6

    invoke-virtual {v2, v11}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    move-result v13

    iput v13, v7, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    invoke-virtual {v6, v7}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v0, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    invoke-static {v5}, Le7/e;->Y(Ljava/lang/CharSequence;)Z

    move-result v6

    const/4 v7, 0x5

    if-nez v6, :cond_f

    new-instance v6, Landroid/widget/TextView;

    invoke-direct {v6, v2}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    invoke-virtual {v6, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {v6, v9}, Landroid/widget/TextView;->setTextSize(F)V

    const-string v5, "#86EFAC"

    invoke-static {v5}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v5

    invoke-virtual {v6, v5}, Landroid/widget/TextView;->setTextColor(I)V

    invoke-virtual {v6, v10}, Landroid/widget/TextView;->setMaxLines(I)V

    invoke-virtual {v6, v12}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v10, -0x1

    const/4 v13, -0x2

    invoke-direct {v5, v10, v13}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v2, v7}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    move-result v10

    iput v10, v5, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    invoke-virtual {v6, v5}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v0, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    :cond_f
    invoke-static {v1}, Le7/e;->Y(Ljava/lang/CharSequence;)Z

    move-result v5

    if-nez v5, :cond_10

    new-instance v5, Landroid/widget/TextView;

    invoke-direct {v5, v2}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    invoke-virtual {v5, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/high16 v1, 0x41480000    # 12.5f

    invoke-virtual {v5, v1}, Landroid/widget/TextView;->setTextSize(F)V

    const-string v1, "#E2E8F0"

    invoke-static {v1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v5, v1}, Landroid/widget/TextView;->setTextColor(I)V

    const/4 v1, 0x4

    invoke-virtual {v5, v1}, Landroid/widget/TextView;->setMaxLines(I)V

    invoke-virtual {v5, v12}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v10, -0x1

    const/4 v12, -0x2

    invoke-direct {v1, v10, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/4 v6, 0x7

    invoke-virtual {v2, v6}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    move-result v6

    iput v6, v1, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    invoke-virtual {v5, v1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v0, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    :cond_10
    invoke-static/range {v21 .. v21}, Le7/e;->Y(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_11

    new-instance v1, Landroid/widget/TextView;

    invoke-direct {v1, v2}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    new-instance v5, Ljava/lang/StringBuilder;

    const-string v6, "Director: "

    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    move-object/from16 v6, v21

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v1, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {v1, v9}, Landroid/widget/TextView;->setTextSize(F)V

    invoke-virtual {v1}, Landroid/widget/TextView;->getTypeface()Landroid/graphics/Typeface;

    move-result-object v5

    const/4 v12, 0x1

    invoke-virtual {v1, v5, v12}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    const-string v5, "#93C5FD"

    invoke-static {v5}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v5

    invoke-virtual {v1, v5}, Landroid/widget/TextView;->setTextColor(I)V

    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v12, -0x2

    invoke-direct {v5, v12, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v2, v11}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    move-result v6

    iput v6, v5, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    invoke-virtual {v1, v5}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    :cond_11
    invoke-virtual {v8, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    move-object/from16 v9, v20

    invoke-virtual {v9, v8}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    new-instance v8, Landroid/widget/LinearLayout;

    invoke-direct {v8, v2}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v13, 0x0

    invoke-virtual {v8, v13}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v0, 0x10

    invoke-virtual {v8, v0}, Landroid/widget/LinearLayout;->setGravity(I)V

    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v10, -0x1

    const/4 v12, -0x2

    invoke-direct {v0, v10, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/16 v13, 0x12

    invoke-virtual {v2, v13}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    move-result v1

    iput v1, v0, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    invoke-virtual {v8, v0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    iget-object v0, v4, Lm6/p8;->m:Ljava/lang/String;

    invoke-static {v0}, Le7/e;->o0(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v1

    if-nez v1, :cond_13

    :cond_12
    const/4 v0, 0x0

    goto :goto_9

    :cond_13
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    if-lt v0, v7, :cond_12

    const/4 v0, 0x1

    :goto_9
    new-instance v10, Landroid/widget/Button;

    invoke-direct {v10, v2}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    if-eqz v0, :cond_14

    const-string v1, "\ud83c\udfac TRAILER"

    goto :goto_a

    :cond_14
    const-string v1, "TRAILER UNAVAILABLE"

    :goto_a
    invoke-virtual {v10, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v13, 0x0

    invoke-virtual {v10, v13}, Landroid/widget/TextView;->setAllCaps(Z)V

    const/high16 v1, 0x41580000    # 13.5f

    invoke-virtual {v10, v1}, Landroid/widget/TextView;->setTextSize(F)V

    invoke-virtual {v10}, Landroid/widget/TextView;->getTypeface()Landroid/graphics/Typeface;

    move-result-object v5

    const/4 v12, 0x1

    invoke-virtual {v10, v5, v12}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    if-eqz v0, :cond_15

    const/4 v5, -0x1

    goto :goto_b

    :cond_15
    const-string v5, "#94A3B8"

    invoke-static {v5}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v5

    :goto_b
    invoke-virtual {v10, v5}, Landroid/widget/TextView;->setTextColor(I)V

    if-eqz v0, :cond_16

    const v5, 0x7f080055

    goto :goto_c

    :cond_16
    const v5, 0x7f08005b

    :goto_c
    invoke-virtual {v10, v5}, Landroid/view/View;->setBackgroundResource(I)V

    const/4 v5, 0x0

    invoke-virtual {v10, v5}, Landroid/view/View;->setBackgroundTintList(Landroid/content/res/ColorStateList;)V

    const/4 v12, 0x1

    invoke-virtual {v10, v12}, Landroid/view/View;->setFocusable(Z)V

    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v6, 0x2e

    invoke-virtual {v2, v6}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    move-result v7

    const/high16 v12, 0x3f800000    # 1.0f

    const/4 v13, 0x0

    invoke-direct {v5, v13, v7, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    const/16 v12, 0xa

    invoke-virtual {v2, v12}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    move-result v7

    invoke-virtual {v5, v7}, Landroid/view/ViewGroup$MarginLayoutParams;->setMarginEnd(I)V

    invoke-virtual {v10, v5}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v5, Lm6/w1;

    const v7, 0x3f847ae1    # 1.035f

    invoke-direct {v5, v7, v2}, Lm6/w1;-><init>(FLcom/harindra/iptvpro/PlayerActivity;)V

    invoke-virtual {v10, v5}, Landroid/view/View;->setOnFocusChangeListener(Landroid/view/View$OnFocusChangeListener;)V

    new-instance v5, Lm6/p5;

    move-object/from16 v13, v19

    invoke-direct {v5, v0, v2, v13, v4}, Lm6/p5;-><init>(ZLcom/harindra/iptvpro/PlayerActivity;La7/m;Lm6/p8;)V

    invoke-virtual {v10, v5}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    if-eqz v16, :cond_17

    invoke-virtual/range {v16 .. v16}, Lm6/n1;->a()Z

    move-result v0

    if-eqz v0, :cond_17

    const/4 v0, 0x1

    goto :goto_d

    :cond_17
    const/4 v0, 0x0

    :goto_d
    new-instance v14, Landroid/widget/Button;

    invoke-direct {v14, v2}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    if-eqz v0, :cond_18

    invoke-static/range {v16 .. v16}, La7/h;->b(Ljava/lang/Object;)V

    invoke-virtual/range {v16 .. v16}, Lm6/n1;->b()I

    move-result v5

    const-string v15, "\u25b6 RESUME MOVIE ("

    const-string v11, "%)"

    invoke-static {v5, v15, v11}, La0/h;->p(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    goto :goto_e

    :cond_18
    const-string v5, "\u25b6 PLAY MOVIE"

    :goto_e
    invoke-virtual {v14, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v11, 0x0

    invoke-virtual {v14, v11}, Landroid/widget/TextView;->setAllCaps(Z)V

    invoke-virtual {v14, v1}, Landroid/widget/TextView;->setTextSize(F)V

    invoke-virtual {v14}, Landroid/widget/TextView;->getTypeface()Landroid/graphics/Typeface;

    move-result-object v1

    const/4 v5, 0x1

    invoke-virtual {v14, v1, v5}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    const/4 v1, -0x1

    invoke-virtual {v14, v1}, Landroid/widget/TextView;->setTextColor(I)V

    const v15, 0x7f080051

    invoke-virtual {v14, v15}, Landroid/view/View;->setBackgroundResource(I)V

    const/4 v1, 0x0

    invoke-virtual {v14, v1}, Landroid/view/View;->setBackgroundTintList(Landroid/content/res/ColorStateList;)V

    invoke-virtual {v14, v5}, Landroid/view/View;->setFocusable(Z)V

    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    invoke-virtual {v2, v6}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    move-result v5

    const/high16 v6, 0x3f800000    # 1.0f

    invoke-direct {v1, v11, v5, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v14, v1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v1, Lm6/w1;

    invoke-direct {v1, v7, v2}, Lm6/w1;-><init>(FLcom/harindra/iptvpro/PlayerActivity;)V

    invoke-virtual {v14, v1}, Landroid/view/View;->setOnFocusChangeListener(Landroid/view/View$OnFocusChangeListener;)V

    move v6, v0

    new-instance v0, Lm6/q5;

    move-object v5, v4

    move-object v1, v13

    move-object/from16 v7, v16

    move-object v4, v3

    move/from16 v3, p1

    invoke-direct/range {v0 .. v7}, Lm6/q5;-><init>(La7/m;Lcom/harindra/iptvpro/PlayerActivity;ILm6/n;Lm6/p8;ZLm6/n1;)V

    invoke-virtual {v14, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual {v8, v10}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    invoke-virtual {v8, v14}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    invoke-virtual {v9, v8}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    new-instance v8, Landroid/widget/LinearLayout;

    invoke-direct {v8, v2}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v13, 0x0

    invoke-virtual {v8, v13}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const v0, 0x800015

    invoke-virtual {v8, v0}, Landroid/widget/LinearLayout;->setGravity(I)V

    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v10, -0x1

    const/4 v11, -0x2

    invoke-direct {v0, v10, v11}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v2, v12}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    move-result v3

    iput v3, v0, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    invoke-virtual {v8, v0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const v7, 0x7f080052

    if-eqz v6, :cond_19

    new-instance v0, Lm6/r5;

    move/from16 v4, p1

    move-object/from16 v3, p2

    move-object/from16 v5, p3

    invoke-direct/range {v0 .. v5}, Lm6/r5;-><init>(La7/m;Lcom/harindra/iptvpro/PlayerActivity;Lm6/n;ILm6/p8;)V

    const-string v3, "\u23ee Start from Beginning"

    const v4, 0x7f0800ca

    invoke-static {v2, v3, v7, v4, v0}, Landroid/support/v4/media/session/b;->u(Lcom/harindra/iptvpro/PlayerActivity;Ljava/lang/String;IILz6/a;)Landroid/widget/Button;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v3

    const-string v4, "null cannot be cast to non-null type android.widget.LinearLayout.LayoutParams"

    invoke-static {v3, v4}, La7/h;->c(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v3, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v13, 0x0

    invoke-virtual {v3, v13}, Landroid/view/ViewGroup$MarginLayoutParams;->setMarginStart(I)V

    invoke-virtual {v8, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    :cond_19
    if-eqz v17, :cond_1a

    const-string v0, "\u2605 In Watchlist (Remove)"

    :goto_f
    move-object v6, v0

    goto :goto_10

    :cond_1a
    const-string v0, "\u2606 Add to Watchlist"

    goto :goto_f

    :goto_10
    if-eqz v17, :cond_1b

    const v0, 0x7f080053

    :goto_11
    move v10, v0

    goto :goto_12

    :cond_1b
    const v0, 0x7f080054

    goto :goto_11

    :goto_12
    new-instance v0, Lm6/r5;

    move/from16 v5, p1

    move-object/from16 v3, p3

    move-object v4, v1

    move-object v1, v2

    move-object/from16 v2, p2

    invoke-direct/range {v0 .. v5}, Lm6/r5;-><init>(Lcom/harindra/iptvpro/PlayerActivity;Lm6/n;Lm6/p8;La7/m;I)V

    move-object v2, v1

    move-object v1, v4

    const v3, 0x7f0800d5

    invoke-static {v2, v6, v10, v3, v0}, Landroid/support/v4/media/session/b;->u(Lcom/harindra/iptvpro/PlayerActivity;Ljava/lang/String;IILz6/a;)Landroid/widget/Button;

    move-result-object v0

    invoke-virtual {v8, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    invoke-virtual {v2}, Lcom/harindra/iptvpro/PlayerActivity;->x()Z

    move-result v0

    if-eqz v0, :cond_1c

    invoke-virtual {v2}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v0

    iget-object v3, v2, Lcom/harindra/iptvpro/PlayerActivity;->g2:Ljava/lang/String;

    move-object/from16 v10, v18

    invoke-virtual {v0, v10, v3}, Lm6/m6;->Z(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    move-object v5, v1

    move v1, v0

    goto :goto_13

    :cond_1c
    move-object/from16 v10, v18

    move-object v5, v1

    const/4 v1, 0x0

    :goto_13
    if-eqz v1, :cond_1d

    const-string v0, "\u2713 Watched (Mark Unwatched)"

    :goto_14
    move-object v11, v0

    goto :goto_15

    :cond_1d
    const-string v0, "\u2713 Mark Watched"

    goto :goto_14

    :goto_15
    if-eqz v1, :cond_1e

    move v12, v7

    goto :goto_16

    :cond_1e
    const v12, 0x7f080055

    :goto_16
    new-instance v0, Lm6/s5;

    const/4 v7, 0x0

    move/from16 v6, p1

    move-object/from16 v3, p2

    move-object/from16 v4, p3

    invoke-direct/range {v0 .. v7}, Lm6/s5;-><init>(ZLcom/harindra/iptvpro/PlayerActivity;Lm6/n;Lm6/p8;La7/m;II)V

    move-object v1, v5

    const/4 v13, 0x0

    invoke-static {v2, v11, v12, v13, v0}, Landroid/support/v4/media/session/b;->u(Lcom/harindra/iptvpro/PlayerActivity;Ljava/lang/String;IILz6/a;)Landroid/widget/Button;

    move-result-object v0

    invoke-virtual {v8, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    new-instance v0, Lm6/d;

    const/4 v5, 0x5

    invoke-direct/range {v0 .. v5}, Lm6/d;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    const-string v3, "\ud83c\udfac Similar"

    invoke-static {v2, v3, v15, v13, v0}, Landroid/support/v4/media/session/b;->u(Lcom/harindra/iptvpro/PlayerActivity;Ljava/lang/String;IILz6/a;)Landroid/widget/Button;

    move-result-object v0

    invoke-virtual {v8, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    invoke-virtual {v2}, Lcom/harindra/iptvpro/PlayerActivity;->B()Lm6/q1;

    move-result-object v0

    iget-object v3, v2, Lcom/harindra/iptvpro/PlayerActivity;->g2:Ljava/lang/String;

    invoke-virtual {v0, v3}, Lm6/q1;->c(Ljava/lang/String;)Lm6/p1;

    move-result-object v0

    sget-object v3, Lm6/q6;->MOVIE:Lm6/q6;

    invoke-virtual {v0, v3, v10}, Lm6/p1;->b(Lm6/q6;Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_1f

    const-string v3, "\u2713 Queued"

    :goto_17
    move-object v5, v1

    move-object v10, v3

    move v1, v0

    goto :goto_18

    :cond_1f
    const-string v3, "\uff0b Queue"

    goto :goto_17

    :goto_18
    new-instance v0, Lm6/s5;

    const/4 v7, 0x1

    move/from16 v6, p1

    move-object/from16 v3, p2

    move-object/from16 v4, p3

    invoke-direct/range {v0 .. v7}, Lm6/s5;-><init>(ZLcom/harindra/iptvpro/PlayerActivity;Lm6/n;Lm6/p8;La7/m;II)V

    move-object v1, v5

    const v3, 0x7f080056

    const/4 v13, 0x0

    invoke-static {v2, v10, v3, v13, v0}, Landroid/support/v4/media/session/b;->u(Lcom/harindra/iptvpro/PlayerActivity;Ljava/lang/String;IILz6/a;)Landroid/widget/Button;

    move-result-object v0

    invoke-virtual {v8, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    new-instance v0, Lm6/u3;

    const/4 v3, 0x4

    invoke-direct {v0, v1, v3}, Lm6/u3;-><init>(La7/m;I)V

    const-string v3, "Back to Movies"

    const v4, 0x7f080055

    invoke-static {v2, v3, v4, v13, v0}, Landroid/support/v4/media/session/b;->u(Lcom/harindra/iptvpro/PlayerActivity;Ljava/lang/String;IILz6/a;)Landroid/widget/Button;

    move-result-object v0

    invoke-virtual {v8, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    invoke-virtual {v9, v8}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    const/16 v0, 0x2a8

    invoke-static {v2, v9, v0}, Landroid/support/v4/media/session/b;->P(Lcom/harindra/iptvpro/PlayerActivity;Landroid/widget/LinearLayout;I)Li/h;

    move-result-object v0

    iput-object v0, v1, La7/m;->l:Ljava/lang/Object;

    new-instance v0, Lm6/e4;

    const/4 v1, 0x2

    invoke-direct {v0, v14, v1}, Lm6/e4;-><init>(Landroid/widget/Button;I)V

    invoke-virtual {v14, v0}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public static y(ILcom/harindra/iptvpro/PlayerActivity;I)V
    .locals 8

    and-int/lit8 v0, p2, 0x1

    if-eqz v0, :cond_0

    const-wide/16 v0, 0x0

    :goto_0
    move-wide v3, v0

    goto :goto_1

    :cond_0
    const-wide/16 v0, 0x6e

    goto :goto_0

    :goto_1
    and-int/lit8 p2, p2, 0x2

    if-eqz p2, :cond_1

    const/4 p0, -0x1

    :cond_1
    move v6, p0

    const-string p0, "<this>"

    invoke-static {p1, p0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object p0, p1, Lcom/harindra/iptvpro/PlayerActivity;->A1:Lf7/g1;

    const/4 p2, 0x0

    if-eqz p0, :cond_2

    invoke-virtual {p0, p2}, Lf7/b1;->c(Ljava/util/concurrent/CancellationException;)V

    :cond_2
    invoke-static {p1}, Landroidx/lifecycle/i0;->a(Landroidx/lifecycle/r;)Landroidx/lifecycle/m;

    move-result-object p0

    new-instance v2, Lm6/v5;

    const/4 v7, 0x0

    move-object v5, p1

    invoke-direct/range {v2 .. v7}, Lm6/v5;-><init>(JLcom/harindra/iptvpro/PlayerActivity;ILr6/d;)V

    const/4 p1, 0x3

    invoke-static {p0, p2, v2, p1}, Lf7/v;->j(Lf7/s;Lr6/i;Lz6/p;I)Lf7/g1;

    move-result-object p0

    iput-object p0, v5, Lcom/harindra/iptvpro/PlayerActivity;->A1:Lf7/g1;

    return-void
.end method

.method public static final z(Lcom/harindra/iptvpro/PlayerActivity;)V
    .locals 9

    const-string v0, "<this>"

    invoke-static {p0, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v0, Lm6/z0;->a:Lm6/y0;

    sget-object v0, Lm6/z0;->a:Lm6/y0;

    iget v3, v0, Lm6/y0;->b:I

    iget-object v4, v0, Lm6/y0;->c:Ljava/lang/String;

    iget-object v5, v0, Lm6/y0;->d:Ljava/lang/String;

    iget-object v6, v0, Lm6/y0;->e:Ljava/lang/String;

    iget-wide v7, v0, Lm6/y0;->f:J

    const-string v1, "sectionEntered"

    invoke-static {v6, v1}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v1, Lm6/y0;

    const/4 v2, 0x0

    invoke-direct/range {v1 .. v8}, Lm6/y0;-><init>(ZILjava/lang/String;Ljava/lang/String;Ljava/lang/String;J)V

    sput-object v1, Lm6/z0;->a:Lm6/y0;

    iget-object v1, p0, Lcom/harindra/iptvpro/PlayerActivity;->T2:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/Collection;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_2

    iget-boolean v1, v0, Lm6/y0;->a:Z

    if-eqz v1, :cond_2

    iget-object v1, v0, Lm6/y0;->c:Ljava/lang/String;

    invoke-static {v1}, Le7/e;->Y(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_1

    iget-object v1, p0, Lcom/harindra/iptvpro/PlayerActivity;->W2:Ljava/lang/Object;

    iget-object v3, v0, Lm6/y0;->c:Ljava/lang/String;

    invoke-interface {v1, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    if-eqz v1, :cond_0

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v0

    goto :goto_0

    :cond_0
    iget v0, v0, Lm6/y0;->b:I

    iget-object v1, p0, Lcom/harindra/iptvpro/PlayerActivity;->T2:Ljava/util/List;

    invoke-static {v1}, Lo6/k;->J(Ljava/util/List;)I

    move-result v1

    invoke-static {v0, v2, v1}, Lc4/b0;->i(III)I

    move-result v0

    goto :goto_0

    :cond_1
    iget v0, v0, Lm6/y0;->b:I

    iget-object v1, p0, Lcom/harindra/iptvpro/PlayerActivity;->T2:Ljava/util/List;

    invoke-static {v1}, Lo6/k;->J(Ljava/util/List;)I

    move-result v1

    invoke-static {v0, v2, v1}, Lc4/b0;->i(III)I

    move-result v0

    :goto_0
    iput v0, p0, Lcom/harindra/iptvpro/PlayerActivity;->c3:I

    invoke-virtual {p0}, Lcom/harindra/iptvpro/PlayerActivity;->s()Lm6/a0;

    move-result-object v0

    iget v1, p0, Lcom/harindra/iptvpro/PlayerActivity;->c3:I

    invoke-virtual {v0, v1}, Lm6/a0;->l(I)V

    :cond_2
    invoke-virtual {p0}, Lcom/harindra/iptvpro/PlayerActivity;->x()Z

    move-result v0

    const/4 v1, 0x1

    if-eqz v0, :cond_3

    invoke-virtual {p0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v0

    iget-object v0, v0, Lm6/m6;->b:Landroid/content/SharedPreferences;

    const-string v3, "auto_reconnect_live_on_return_v190"

    invoke-interface {v0, v3, v1}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    if-eqz v0, :cond_3

    move v0, v1

    goto :goto_1

    :cond_3
    move v0, v2

    :goto_1
    iget-object v3, p0, Lcom/harindra/iptvpro/PlayerActivity;->I:Ld1/k0;

    if-eqz v3, :cond_6

    invoke-virtual {v3}, Ld1/k0;->D()I

    move-result v3

    if-ne v3, v1, :cond_4

    goto :goto_2

    :cond_4
    iget-object v3, p0, Lcom/harindra/iptvpro/PlayerActivity;->q2:Ljava/lang/String;

    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v3

    if-nez v3, :cond_5

    goto :goto_2

    :cond_5
    move v3, v2

    goto :goto_3

    :cond_6
    :goto_2
    move v3, v1

    :goto_3
    if-eqz v0, :cond_7

    if-eqz v3, :cond_7

    iget-object v0, p0, Lcom/harindra/iptvpro/PlayerActivity;->T2:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_7

    invoke-static {p0, v1}, Lcom/bumptech/glide/c;->D(Lcom/harindra/iptvpro/PlayerActivity;Z)V

    return-void

    :cond_7
    if-eqz v3, :cond_a

    iget-object v0, p0, Lcom/harindra/iptvpro/PlayerActivity;->T2:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_a

    iget-object v0, p0, Lcom/harindra/iptvpro/PlayerActivity;->T2:Ljava/util/List;

    iget v1, p0, Lcom/harindra/iptvpro/PlayerActivity;->c3:I

    invoke-static {v1, v0}, Lo6/j;->Y(ILjava/util/List;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lm6/n;

    if-eqz v0, :cond_8

    iget-object v0, v0, Lm6/n;->c:Ljava/lang/String;

    if-nez v0, :cond_9

    :cond_8
    const-string v0, "Live TV"

    :cond_9
    new-instance v1, Ljava/lang/StringBuilder;

    const-string v3, "\u23f8 "

    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, " Ready \u2022 Press OK / Play to Watch"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "<set-?>"

    invoke-static {v0, v1}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iput-object v0, p0, Lcom/harindra/iptvpro/PlayerActivity;->j2:Ljava/lang/String;

    invoke-static {p0, v2}, Lcom/bumptech/glide/c;->H(Lcom/harindra/iptvpro/PlayerActivity;Z)V

    invoke-static {p0}, Lcom/bumptech/glide/c;->z(Lcom/harindra/iptvpro/PlayerActivity;)V

    :cond_a
    return-void
.end method
