.class public final Lc6/a;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Ljava/lang/Class;

.field public final synthetic b:I


# direct methods
.method public constructor <init>(ILjava/lang/Class;)V
    .locals 0

    .line 1
    iput p1, p0, Lc6/a;->b:I

    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    iput-object p2, p0, Lc6/a;->a:Ljava/lang/Class;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final a(Lcom/google/crypto/tink/shaded/protobuf/a;)Ljava/lang/Object;
    .locals 14

    .line 1
    iget v0, p0, Lc6/a;->b:I

    .line 2
    .line 3
    const/4 v1, 0x4

    .line 4
    const/4 v2, 0x2

    .line 5
    const/4 v3, 0x0

    .line 6
    const/4 v4, 0x1

    .line 7
    packed-switch v0, :pswitch_data_0

    .line 8
    .line 9
    .line 10
    check-cast p1, Lj6/t1;

    .line 11
    .line 12
    new-instance v0, Lk6/c;

    .line 13
    .line 14
    invoke-virtual {p1}, Lj6/t1;->y()Lcom/google/crypto/tink/shaded/protobuf/j;

    .line 15
    .line 16
    .line 17
    move-result-object p1

    .line 18
    invoke-virtual {p1}, Lcom/google/crypto/tink/shaded/protobuf/j;->j()[B

    .line 19
    .line 20
    .line 21
    move-result-object p1

    .line 22
    invoke-direct {v0, v2, p1}, Lk6/c;-><init>(I[B)V

    .line 23
    .line 24
    .line 25
    return-object v0

    .line 26
    :pswitch_0
    check-cast p1, Lj6/o1;

    .line 27
    .line 28
    invoke-virtual {p1}, Lj6/o1;->y()Lj6/p1;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    invoke-virtual {v0}, Lj6/p1;->y()Ljava/lang/String;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    invoke-static {v0}, Lx5/i;->a(Ljava/lang/String;)Ld6/c;

    .line 37
    .line 38
    .line 39
    move-result-object v1

    .line 40
    invoke-virtual {v1, v0}, Ld6/c;->c(Ljava/lang/String;)Ld6/b;

    .line 41
    .line 42
    .line 43
    move-result-object v0

    .line 44
    new-instance v1, Ly5/r;

    .line 45
    .line 46
    invoke-virtual {p1}, Lj6/o1;->y()Lj6/p1;

    .line 47
    .line 48
    .line 49
    move-result-object p1

    .line 50
    invoke-virtual {p1}, Lj6/p1;->x()Lj6/a1;

    .line 51
    .line 52
    .line 53
    move-result-object p1

    .line 54
    invoke-direct {v1, p1, v0}, Ly5/r;-><init>(Lj6/a1;Ld6/b;)V

    .line 55
    .line 56
    .line 57
    return-object v1

    .line 58
    :pswitch_1
    check-cast p1, Lj6/l1;

    .line 59
    .line 60
    invoke-virtual {p1}, Lj6/l1;->y()Lj6/m1;

    .line 61
    .line 62
    .line 63
    move-result-object p1

    .line 64
    invoke-virtual {p1}, Lj6/m1;->x()Ljava/lang/String;

    .line 65
    .line 66
    .line 67
    move-result-object p1

    .line 68
    invoke-static {p1}, Lx5/i;->a(Ljava/lang/String;)Ld6/c;

    .line 69
    .line 70
    .line 71
    move-result-object v0

    .line 72
    invoke-virtual {v0, p1}, Ld6/c;->c(Ljava/lang/String;)Ld6/b;

    .line 73
    .line 74
    .line 75
    move-result-object p1

    .line 76
    return-object p1

    .line 77
    :pswitch_2
    check-cast p1, Lj6/j0;

    .line 78
    .line 79
    new-instance v0, Lk6/c;

    .line 80
    .line 81
    invoke-virtual {p1}, Lj6/j0;->y()Lcom/google/crypto/tink/shaded/protobuf/j;

    .line 82
    .line 83
    .line 84
    move-result-object p1

    .line 85
    invoke-virtual {p1}, Lcom/google/crypto/tink/shaded/protobuf/j;->j()[B

    .line 86
    .line 87
    .line 88
    move-result-object p1

    .line 89
    invoke-direct {v0, v4, p1}, Lk6/c;-><init>(I[B)V

    .line 90
    .line 91
    .line 92
    return-object v0

    .line 93
    :pswitch_3
    check-cast p1, Lj6/b0;

    .line 94
    .line 95
    new-instance v0, La6/b;

    .line 96
    .line 97
    invoke-virtual {p1}, Lj6/b0;->y()Lcom/google/crypto/tink/shaded/protobuf/j;

    .line 98
    .line 99
    .line 100
    move-result-object p1

    .line 101
    invoke-virtual {p1}, Lcom/google/crypto/tink/shaded/protobuf/j;->j()[B

    .line 102
    .line 103
    .line 104
    move-result-object p1

    .line 105
    invoke-direct {v0, p1}, La6/b;-><init>([B)V

    .line 106
    .line 107
    .line 108
    return-object v0

    .line 109
    :pswitch_4
    check-cast p1, Lj6/x;

    .line 110
    .line 111
    new-instance v0, Lk6/c;

    .line 112
    .line 113
    invoke-virtual {p1}, Lj6/x;->y()Lcom/google/crypto/tink/shaded/protobuf/j;

    .line 114
    .line 115
    .line 116
    move-result-object p1

    .line 117
    invoke-virtual {p1}, Lcom/google/crypto/tink/shaded/protobuf/j;->j()[B

    .line 118
    .line 119
    .line 120
    move-result-object p1

    .line 121
    invoke-direct {v0, v3, p1}, Lk6/c;-><init>(I[B)V

    .line 122
    .line 123
    .line 124
    return-object v0

    .line 125
    :pswitch_5
    check-cast p1, Lj6/r;

    .line 126
    .line 127
    new-instance v0, Lk6/b;

    .line 128
    .line 129
    invoke-virtual {p1}, Lj6/r;->z()Lcom/google/crypto/tink/shaded/protobuf/j;

    .line 130
    .line 131
    .line 132
    move-result-object v1

    .line 133
    invoke-virtual {v1}, Lcom/google/crypto/tink/shaded/protobuf/j;->j()[B

    .line 134
    .line 135
    .line 136
    move-result-object v1

    .line 137
    invoke-virtual {p1}, Lj6/r;->A()Lj6/v;

    .line 138
    .line 139
    .line 140
    move-result-object p1

    .line 141
    invoke-virtual {p1}, Lj6/v;->y()I

    .line 142
    .line 143
    .line 144
    move-result p1

    .line 145
    invoke-direct {v0, p1, v1}, Lk6/b;-><init>(I[B)V

    .line 146
    .line 147
    .line 148
    return-object v0

    .line 149
    :pswitch_6
    check-cast p1, Lj6/l;

    .line 150
    .line 151
    new-instance v0, Lk6/a;

    .line 152
    .line 153
    invoke-virtual {p1}, Lj6/l;->A()Lcom/google/crypto/tink/shaded/protobuf/j;

    .line 154
    .line 155
    .line 156
    move-result-object v1

    .line 157
    invoke-virtual {v1}, Lcom/google/crypto/tink/shaded/protobuf/j;->j()[B

    .line 158
    .line 159
    .line 160
    move-result-object v1

    .line 161
    invoke-virtual {p1}, Lj6/l;->B()Lj6/p;

    .line 162
    .line 163
    .line 164
    move-result-object p1

    .line 165
    invoke-virtual {p1}, Lj6/p;->y()I

    .line 166
    .line 167
    .line 168
    move-result p1

    .line 169
    invoke-direct {v0, p1, v1}, Lk6/a;-><init>(I[B)V

    .line 170
    .line 171
    .line 172
    return-object v0

    .line 173
    :pswitch_7
    check-cast p1, Lj6/h;

    .line 174
    .line 175
    new-instance v0, Lk6/g;

    .line 176
    .line 177
    new-instance v5, Lc6/a;

    .line 178
    .line 179
    const-class v6, Lk6/j;

    .line 180
    .line 181
    invoke-direct {v5, v1, v6}, Lc6/a;-><init>(ILjava/lang/Class;)V

    .line 182
    .line 183
    .line 184
    new-array v1, v4, [Lc6/a;

    .line 185
    .line 186
    aput-object v5, v1, v3

    .line 187
    .line 188
    new-instance v5, Ljava/util/HashMap;

    .line 189
    .line 190
    invoke-direct {v5}, Ljava/util/HashMap;-><init>()V

    .line 191
    .line 192
    .line 193
    array-length v7, v1

    .line 194
    move v8, v3

    .line 195
    :goto_0
    const-string v9, "KeyTypeManager constructed with duplicate factories for primitive "

    .line 196
    .line 197
    if-ge v8, v7, :cond_1

    .line 198
    .line 199
    aget-object v10, v1, v8

    .line 200
    .line 201
    iget-object v11, v10, Lc6/a;->a:Ljava/lang/Class;

    .line 202
    .line 203
    invoke-virtual {v5, v11}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    .line 204
    .line 205
    .line 206
    move-result v12

    .line 207
    if-nez v12, :cond_0

    .line 208
    .line 209
    invoke-virtual {v5, v11, v10}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 210
    .line 211
    .line 212
    add-int/lit8 v8, v8, 0x1

    .line 213
    .line 214
    goto :goto_0

    .line 215
    :cond_0
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 216
    .line 217
    new-instance v0, Ljava/lang/StringBuilder;

    .line 218
    .line 219
    invoke-direct {v0, v9}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 220
    .line 221
    .line 222
    invoke-virtual {v11}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    .line 223
    .line 224
    .line 225
    move-result-object v1

    .line 226
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 227
    .line 228
    .line 229
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 230
    .line 231
    .line 232
    move-result-object v0

    .line 233
    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 234
    .line 235
    .line 236
    throw p1

    .line 237
    :cond_1
    array-length v7, v1

    .line 238
    if-lez v7, :cond_2

    .line 239
    .line 240
    aget-object v1, v1, v3

    .line 241
    .line 242
    iget-object v1, v1, Lc6/a;->a:Ljava/lang/Class;

    .line 243
    .line 244
    :cond_2
    invoke-static {v5}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;

    .line 245
    .line 246
    .line 247
    move-result-object v1

    .line 248
    invoke-virtual {p1}, Lj6/h;->z()Lj6/l;

    .line 249
    .line 250
    .line 251
    move-result-object v5

    .line 252
    invoke-interface {v1, v6}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 253
    .line 254
    .line 255
    move-result-object v1

    .line 256
    check-cast v1, Lc6/a;

    .line 257
    .line 258
    const-string v7, " not supported."

    .line 259
    .line 260
    const-string v8, "Requested primitive class "

    .line 261
    .line 262
    if-eqz v1, :cond_7

    .line 263
    .line 264
    invoke-virtual {v1, v5}, Lc6/a;->a(Lcom/google/crypto/tink/shaded/protobuf/a;)Ljava/lang/Object;

    .line 265
    .line 266
    .line 267
    move-result-object v1

    .line 268
    check-cast v1, Lk6/j;

    .line 269
    .line 270
    new-instance v5, Lc6/a;

    .line 271
    .line 272
    const-class v6, Lx5/j;

    .line 273
    .line 274
    invoke-direct {v5, v2, v6}, Lc6/a;-><init>(ILjava/lang/Class;)V

    .line 275
    .line 276
    .line 277
    new-array v2, v4, [Lc6/a;

    .line 278
    .line 279
    aput-object v5, v2, v3

    .line 280
    .line 281
    new-instance v4, Ljava/util/HashMap;

    .line 282
    .line 283
    invoke-direct {v4}, Ljava/util/HashMap;-><init>()V

    .line 284
    .line 285
    .line 286
    array-length v5, v2

    .line 287
    move v10, v3

    .line 288
    :goto_1
    if-ge v10, v5, :cond_4

    .line 289
    .line 290
    aget-object v11, v2, v10

    .line 291
    .line 292
    iget-object v12, v11, Lc6/a;->a:Ljava/lang/Class;

    .line 293
    .line 294
    invoke-virtual {v4, v12}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    .line 295
    .line 296
    .line 297
    move-result v13

    .line 298
    if-nez v13, :cond_3

    .line 299
    .line 300
    invoke-virtual {v4, v12, v11}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 301
    .line 302
    .line 303
    add-int/lit8 v10, v10, 0x1

    .line 304
    .line 305
    goto :goto_1

    .line 306
    :cond_3
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 307
    .line 308
    new-instance v0, Ljava/lang/StringBuilder;

    .line 309
    .line 310
    invoke-direct {v0, v9}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 311
    .line 312
    .line 313
    invoke-virtual {v12}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    .line 314
    .line 315
    .line 316
    move-result-object v1

    .line 317
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 318
    .line 319
    .line 320
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 321
    .line 322
    .line 323
    move-result-object v0

    .line 324
    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 325
    .line 326
    .line 327
    throw p1

    .line 328
    :cond_4
    array-length v5, v2

    .line 329
    if-lez v5, :cond_5

    .line 330
    .line 331
    aget-object v2, v2, v3

    .line 332
    .line 333
    iget-object v2, v2, Lc6/a;->a:Ljava/lang/Class;

    .line 334
    .line 335
    :cond_5
    invoke-static {v4}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;

    .line 336
    .line 337
    .line 338
    move-result-object v2

    .line 339
    invoke-virtual {p1}, Lj6/h;->A()Lj6/q0;

    .line 340
    .line 341
    .line 342
    move-result-object v3

    .line 343
    invoke-interface {v2, v6}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 344
    .line 345
    .line 346
    move-result-object v2

    .line 347
    check-cast v2, Lc6/a;

    .line 348
    .line 349
    if-eqz v2, :cond_6

    .line 350
    .line 351
    invoke-virtual {v2, v3}, Lc6/a;->a(Lcom/google/crypto/tink/shaded/protobuf/a;)Ljava/lang/Object;

    .line 352
    .line 353
    .line 354
    move-result-object v2

    .line 355
    check-cast v2, Lx5/j;

    .line 356
    .line 357
    invoke-virtual {p1}, Lj6/h;->A()Lj6/q0;

    .line 358
    .line 359
    .line 360
    move-result-object p1

    .line 361
    invoke-virtual {p1}, Lj6/q0;->B()Lj6/u0;

    .line 362
    .line 363
    .line 364
    move-result-object p1

    .line 365
    invoke-virtual {p1}, Lj6/u0;->A()I

    .line 366
    .line 367
    .line 368
    move-result p1

    .line 369
    invoke-direct {v0, v1, v2, p1}, Lk6/g;-><init>(Lk6/j;Lx5/j;I)V

    .line 370
    .line 371
    .line 372
    return-object v0

    .line 373
    :cond_6
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 374
    .line 375
    new-instance v0, Ljava/lang/StringBuilder;

    .line 376
    .line 377
    invoke-direct {v0, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 378
    .line 379
    .line 380
    invoke-virtual {v6}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    .line 381
    .line 382
    .line 383
    move-result-object v1

    .line 384
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 385
    .line 386
    .line 387
    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 388
    .line 389
    .line 390
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 391
    .line 392
    .line 393
    move-result-object v0

    .line 394
    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 395
    .line 396
    .line 397
    throw p1

    .line 398
    :cond_7
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 399
    .line 400
    new-instance v0, Ljava/lang/StringBuilder;

    .line 401
    .line 402
    invoke-direct {v0, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 403
    .line 404
    .line 405
    invoke-virtual {v6}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    .line 406
    .line 407
    .line 408
    move-result-object v1

    .line 409
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 410
    .line 411
    .line 412
    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 413
    .line 414
    .line 415
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 416
    .line 417
    .line 418
    move-result-object v0

    .line 419
    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 420
    .line 421
    .line 422
    throw p1

    .line 423
    :pswitch_8
    check-cast p1, Lj6/q0;

    .line 424
    .line 425
    invoke-virtual {p1}, Lj6/q0;->B()Lj6/u0;

    .line 426
    .line 427
    .line 428
    move-result-object v0

    .line 429
    invoke-virtual {v0}, Lj6/u0;->z()Lj6/o0;

    .line 430
    .line 431
    .line 432
    move-result-object v0

    .line 433
    invoke-virtual {p1}, Lj6/q0;->A()Lcom/google/crypto/tink/shaded/protobuf/j;

    .line 434
    .line 435
    .line 436
    move-result-object v3

    .line 437
    invoke-virtual {v3}, Lcom/google/crypto/tink/shaded/protobuf/j;->j()[B

    .line 438
    .line 439
    .line 440
    move-result-object v3

    .line 441
    new-instance v5, Ljavax/crypto/spec/SecretKeySpec;

    .line 442
    .line 443
    const-string v6, "HMAC"

    .line 444
    .line 445
    invoke-direct {v5, v3, v6}, Ljavax/crypto/spec/SecretKeySpec;-><init>([BLjava/lang/String;)V

    .line 446
    .line 447
    .line 448
    invoke-virtual {p1}, Lj6/q0;->B()Lj6/u0;

    .line 449
    .line 450
    .line 451
    move-result-object p1

    .line 452
    invoke-virtual {p1}, Lj6/u0;->A()I

    .line 453
    .line 454
    .line 455
    move-result p1

    .line 456
    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    .line 457
    .line 458
    .line 459
    move-result v0

    .line 460
    if-eq v0, v4, :cond_c

    .line 461
    .line 462
    if-eq v0, v2, :cond_b

    .line 463
    .line 464
    const/4 v2, 0x3

    .line 465
    if-eq v0, v2, :cond_a

    .line 466
    .line 467
    if-eq v0, v1, :cond_9

    .line 468
    .line 469
    const/4 v1, 0x5

    .line 470
    if-ne v0, v1, :cond_8

    .line 471
    .line 472
    new-instance v0, Lk6/l;

    .line 473
    .line 474
    new-instance v1, Ld1/r1;

    .line 475
    .line 476
    const-string v2, "HMACSHA224"

    .line 477
    .line 478
    invoke-direct {v1, v2, v5}, Ld1/r1;-><init>(Ljava/lang/String;Ljavax/crypto/spec/SecretKeySpec;)V

    .line 479
    .line 480
    .line 481
    invoke-direct {v0, v1, p1}, Lk6/l;-><init>(Li6/a;I)V

    .line 482
    .line 483
    .line 484
    goto :goto_2

    .line 485
    :cond_8
    new-instance p1, Ljava/security/GeneralSecurityException;

    .line 486
    .line 487
    const-string v0, "unknown hash"

    .line 488
    .line 489
    invoke-direct {p1, v0}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 490
    .line 491
    .line 492
    throw p1

    .line 493
    :cond_9
    new-instance v0, Lk6/l;

    .line 494
    .line 495
    new-instance v1, Ld1/r1;

    .line 496
    .line 497
    const-string v2, "HMACSHA512"

    .line 498
    .line 499
    invoke-direct {v1, v2, v5}, Ld1/r1;-><init>(Ljava/lang/String;Ljavax/crypto/spec/SecretKeySpec;)V

    .line 500
    .line 501
    .line 502
    invoke-direct {v0, v1, p1}, Lk6/l;-><init>(Li6/a;I)V

    .line 503
    .line 504
    .line 505
    goto :goto_2

    .line 506
    :cond_a
    new-instance v0, Lk6/l;

    .line 507
    .line 508
    new-instance v1, Ld1/r1;

    .line 509
    .line 510
    const-string v2, "HMACSHA256"

    .line 511
    .line 512
    invoke-direct {v1, v2, v5}, Ld1/r1;-><init>(Ljava/lang/String;Ljavax/crypto/spec/SecretKeySpec;)V

    .line 513
    .line 514
    .line 515
    invoke-direct {v0, v1, p1}, Lk6/l;-><init>(Li6/a;I)V

    .line 516
    .line 517
    .line 518
    goto :goto_2

    .line 519
    :cond_b
    new-instance v0, Lk6/l;

    .line 520
    .line 521
    new-instance v1, Ld1/r1;

    .line 522
    .line 523
    const-string v2, "HMACSHA384"

    .line 524
    .line 525
    invoke-direct {v1, v2, v5}, Ld1/r1;-><init>(Ljava/lang/String;Ljavax/crypto/spec/SecretKeySpec;)V

    .line 526
    .line 527
    .line 528
    invoke-direct {v0, v1, p1}, Lk6/l;-><init>(Li6/a;I)V

    .line 529
    .line 530
    .line 531
    goto :goto_2

    .line 532
    :cond_c
    new-instance v0, Lk6/l;

    .line 533
    .line 534
    new-instance v1, Ld1/r1;

    .line 535
    .line 536
    const-string v2, "HMACSHA1"

    .line 537
    .line 538
    invoke-direct {v1, v2, v5}, Ld1/r1;-><init>(Ljava/lang/String;Ljavax/crypto/spec/SecretKeySpec;)V

    .line 539
    .line 540
    .line 541
    invoke-direct {v0, v1, p1}, Lk6/l;-><init>(Li6/a;I)V

    .line 542
    .line 543
    .line 544
    :goto_2
    return-object v0

    .line 545
    :pswitch_9
    check-cast p1, Lj6/b;

    .line 546
    .line 547
    new-instance v0, Lk6/l;

    .line 548
    .line 549
    new-instance v1, Ll4/t;

    .line 550
    .line 551
    invoke-virtual {p1}, Lj6/b;->z()Lcom/google/crypto/tink/shaded/protobuf/j;

    .line 552
    .line 553
    .line 554
    move-result-object v2

    .line 555
    invoke-virtual {v2}, Lcom/google/crypto/tink/shaded/protobuf/j;->j()[B

    .line 556
    .line 557
    .line 558
    move-result-object v2

    .line 559
    invoke-direct {v1, v2}, Ll4/t;-><init>([B)V

    .line 560
    .line 561
    .line 562
    invoke-virtual {p1}, Lj6/b;->A()Lj6/f;

    .line 563
    .line 564
    .line 565
    move-result-object p1

    .line 566
    invoke-virtual {p1}, Lj6/f;->y()I

    .line 567
    .line 568
    .line 569
    move-result p1

    .line 570
    invoke-direct {v0, v1, p1}, Lk6/l;-><init>(Li6/a;I)V

    .line 571
    .line 572
    .line 573
    return-object v0

    .line 574
    :pswitch_a
    check-cast p1, Lj6/f0;

    .line 575
    .line 576
    new-instance v0, Lk6/d;

    .line 577
    .line 578
    invoke-virtual {p1}, Lj6/f0;->y()Lcom/google/crypto/tink/shaded/protobuf/j;

    .line 579
    .line 580
    .line 581
    move-result-object p1

    .line 582
    invoke-virtual {p1}, Lcom/google/crypto/tink/shaded/protobuf/j;->j()[B

    .line 583
    .line 584
    .line 585
    move-result-object p1

    .line 586
    invoke-direct {v0, p1}, Lk6/d;-><init>([B)V

    .line 587
    .line 588
    .line 589
    return-object v0

    .line 590
    nop

    .line 591
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
