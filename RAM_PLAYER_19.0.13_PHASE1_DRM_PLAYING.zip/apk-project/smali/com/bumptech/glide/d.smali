.class public abstract Lcom/bumptech/glide/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Le0/t0;


# direct methods
.method public static A(Lr6/g;Lr6/i;)Lr6/i;
    .locals 2

    const-string v0, "context"

    invoke-static {p1, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v0, Lr6/j;->k:Lr6/j;

    if-ne p1, v0, :cond_0

    return-object p0

    :cond_0
    new-instance v0, Lr6/b;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Lr6/b;-><init>(I)V

    invoke-interface {p1, p0, v0}, Lr6/i;->o(Ljava/lang/Object;Lz6/p;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lr6/i;

    return-object p0
.end method

.method public static B(Ly0/w;II)J
    .locals 7

    invoke-virtual {p0, p1}, Ly0/w;->N(I)V

    invoke-virtual {p0}, Ly0/w;->a()I

    move-result p1

    const/4 v0, 0x5

    const-wide v1, -0x7fffffffffffffffL    # -4.9E-324

    if-ge p1, v0, :cond_0

    return-wide v1

    :cond_0
    invoke-virtual {p0}, Ly0/w;->m()I

    move-result p1

    const/high16 v0, 0x800000

    and-int/2addr v0, p1

    if-eqz v0, :cond_1

    return-wide v1

    :cond_1
    const v0, 0x1fff00

    and-int/2addr v0, p1

    shr-int/lit8 v0, v0, 0x8

    if-eq v0, p2, :cond_2

    return-wide v1

    :cond_2
    and-int/lit8 p1, p1, 0x20

    if-eqz p1, :cond_3

    invoke-virtual {p0}, Ly0/w;->A()I

    move-result p1

    const/4 p2, 0x7

    if-lt p1, p2, :cond_3

    invoke-virtual {p0}, Ly0/w;->a()I

    move-result p1

    if-lt p1, p2, :cond_3

    invoke-virtual {p0}, Ly0/w;->A()I

    move-result p1

    const/16 v0, 0x10

    and-int/2addr p1, v0

    if-ne p1, v0, :cond_3

    const/4 p1, 0x6

    new-array v0, p1, [B

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1, p1}, Ly0/w;->k([BII)V

    aget-byte p0, v0, v1

    int-to-long p0, p0

    const-wide/16 v1, 0xff

    and-long/2addr p0, v1

    const/16 v3, 0x19

    shl-long/2addr p0, v3

    const/4 v3, 0x1

    aget-byte v4, v0, v3

    int-to-long v4, v4

    and-long/2addr v4, v1

    const/16 v6, 0x11

    shl-long/2addr v4, v6

    or-long/2addr p0, v4

    const/4 v4, 0x2

    aget-byte v4, v0, v4

    int-to-long v4, v4

    and-long/2addr v4, v1

    const/16 v6, 0x9

    shl-long/2addr v4, v6

    or-long/2addr p0, v4

    const/4 v4, 0x3

    aget-byte v4, v0, v4

    int-to-long v4, v4

    and-long/2addr v4, v1

    shl-long v3, v4, v3

    or-long/2addr p0, v3

    const/4 v3, 0x4

    aget-byte v0, v0, v3

    int-to-long v3, v0

    and-long/2addr v1, v3

    shr-long v0, v1, p2

    or-long/2addr p0, v0

    return-wide p0

    :cond_3
    return-wide v1
.end method

.method public static final C(Ljava/util/Set;)[B
    .locals 4

    const-string v0, "triggers"

    invoke-static {p0, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-interface {p0}, Ljava/util/Set;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 p0, 0x0

    new-array p0, p0, [B

    return-object p0

    :cond_0
    new-instance v0, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v0}, Ljava/io/ByteArrayOutputStream;-><init>()V

    :try_start_0
    new-instance v1, Ljava/io/ObjectOutputStream;

    invoke-direct {v1, v0}, Ljava/io/ObjectOutputStream;-><init>(Ljava/io/OutputStream;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    invoke-interface {p0}, Ljava/util/Set;->size()I

    move-result v2

    invoke-virtual {v1, v2}, Ljava/io/ObjectOutputStream;->writeInt(I)V

    invoke-interface {p0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lc4/b;

    iget-object v3, v2, Lc4/b;->a:Landroid/net/Uri;

    invoke-virtual {v3}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/io/ObjectOutputStream;->writeUTF(Ljava/lang/String;)V

    iget-boolean v2, v2, Lc4/b;->b:Z

    invoke-virtual {v1, v2}, Ljava/io/ObjectOutputStream;->writeBoolean(Z)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception p0

    goto :goto_1

    :cond_1
    :try_start_2
    invoke-interface {v1}, Ljava/io/Closeable;->close()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    invoke-interface {v0}, Ljava/io/Closeable;->close()V

    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object p0

    const-string v0, "outputStream.toByteArray()"

    invoke-static {p0, v0}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    return-object p0

    :catchall_1
    move-exception p0

    goto :goto_2

    :goto_1
    :try_start_3
    throw p0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    :catchall_2
    move-exception v2

    :try_start_4
    invoke-static {v1, p0}, Ll3/e;->n(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v2
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    :goto_2
    :try_start_5
    throw p0
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_3

    :catchall_3
    move-exception v1

    invoke-static {v0, p0}, Ll3/e;->n(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v1
.end method

.method public static final D(Lcom/harindra/iptvpro/PlayerActivity;)V
    .locals 22

    move-object/from16 v0, p0

    const-string v1, "<this>"

    invoke-static {v0, v1}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v1

    iget-object v1, v1, Lm6/m6;->b:Landroid/content/SharedPreferences;

    const-string v2, "idle_screensaver_mins_v190"

    const/16 v3, 0xa

    invoke-interface {v1, v2, v3}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v1

    const/16 v2, 0x3c

    const/4 v3, 0x0

    invoke-static {v1, v3, v2}, Lc4/b0;->i(III)I

    move-result v1

    new-instance v4, Lm6/v0;

    new-instance v10, Lm6/a1;

    const/16 v2, 0xc

    invoke-direct {v10, v2}, Lm6/a1;-><init>(I)V

    const v5, 0x7f0800ce

    const-string v6, "RAM PLAYER v19.0.9 PATCH10 ULTRA \u2014 AMOLED 3D Edition (Build 195)"

    const-string v7, "Package: com.harindra.iptvpro \u2022 Media3 1.11.1 \u2022 Strict ContentSourceType Separation \u2022 512MB Low-RAM Guard"

    const-string v8, "v19.0 \u2713"

    const/4 v9, 0x1

    invoke-direct/range {v4 .. v10}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    new-instance v5, Lm6/v0;

    const v2, 0x7f10006c

    invoke-virtual {v0, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v7

    const-string v2, "getString(...)"

    invoke-static {v7, v2}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    const v6, 0x7f10006b

    invoke-virtual {v0, v6}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v8

    invoke-static {v8, v2}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v11, Lm6/a3;

    invoke-direct {v11, v0, v3}, Lm6/a3;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const/4 v10, 0x0

    const v6, 0x7f0800d2

    const-string v9, "LEGAL"

    invoke-direct/range {v5 .. v11}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    new-instance v6, Lm6/v0;

    new-instance v12, Lm6/a3;

    const/4 v2, 0x1

    invoke-direct {v12, v0, v2}, Lm6/a3;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const/4 v11, 0x0

    const v7, 0x7f0800c4

    const-string v8, "Run First-Time TV Setup Wizard"

    const-string v9, "Configure TV Performance Mode, UI Density, Overscan Safe-Area & Live TV Background behavior in 1 minute"

    const-string v10, "WIZARD"

    invoke-direct/range {v6 .. v12}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    new-instance v7, Lm6/v0;

    const-string v8, "OFF"

    if-nez v1, :cond_0

    move-object v9, v8

    goto :goto_0

    :cond_0
    const-string v9, "After "

    const-string v10, " Minutes"

    invoke-static {v1, v9, v10}, La0/h;->p(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    :goto_0
    const-string v10, "Ambient Idle Screensaver: "

    invoke-static {v10, v9}, La0/h;->s(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    if-nez v1, :cond_1

    :goto_1
    move-object v11, v8

    goto :goto_2

    :cond_1
    const-string v8, "m"

    invoke-static {v8, v1}, Lq3/e;->c(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v8

    goto :goto_1

    :goto_2
    new-instance v13, Lm6/j2;

    const/4 v14, 0x5

    invoke-direct {v13, v1, v0, v14}, Lm6/j2;-><init>(ILcom/harindra/iptvpro/PlayerActivity;I)V

    const/4 v12, 0x0

    const v8, 0x7f0800d3

    const-string v10, "Tap to cycle idle timeout: 10m \u2192 15m \u2192 30m \u2192 Off \u2192 5m (Displays clock & active profile when idle)"

    invoke-direct/range {v7 .. v13}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    new-instance v15, Lm6/v0;

    new-instance v1, Lm6/a3;

    const/4 v8, 0x2

    invoke-direct {v1, v0, v8}, Lm6/a3;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const/16 v20, 0x0

    const v16, 0x7f0800ca

    const-string v17, "Preview Ambient TV Screensaver Now"

    const-string v18, "Test the low-memory ambient clock screensaver (press any remote key to dismiss)"

    const-string v19, "PREVIEW"

    move-object/from16 v21, v1

    invoke-direct/range {v15 .. v21}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    new-array v1, v14, [Lm6/v0;

    aput-object v4, v1, v3

    aput-object v5, v1, v2

    aput-object v6, v1, v8

    const/4 v2, 0x3

    aput-object v7, v1, v2

    const/4 v2, 0x4

    aput-object v15, v1, v2

    invoke-static {v1}, Lo6/k;->K([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v5

    const-string v4, "v19.0 AMOLED"

    const-string v6, "Back"

    const v1, 0x7f0800ce

    const-string v2, "About, Setup Wizard, Screensaver & Update Center"

    const-string v3, "What\'s New: Live TV Background Stop, Cinematic Home Hub, 15-Category Settings, Duplicate Detector & SXBK_V19 Backup"

    invoke-static/range {v0 .. v6}, Landroid/support/v4/media/session/b;->Y(Lcom/harindra/iptvpro/PlayerActivity;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;)V

    return-void
.end method

.method public static final E(Lcom/harindra/iptvpro/PlayerActivity;)V
    .locals 15

    const-string v0, "<this>"

    invoke-static {p0, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-boolean v0, p0, Lcom/harindra/iptvpro/PlayerActivity;->u1:Z

    if-eqz v0, :cond_0

    return-void

    :cond_0
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/harindra/iptvpro/PlayerActivity;->u1:Z

    new-instance v0, Ljava/text/SimpleDateFormat;

    invoke-virtual {p0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v1

    invoke-virtual {v1}, Lm6/m6;->X()Z

    move-result v1

    if-eqz v1, :cond_1

    const-string v1, "HH:mm"

    goto :goto_0

    :cond_1
    const-string v1, "hh:mm a"

    :goto_0
    sget-object v2, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-direct {v0, v1, v2}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    new-instance v1, Ljava/util/Date;

    invoke-direct {v1}, Ljava/util/Date;-><init>()V

    invoke-virtual {v0, v1}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v7

    new-instance v0, Ljava/text/SimpleDateFormat;

    const-string v1, "EEEE, dd MMMM yyyy"

    invoke-direct {v0, v1, v2}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    new-instance v1, Ljava/util/Date;

    invoke-direct {v1}, Ljava/util/Date;-><init>()V

    invoke-virtual {v0, v1}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Lcom/harindra/iptvpro/PlayerActivity;->T2:Ljava/util/List;

    iget v2, p0, Lcom/harindra/iptvpro/PlayerActivity;->c3:I

    invoke-static {v2, v1}, Lo6/j;->Y(ILjava/util/List;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lm6/n;

    new-instance v8, Lm6/v0;

    const-string v2, "\ud83d\udd52 "

    const-string v3, "  \u2022  "

    invoke-static {v2, v7, v3, v0}, La0/h;->t(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    if-eqz v1, :cond_2

    iget-object v0, v1, Lm6/n;->c:Ljava/lang/String;

    if-nez v0, :cond_3

    :cond_2
    const-string v0, "Live TV"

    :cond_3
    const-string v1, "RAM PLAYER Ambient Mode \u2022 Last Channel: "

    const-string v2, " \u2022 Press OK or Back to wake"

    invoke-static {v1, v0, v2}, Lq3/e;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    new-instance v14, Lm6/l2;

    const/16 v0, 0x16

    invoke-direct {v14, p0, v0}, Lm6/l2;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const v9, 0x7f0800d3

    const-string v12, "AMBIENT"

    const/4 v13, 0x1

    invoke-direct/range {v8 .. v14}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    invoke-static {v8}, Lcom/bumptech/glide/c;->m(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v8

    invoke-static {v7}, La7/h;->b(Ljava/lang/Object;)V

    const-string v9, "Wake Screen"

    const v4, 0x7f0800d3

    const-string v5, "RAM PLAYER Ambient Screensaver"

    const-string v6, "Low-power OLED/LED screen protection active"

    move-object v3, p0

    invoke-static/range {v3 .. v9}, Landroid/support/v4/media/session/b;->Y(Lcom/harindra/iptvpro/PlayerActivity;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;)V

    const/4 p0, 0x0

    iput-boolean p0, v3, Lcom/harindra/iptvpro/PlayerActivity;->u1:Z

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    iput-wide v0, v3, Lcom/harindra/iptvpro/PlayerActivity;->t1:J

    return-void
.end method

.method public static final F(Lcom/harindra/iptvpro/PlayerActivity;)V
    .locals 20

    move-object/from16 v0, p0

    const-string v1, "<this>"

    invoke-static {v0, v1}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v2, Lm6/v0;

    new-instance v8, Lm6/a3;

    const/4 v1, 0x3

    invoke-direct {v8, v0, v1}, Lm6/a3;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const v3, 0x7f0800c6

    const-string v4, "Export Safe Backup (Credentials Redacted)"

    const-string v5, "Exports Favorites, Movie/Series Watchlists, Custom Groups, Watched History & Settings (Excludes passwords)"

    const-string v6, "SAFE BACKUP"

    const/4 v7, 0x1

    invoke-direct/range {v2 .. v8}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    new-instance v3, Lm6/v0;

    new-instance v9, Lm6/a3;

    const/4 v10, 0x4

    invoke-direct {v9, v0, v10}, Lm6/a3;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const/4 v8, 0x0

    const v4, 0x7f0800bd

    const-string v5, "Export Complete Backup (Includes Account Credentials)"

    const-string v6, "Exports all profiles (including M3U/Xtream URLs & passwords), Favorites, Watchlists & Settings"

    const-string v7, "FULL BACKUP"

    invoke-direct/range {v3 .. v9}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    new-instance v11, Lm6/v0;

    new-instance v4, Lm6/a3;

    const/4 v5, 0x5

    invoke-direct {v4, v0, v5}, Lm6/a3;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const/16 v16, 0x0

    const v12, 0x7f0800c6

    const-string v13, "\ud83d\udd10 Export Password-Protected Backup (AES-256-GCM)"

    const-string v14, "Encrypts full profile, favorites, blacklist, home/sidebar & settings with your password"

    const-string v15, "AES-256"

    move-object/from16 v17, v4

    invoke-direct/range {v11 .. v17}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    new-instance v12, Lm6/v0;

    new-instance v4, Lm6/a3;

    const/4 v6, 0x6

    invoke-direct {v4, v0, v6}, Lm6/a3;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const/16 v17, 0x0

    const v13, 0x7f0800d7

    const-string v14, "Restore from SXBK_V19 Backup JSON"

    const-string v15, "Validates versioned backup format before restoring Favorites, Watchlists, Groups & Settings"

    const-string v16, "RESTORE"

    move-object/from16 v18, v4

    invoke-direct/range {v12 .. v18}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    new-instance v13, Lm6/v0;

    new-instance v4, Lm6/a3;

    const/4 v6, 0x7

    invoke-direct {v4, v0, v6}, Lm6/a3;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const/16 v18, 0x0

    const v14, 0x7f0800d9

    const-string v15, "Restore Default App Settings (Keep Profiles & Favorites)"

    const-string v16, "Resets playback, density, overscan & remote settings to recommended defaults without deleting accounts"

    const-string v17, "DEFAULTS"

    move-object/from16 v19, v4

    invoke-direct/range {v13 .. v19}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    new-array v4, v5, [Lm6/v0;

    const/4 v5, 0x0

    aput-object v2, v4, v5

    const/4 v2, 0x1

    aput-object v3, v4, v2

    const/4 v2, 0x2

    aput-object v11, v4, v2

    aput-object v12, v4, v1

    aput-object v13, v4, v10

    invoke-static {v4}, Lo6/k;->K([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v5

    const-string v4, "SXBK_V19"

    const-string v6, "Back"

    const v1, 0x7f0800d7

    const-string v2, "Versioned Backup & Restore (SXBK_V19)"

    const-string v3, "Validated backup format with explicit credential control & safe restore"

    invoke-static/range {v0 .. v6}, Landroid/support/v4/media/session/b;->Y(Lcom/harindra/iptvpro/PlayerActivity;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;)V

    return-void
.end method

.method public static final G(Lcom/harindra/iptvpro/PlayerActivity;Ljava/lang/String;Z)V
    .locals 13

    const-string v0, "<this>"

    invoke-static {p0, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "jsonPayload"

    invoke-static {p1, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "iptv_pro_prefs"

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "last_sxbk_v19_backup"

    invoke-interface {v0, v1, p1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    if-eqz p2, :cond_0

    const-string p2, "Full Backup Saved (Credentials Included)"

    :goto_0
    move-object v2, p2

    goto :goto_1

    :cond_0
    const-string p2, "Safe Backup Saved (Credentials Redacted)"

    goto :goto_0

    :goto_1
    new-instance v3, Lm6/u0;

    const/4 v8, 0x0

    const/16 v9, 0x10

    const-string v4, "BACKUP PAYLOAD (SXBK_V19)"

    const-string v5, ""

    const v6, 0x7f0800c6

    move-object v7, p1

    invoke-direct/range {v3 .. v9}, Lm6/u0;-><init>(Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;II)V

    invoke-static {v3}, Lcom/bumptech/glide/c;->m(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v5

    new-instance v11, Ld7/n;

    const/4 p1, 0x6

    invoke-direct {v11, p1}, Ld7/n;-><init>(I)V

    const/16 v12, 0x9e0

    const v1, 0x7f0800c6

    const-string v3, "Also saved to local recovery slot for instant 1-click restore"

    const-string v4, "SXBK_V19"

    const/4 v6, 0x0

    const/4 v7, 0x0

    const-string v8, "Done"

    const v9, 0x7f080051

    const/4 v10, 0x0

    move-object v0, p0

    invoke-static/range {v0 .. v12}, Landroid/support/v4/media/session/b;->X(Lcom/harindra/iptvpro/PlayerActivity;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;Lz6/a;Ljava/lang/String;IILz6/l;I)V

    return-void
.end method

.method public static final H(I)I
    .locals 1

    const-string v0, "state"

    invoke-static {v0, p0}, La0/h;->B(Ljava/lang/String;I)V

    invoke-static {p0}, Lr0/u;->c(I)I

    move-result p0

    if-eqz p0, :cond_2

    const/4 v0, 0x1

    if-eq p0, v0, :cond_1

    const/4 v0, 0x2

    if-eq p0, v0, :cond_1

    const/4 v0, 0x3

    if-eq p0, v0, :cond_1

    const/4 v0, 0x4

    if-eq p0, v0, :cond_1

    const/4 v0, 0x5

    if-ne p0, v0, :cond_0

    return v0

    :cond_0
    new-instance p0, Lb5/f0;

    invoke-direct {p0}, Ljava/lang/RuntimeException;-><init>()V

    throw p0

    :cond_1
    return v0

    :cond_2
    const/4 p0, 0x0

    return p0
.end method

.method public static final I(Lcom/harindra/iptvpro/PlayerActivity;)V
    .locals 4

    const-string v0, "<this>"

    invoke-static {p0, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, Lcom/harindra/iptvpro/PlayerActivity;->Z2:Ljava/util/Set;

    iget-object v1, p0, Lcom/harindra/iptvpro/PlayerActivity;->T2:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_0

    goto :goto_1

    :cond_0
    iget-object v1, p0, Lcom/harindra/iptvpro/PlayerActivity;->T2:Ljava/util/List;

    iget v2, p0, Lcom/harindra/iptvpro/PlayerActivity;->c3:I

    invoke-interface {v1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lm6/n;

    iget-object v1, v1, Lm6/n;->a:Ljava/lang/String;

    invoke-interface {v0, v1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_1

    invoke-interface {v0, v1}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    const-string v2, "Removed from \u2605 Favorites"

    invoke-static {p0, v2, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v2

    invoke-virtual {v2}, Landroid/widget/Toast;->show()V

    goto :goto_0

    :cond_1
    invoke-interface {v0, v1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    const-string v2, "Added to \u2605 Favorites!"

    invoke-static {p0, v2, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v2

    invoke-virtual {v2}, Landroid/widget/Toast;->show()V

    :goto_0
    const-string v2, "iptv_pro_prefs"

    invoke-virtual {p0, v2, v3}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v2

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    new-instance v3, Ljava/util/HashSet;

    invoke-direct {v3, v0}, Ljava/util/HashSet;-><init>(Ljava/util/Collection;)V

    const-string v0, "fav_ids"

    invoke-interface {v2, v0, v3}, Landroid/content/SharedPreferences$Editor;->putStringSet(Ljava/lang/String;Ljava/util/Set;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    invoke-static {p0, v1}, Lcom/bumptech/glide/d;->J(Lcom/harindra/iptvpro/PlayerActivity;Ljava/lang/String;)V

    invoke-virtual {p0}, Lcom/harindra/iptvpro/PlayerActivity;->y()Landroid/view/View;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    move-result v0

    if-nez v0, :cond_3

    iget-object v0, p0, Lcom/harindra/iptvpro/PlayerActivity;->b3:Ljava/lang/String;

    const-string v1, "FAV"

    invoke-static {v0, v1}, La7/h;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    const/4 v0, 0x7

    invoke-static {p0, v0}, Ll4/f;->w(Lcom/harindra/iptvpro/PlayerActivity;I)V

    return-void

    :cond_2
    invoke-virtual {p0}, Lcom/harindra/iptvpro/PlayerActivity;->s()Lm6/a0;

    move-result-object v0

    iget p0, p0, Lcom/harindra/iptvpro/PlayerActivity;->c3:I

    invoke-virtual {v0, p0}, Lm6/a0;->i(I)I

    move-result p0

    const/4 v1, -0x1

    if-eq p0, v1, :cond_3

    const/4 v1, 0x2

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v0, p0, v1}, Lp3/e0;->c(ILjava/lang/Integer;)V

    :cond_3
    :goto_1
    return-void
.end method

.method public static final J(Lcom/harindra/iptvpro/PlayerActivity;Ljava/lang/String;)V
    .locals 1

    const-string v0, "<this>"

    invoke-static {p0, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "channelId"

    invoke-static {p1, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, Lcom/harindra/iptvpro/PlayerActivity;->Z2:Ljava/util/Set;

    invoke-interface {v0, p1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result p1

    iget-object p0, p0, Lcom/harindra/iptvpro/PlayerActivity;->b0:Landroid/widget/Button;

    if-eqz p0, :cond_1

    if-eqz p1, :cond_0

    const-string p1, "\u2605"

    goto :goto_0

    :cond_0
    const-string p1, "\u2606"

    :goto_0
    invoke-virtual {p0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void

    :cond_1
    const-string p0, "btnToggleFavorite"

    invoke-static {p0}, La7/h;->h(Ljava/lang/String;)V

    const/4 p0, 0x0

    throw p0
.end method

.method public static K(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 2

    const-string v0, "serverUrl"

    invoke-static {p0, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "username"

    invoke-static {p1, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {p0}, Le7/e;->o0(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {p1}, Le7/e;->o0(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "xtream_"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, "_"

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lcom/bumptech/glide/d;->o(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const-string p1, "live_"

    invoke-static {p1, p0}, La0/h;->s(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static final d(Lcom/harindra/iptvpro/PlayerActivity;Ljava/lang/String;)V
    .locals 3

    const-string v0, "<this>"

    invoke-static {p0, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    :try_start_0
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/Window;->getAttributes()Landroid/view/WindowManager$LayoutParams;

    move-result-object v0

    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result v1

    const v2, -0x5974c1e6

    if-eq v1, v2, :cond_4

    const v2, -0x4bf8a61d

    if-eq v1, v2, :cond_2

    const v2, -0x117954a5

    if-eq v1, v2, :cond_0

    goto :goto_0

    :cond_0
    const-string v1, "NIGHT_EYECARE"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_1

    goto :goto_0

    :cond_1
    const p1, 0x3eb33333    # 0.35f

    goto :goto_1

    :cond_2
    const-string v1, "VIVID_MAX"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_3

    goto :goto_0

    :cond_3
    const/high16 p1, 0x3f800000    # 1.0f

    goto :goto_1

    :cond_4
    const-string v1, "CINEMA_DIM"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_5

    :goto_0
    const/high16 p1, -0x40800000    # -1.0f

    goto :goto_1

    :cond_5
    const p1, 0x3f0ccccd    # 0.55f

    :goto_1
    iput p1, v0, Landroid/view/WindowManager$LayoutParams;->screenBrightness:F

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object p0

    invoke-virtual {p0, v0}, Landroid/view/Window;->setAttributes(Landroid/view/WindowManager$LayoutParams;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return-void

    :catchall_0
    move-exception p0

    invoke-static {p0}, Lw7/d;->g(Ljava/lang/Throwable;)Ln6/e;

    return-void
.end method

.method public static final e(Lcom/harindra/iptvpro/PlayerActivity;I)V
    .locals 4

    const-string v0, "<this>"

    invoke-static {p0, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, Lcom/harindra/iptvpro/PlayerActivity;->v2:Ljava/util/List;

    invoke-static {v0}, Lo6/k;->I(Ljava/util/Collection;)Lb7/c;

    move-result-object v1

    iget v2, v1, Lb7/a;->l:I

    invoke-virtual {v1}, Lb7/c;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_4

    if-gez p1, :cond_0

    const/4 p1, 0x0

    goto :goto_0

    :cond_0
    if-le p1, v2, :cond_1

    move p1, v2

    :cond_1
    :goto_0
    iput p1, p0, Lcom/harindra/iptvpro/PlayerActivity;->w2:I

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lm6/j8;

    iget-object v0, p1, Lm6/j8;->d:Ljava/lang/String;

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iget-object v1, p1, Lm6/j8;->e:Ljava/lang/String;

    invoke-static {v1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {p0}, Lcom/harindra/iptvpro/PlayerActivity;->I()Landroid/widget/TextView;

    move-result-object v2

    invoke-virtual {v2, v0}, Landroid/widget/TextView;->setTextColor(I)V

    invoke-virtual {p0}, Lcom/harindra/iptvpro/PlayerActivity;->G()Landroid/widget/TextView;

    move-result-object v0

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    iget-object v0, p0, Lcom/harindra/iptvpro/PlayerActivity;->b3:Ljava/lang/String;

    invoke-static {p0, v0}, Ll3/e;->W(Lcom/harindra/iptvpro/PlayerActivity;Ljava/lang/String;)V

    invoke-virtual {p0}, Lcom/harindra/iptvpro/PlayerActivity;->s()Lm6/a0;

    move-result-object p0

    iget p1, p1, Lm6/j8;->f:I

    iget v0, p0, Lm6/a0;->m:I

    if-ne v0, p1, :cond_2

    goto :goto_1

    :cond_2
    iput p1, p0, Lm6/a0;->m:I

    iget p1, p0, Lm6/a0;->l:I

    invoke-virtual {p0, p1}, Lm6/a0;->i(I)I

    move-result p1

    const/4 v0, -0x1

    if-eq p1, v0, :cond_3

    const/4 v0, 0x1

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-virtual {p0, p1, v0}, Lp3/e0;->c(ILjava/lang/Integer;)V

    :cond_3
    :goto_1
    return-void

    :cond_4
    new-instance p0, Ljava/lang/IllegalArgumentException;

    new-instance p1, Ljava/lang/StringBuilder;

    const-string v0, "Cannot coerce value to an empty range: "

    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/16 v0, 0x2e

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static f()Lb8/e;
    .locals 7

    sget-object v0, Lb8/e;->l:Lb8/e;

    invoke-static {v0}, La7/h;->b(Ljava/lang/Object;)V

    iget-object v0, v0, Lb8/e;->f:Lb8/e;

    const/4 v1, 0x0

    if-nez v0, :cond_1

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v2

    sget-object v0, Lb8/e;->i:Ljava/util/concurrent/locks/Condition;

    sget-wide v4, Lb8/e;->j:J

    sget-object v6, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    invoke-interface {v0, v4, v5, v6}, Ljava/util/concurrent/locks/Condition;->await(JLjava/util/concurrent/TimeUnit;)Z

    sget-object v0, Lb8/e;->l:Lb8/e;

    invoke-static {v0}, La7/h;->b(Ljava/lang/Object;)V

    iget-object v0, v0, Lb8/e;->f:Lb8/e;

    if-nez v0, :cond_0

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v4

    sub-long/2addr v4, v2

    sget-wide v2, Lb8/e;->k:J

    cmp-long v0, v4, v2

    if-ltz v0, :cond_0

    sget-object v0, Lb8/e;->l:Lb8/e;

    return-object v0

    :cond_0
    return-object v1

    :cond_1
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v2

    iget-wide v4, v0, Lb8/e;->g:J

    sub-long/2addr v4, v2

    const-wide/16 v2, 0x0

    cmp-long v2, v4, v2

    if-lez v2, :cond_2

    sget-object v0, Lb8/e;->i:Ljava/util/concurrent/locks/Condition;

    sget-object v2, Ljava/util/concurrent/TimeUnit;->NANOSECONDS:Ljava/util/concurrent/TimeUnit;

    invoke-interface {v0, v4, v5, v2}, Ljava/util/concurrent/locks/Condition;->await(JLjava/util/concurrent/TimeUnit;)Z

    return-object v1

    :cond_2
    sget-object v2, Lb8/e;->l:Lb8/e;

    invoke-static {v2}, La7/h;->b(Ljava/lang/Object;)V

    iget-object v3, v0, Lb8/e;->f:Lb8/e;

    iput-object v3, v2, Lb8/e;->f:Lb8/e;

    iput-object v1, v0, Lb8/e;->f:Lb8/e;

    return-object v0
.end method

.method public static g([B)Ljava/lang/String;
    .locals 5

    new-instance v0, Ljava/lang/StringBuilder;

    array-length v1, p0

    mul-int/lit8 v1, v1, 0x2

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(I)V

    const/4 v1, 0x0

    move v2, v1

    :goto_0
    array-length v3, p0

    if-ge v2, v3, :cond_0

    aget-byte v3, p0, v2

    invoke-static {v3}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object v3

    const/4 v4, 0x1

    new-array v4, v4, [Ljava/lang/Object;

    aput-object v3, v4, v1

    const-string v3, "%02x"

    invoke-static {v3, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_0
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static final h([B)Ljava/util/LinkedHashSet;
    .locals 8

    const-string v0, "bytes"

    invoke-static {p0, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v0, Ljava/util/LinkedHashSet;

    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    array-length v1, p0

    if-nez v1, :cond_0

    return-object v0

    :cond_0
    new-instance v1, Ljava/io/ByteArrayInputStream;

    invoke-direct {v1, p0}, Ljava/io/ByteArrayInputStream;-><init>([B)V

    :try_start_0
    new-instance p0, Ljava/io/ObjectInputStream;

    invoke-direct {p0, v1}, Ljava/io/ObjectInputStream;-><init>(Ljava/io/InputStream;)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    invoke-virtual {p0}, Ljava/io/ObjectInputStream;->readInt()I

    move-result v2

    const/4 v3, 0x0

    :goto_0
    if-ge v3, v2, :cond_1

    invoke-virtual {p0}, Ljava/io/ObjectInputStream;->readUTF()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v4

    invoke-virtual {p0}, Ljava/io/ObjectInputStream;->readBoolean()Z

    move-result v5

    new-instance v6, Lc4/b;

    const-string v7, "uri"

    invoke-static {v4, v7}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {v6, v4, v5}, Lc4/b;-><init>(Landroid/net/Uri;Z)V

    invoke-interface {v0, v6}, Ljava/util/Set;->add(Ljava/lang/Object;)Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :catchall_0
    move-exception v2

    goto :goto_1

    :cond_1
    :try_start_2
    invoke-virtual {p0}, Ljava/io/ObjectInputStream;->close()V
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    goto :goto_3

    :catchall_1
    move-exception p0

    goto :goto_4

    :catch_0
    move-exception p0

    goto :goto_2

    :goto_1
    :try_start_3
    throw v2
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    :catchall_2
    move-exception v3

    :try_start_4
    invoke-static {p0, v2}, Ll3/e;->n(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v3
    :try_end_4
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_0
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    :goto_2
    :try_start_5
    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    :goto_3
    invoke-virtual {v1}, Ljava/io/ByteArrayInputStream;->close()V

    return-object v0

    :goto_4
    :try_start_6
    throw p0
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_3

    :catchall_3
    move-exception v0

    invoke-static {v1, p0}, Ll3/e;->n(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v0
.end method

.method public static final i(Landroidx/work/impl/WorkDatabase;Lc1/c;Ld4/m;)V
    .locals 5

    const-string v0, "workDatabase"

    invoke-static {p0, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "configuration"

    invoke-static {p1, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x18

    if-ge v0, v1, :cond_0

    goto/16 :goto_4

    :cond_0
    const/4 v0, 0x1

    new-array v1, v0, [Ld4/m;

    const/4 v2, 0x0

    aput-object p2, v1, v2

    new-instance p2, Ljava/util/ArrayList;

    new-instance v3, Lo6/g;

    invoke-direct {v3, v1, v0}, Lo6/g;-><init>([Ljava/lang/Object;Z)V

    invoke-direct {p2, v3}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    move v0, v2

    :goto_0
    invoke-interface {p2}, Ljava/util/Collection;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_6

    invoke-virtual {p2}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_5

    invoke-static {p2}, Lo6/k;->J(Ljava/util/List;)I

    move-result v1

    invoke-virtual {p2, v1}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ld4/m;

    iget-object v1, v1, Ld4/m;->f:Ljava/util/List;

    const-string v3, "current.work"

    invoke-static {v1, v3}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-interface {v1}, Ljava/util/Collection;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_1

    move v3, v2

    goto :goto_2

    :cond_1
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    move v3, v2

    :cond_2
    :goto_1
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_4

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lc4/c0;

    iget-object v4, v4, Lc4/c0;->b:Ll4/q;

    iget-object v4, v4, Ll4/q;->j:Lc4/c;

    invoke-virtual {v4}, Lc4/c;->a()Z

    move-result v4

    if-eqz v4, :cond_2

    add-int/lit8 v3, v3, 0x1

    if-ltz v3, :cond_3

    goto :goto_1

    :cond_3
    invoke-static {}, Lo6/k;->M()V

    const/4 p0, 0x0

    throw p0

    :cond_4
    :goto_2
    add-int/2addr v0, v3

    goto :goto_0

    :cond_5
    new-instance p0, Ljava/util/NoSuchElementException;

    const-string p1, "List is empty."

    invoke-direct {p0, p1}, Ljava/util/NoSuchElementException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_6
    if-nez v0, :cond_7

    goto :goto_4

    :cond_7
    invoke-virtual {p0}, Landroidx/work/impl/WorkDatabase;->t()Ll4/r;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string p2, "Select COUNT(*) FROM workspec WHERE LENGTH(content_uri_triggers)<>0 AND state NOT IN (2, 3, 5)"

    invoke-static {p2, v2}, Lq3/l;->a(Ljava/lang/String;I)Lq3/l;

    move-result-object p2

    iget-object p0, p0, Ll4/r;->a:Landroidx/work/impl/WorkDatabase_Impl;

    invoke-virtual {p0}, Landroidx/work/impl/WorkDatabase;->b()V

    invoke-static {p0, p2, v2}, Lw7/d;->x(Landroidx/work/impl/WorkDatabase;Lq3/l;Z)Landroid/database/Cursor;

    move-result-object p0

    :try_start_0
    invoke-interface {p0}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v1

    if-eqz v1, :cond_8

    invoke-interface {p0, v2}, Landroid/database/Cursor;->getInt(I)I

    move-result v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_3

    :catchall_0
    move-exception p1

    goto :goto_5

    :cond_8
    :goto_3
    invoke-interface {p0}, Landroid/database/Cursor;->close()V

    invoke-virtual {p2}, Lq3/l;->g()V

    iget p0, p1, Lc1/c;->c:I

    add-int p1, v2, v0

    if-gt p1, p0, :cond_9

    :goto_4
    return-void

    :cond_9
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string p2, ";\nalready enqueued count: "

    const-string v1, ";\ncurrent enqueue operation count: "

    const-string v3, "Too many workers with contentUriTriggers are enqueued:\ncontentUriTrigger workers limit: "

    invoke-static {p0, v2, v3, p2, v1}, La0/h;->y(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    const-string p2, ".\nTo address this issue you can: \n1. enqueue less workers or batch some of workers with content uri triggers together;\n2. increase limit via Configuration.Builder.setContentUriTriggerWorkersLimit;\nPlease beware that workers with content uri triggers immediately occupy slots in JobScheduler so no updates to content uris are missed."

    invoke-static {p0, v0, p2}, La0/h;->v(Ljava/lang/StringBuilder;ILjava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1

    :goto_5
    invoke-interface {p0}, Landroid/database/Cursor;->close()V

    invoke-virtual {p2}, Lq3/l;->g()V

    throw p1
.end method

.method public static j(Ljava/io/Serializable;)[J
    .locals 4

    instance-of v0, p0, [I

    if-eqz v0, :cond_1

    check-cast p0, [I

    array-length v0, p0

    new-array v0, v0, [J

    const/4 v1, 0x0

    :goto_0
    array-length v2, p0

    if-ge v1, v2, :cond_0

    aget v2, p0, v1

    int-to-long v2, v2

    aput-wide v2, v0, v1

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    return-object v0

    :cond_1
    instance-of v0, p0, [J

    if-eqz v0, :cond_2

    check-cast p0, [J

    return-object p0

    :cond_2
    const/4 p0, 0x0

    return-object p0
.end method

.method public static final k(Ljava/io/InputStream;Ljava/io/FileOutputStream;I)V
    .locals 2

    new-array p2, p2, [B

    invoke-virtual {p0, p2}, Ljava/io/InputStream;->read([B)I

    move-result v0

    :goto_0
    if-ltz v0, :cond_0

    const/4 v1, 0x0

    invoke-virtual {p1, p2, v1, v0}, Ljava/io/OutputStream;->write([BII)V

    invoke-virtual {p0, p2}, Ljava/io/InputStream;->read([B)I

    move-result v0

    goto :goto_0

    :cond_0
    return-void
.end method

.method public static final l(Lcom/harindra/iptvpro/PlayerActivity;)Lm6/k9;
    .locals 4

    const-string v0, "<this>"

    invoke-static {p0, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v0, Lm6/k9;->Companion:Lm6/j9;

    const-string v1, "ram_player_patch6"

    const/4 v2, 0x0

    invoke-virtual {p0, v1, v2}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p0

    const-string v1, "zap_scope"

    const/4 v2, 0x0

    invoke-interface {p0, v1, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Lm6/k9;->a()Lu6/a;

    move-result-object v0

    check-cast v0, Lo6/d;

    invoke-virtual {v0}, Lo6/d;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    move-object v1, v0

    check-cast v1, La7/a;

    invoke-virtual {v1}, La7/a;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_1

    invoke-virtual {v1}, La7/a;->next()Ljava/lang/Object;

    move-result-object v1

    move-object v3, v1

    check-cast v3, Lm6/k9;

    invoke-virtual {v3}, Lm6/k9;->b()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3, p0}, La7/h;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_0

    move-object v2, v1

    :cond_1
    check-cast v2, Lm6/k9;

    if-nez v2, :cond_2

    sget-object p0, Lm6/k9;->ALL:Lm6/k9;

    return-object p0

    :cond_2
    return-object v2
.end method

.method public static final m(Lcom/harindra/iptvpro/PlayerActivity;)V
    .locals 6

    const-string v0, "<this>"

    invoke-static {p0, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, Lcom/harindra/iptvpro/PlayerActivity;->d2:Lm6/w8;

    iget-object v1, p0, Lcom/harindra/iptvpro/PlayerActivity;->c2:Lm6/n6;

    sget-object v2, Lm6/n6;->XTREAM:Lm6/n6;

    const/4 v3, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-ne v1, v2, :cond_0

    if-eqz v0, :cond_0

    const-string v1, "\ud83d\udd04 Syncing fresh catalogs from Xtream Server..."

    invoke-static {p0, v1, v5}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v1

    invoke-virtual {v1}, Landroid/widget/Toast;->show()V

    invoke-static {p0, v0, v4, v3}, Lw7/d;->p(Lcom/harindra/iptvpro/PlayerActivity;Lm6/w8;ZLjava/lang/String;)V

    return-void

    :cond_0
    sget-object v0, Lm6/n6;->M3U:Lm6/n6;

    if-ne v1, v0, :cond_1

    iget-object v0, p0, Lcom/harindra/iptvpro/PlayerActivity;->e2:Ljava/lang/String;

    invoke-static {v0}, Le7/e;->Y(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_1

    const-string v0, "\ud83d\udd04 Syncing fresh M3U Live TV playlist..."

    invoke-static {p0, v0, v5}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    iget-object v0, p0, Lcom/harindra/iptvpro/PlayerActivity;->e2:Ljava/lang/String;

    iget-object v1, p0, Lcom/harindra/iptvpro/PlayerActivity;->f2:Ljava/lang/String;

    invoke-static {p0, v0, v1, v4, v3}, Lcom/bumptech/glide/c;->n(Lcom/harindra/iptvpro/PlayerActivity;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;)V

    return-void

    :cond_1
    const-string v0, "Connect an Xtream or M3U account first to sync"

    invoke-static {p0, v0, v5}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p0

    invoke-virtual {p0}, Landroid/widget/Toast;->show()V

    return-void
.end method

.method public static n(Landroid/widget/EdgeEffect;)F
    .locals 2

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1f

    if-lt v0, v1, :cond_0

    invoke-static {p0}, Lj0/e;->b(Landroid/widget/EdgeEffect;)F

    move-result p0

    return p0

    :cond_0
    const/4 p0, 0x0

    return p0
.end method

.method public static o(Ljava/lang/String;)Ljava/lang/String;
    .locals 7

    const-string v0, "raw"

    invoke-static {p0, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "SHA-256"

    invoke-static {v0}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    move-result-object v0

    sget-object v1, Le7/a;->a:Ljava/nio/charset/Charset;

    invoke-virtual {p0, v1}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object p0

    const-string v1, "getBytes(...)"

    invoke-static {p0, v1}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v0, p0}, Ljava/security/MessageDigest;->digest([B)[B

    move-result-object p0

    invoke-static {p0}, La7/h;->b(Ljava/lang/Object;)V

    array-length v0, p0

    const/16 v1, 0xc

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-lt v1, v0, :cond_2

    array-length v0, p0

    if-eqz v0, :cond_1

    if-eq v0, v2, :cond_0

    new-instance v0, Ljava/util/ArrayList;

    array-length v1, p0

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    array-length v1, p0

    :goto_0
    if-ge v3, v1, :cond_4

    aget-byte v2, p0, v3

    invoke-static {v2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_0
    aget-byte p0, p0, v3

    invoke-static {p0}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p0

    invoke-static {p0}, Lcom/bumptech/glide/c;->m(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    goto :goto_2

    :cond_1
    sget-object v0, Lo6/r;->k:Lo6/r;

    goto :goto_2

    :cond_2
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    array-length v4, p0

    move v5, v3

    :goto_1
    if-ge v3, v4, :cond_4

    aget-byte v6, p0, v3

    invoke-static {v6}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object v6

    invoke-virtual {v0, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/2addr v5, v2

    if-ne v5, v1, :cond_3

    goto :goto_2

    :cond_3
    add-int/lit8 v3, v3, 0x1

    goto :goto_1

    :cond_4
    :goto_2
    new-instance p0, Ld7/n;

    const/16 v1, 0xc

    invoke-direct {p0, v1}, Ld7/n;-><init>(I)V

    const/16 v1, 0x1e

    const-string v2, ""

    invoke-static {v0, v2, p0, v1}, Lo6/j;->b0(Ljava/lang/Iterable;Ljava/lang/String;Lz6/l;I)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static final p(I)I
    .locals 3

    const/4 v0, 0x1

    if-eqz p0, :cond_1

    if-ne p0, v0, :cond_0

    const/4 p0, 0x2

    return p0

    :cond_0
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "Could not convert "

    const-string v2, " to BackoffPolicy"

    invoke-static {p0, v1, v2}, La0/h;->p(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_1
    return v0
.end method

.method public static final q(I)I
    .locals 3

    const/4 v0, 0x1

    if-eqz p0, :cond_5

    const/4 v1, 0x2

    if-eq p0, v0, :cond_4

    const/4 v0, 0x3

    if-eq p0, v1, :cond_3

    const/4 v1, 0x4

    if-eq p0, v0, :cond_2

    const/4 v0, 0x5

    if-eq p0, v1, :cond_1

    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x1e

    if-lt v1, v2, :cond_0

    if-ne p0, v0, :cond_0

    const/4 p0, 0x6

    return p0

    :cond_0
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "Could not convert "

    const-string v2, " to NetworkType"

    invoke-static {p0, v1, v2}, La0/h;->p(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_1
    return v0

    :cond_2
    return v1

    :cond_3
    return v0

    :cond_4
    return v1

    :cond_5
    return v0
.end method

.method public static final r(I)I
    .locals 3

    const/4 v0, 0x1

    if-eqz p0, :cond_1

    if-ne p0, v0, :cond_0

    const/4 p0, 0x2

    return p0

    :cond_0
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "Could not convert "

    const-string v2, " to OutOfQuotaPolicy"

    invoke-static {p0, v1, v2}, La0/h;->p(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_1
    return v0
.end method

.method public static final s(I)I
    .locals 3

    const/4 v0, 0x1

    if-eqz p0, :cond_5

    const/4 v1, 0x2

    if-eq p0, v0, :cond_4

    const/4 v0, 0x3

    if-eq p0, v1, :cond_3

    const/4 v1, 0x4

    if-eq p0, v0, :cond_2

    const/4 v0, 0x5

    if-eq p0, v1, :cond_1

    if-ne p0, v0, :cond_0

    const/4 p0, 0x6

    return p0

    :cond_0
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "Could not convert "

    const-string v2, " to State"

    invoke-static {p0, v1, v2}, La0/h;->p(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_1
    return v0

    :cond_2
    return v1

    :cond_3
    return v0

    :cond_4
    return v1

    :cond_5
    return v0
.end method

.method public static t(Landroid/net/Uri;)Z
    .locals 2

    if-eqz p0, :cond_0

    const-string v0, "content"

    invoke-virtual {p0}, Landroid/net/Uri;->getScheme()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const-string v0, "media"

    invoke-virtual {p0}, Landroid/net/Uri;->getAuthority()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    return p0

    :cond_0
    const/4 p0, 0x0

    return p0
.end method

.method public static u(B)Z
    .locals 1

    const/16 v0, -0x41

    if-le p0, v0, :cond_0

    const/4 p0, 0x1

    return p0

    :cond_0
    const/4 p0, 0x0

    return p0
.end method

.method public static v(Ljava/lang/String;)Ljava/lang/String;
    .locals 1

    const-string v0, "source"

    invoke-static {p0, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const/16 v0, 0x100

    invoke-static {p0, v0}, Le7/e;->n0(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object p0

    const-string v0, "m3u_live_"

    invoke-virtual {v0, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lcom/bumptech/glide/d;->o(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static w(Lr6/g;Lr6/h;)Lr6/i;
    .locals 1

    const-string v0, "key"

    invoke-static {p1, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-interface {p0}, Lr6/g;->getKey()Lr6/h;

    move-result-object v0

    invoke-static {v0, p1}, La7/h;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    sget-object p0, Lr6/j;->k:Lr6/j;

    :cond_0
    return-object p0
.end method

.method public static final x(I)I
    .locals 3

    const-string v0, "networkType"

    invoke-static {v0, p0}, La0/h;->B(Ljava/lang/String;I)V

    invoke-static {p0}, Lr0/u;->c(I)I

    move-result v0

    if-eqz v0, :cond_2

    const/4 v1, 0x1

    if-eq v0, v1, :cond_1

    const/4 v1, 0x2

    if-eq v0, v1, :cond_1

    const/4 v1, 0x3

    if-eq v0, v1, :cond_1

    const/4 v1, 0x4

    if-eq v0, v1, :cond_1

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1e

    if-lt v0, v1, :cond_0

    const/4 v0, 0x6

    if-ne p0, v0, :cond_0

    const/4 p0, 0x5

    return p0

    :cond_0
    new-instance v0, Ljava/lang/IllegalArgumentException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Could not convert "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-static {p0}, La0/h;->F(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, " to int"

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_1
    return v1

    :cond_2
    const/4 p0, 0x0

    return p0
.end method

.method public static final y(Lcom/harindra/iptvpro/PlayerActivity;Z)I
    .locals 8

    iget-object v0, p0, Lcom/harindra/iptvpro/PlayerActivity;->Z2:Ljava/util/Set;

    iget-object v1, p0, Lcom/harindra/iptvpro/PlayerActivity;->T2:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    iget-object v2, p0, Lcom/harindra/iptvpro/PlayerActivity;->I2:Lm6/k9;

    if-nez v2, :cond_0

    invoke-static {p0}, Lcom/bumptech/glide/d;->l(Lcom/harindra/iptvpro/PlayerActivity;)Lm6/k9;

    move-result-object v2

    iput-object v2, p0, Lcom/harindra/iptvpro/PlayerActivity;->I2:Lm6/k9;

    :cond_0
    iget-object v3, p0, Lcom/harindra/iptvpro/PlayerActivity;->T2:Ljava/util/List;

    iget v4, p0, Lcom/harindra/iptvpro/PlayerActivity;->c3:I

    invoke-static {v4, v3}, Lo6/j;->Y(ILjava/util/List;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lm6/n;

    sget-object v4, Lm6/k9;->ALL:Lm6/k9;

    const/4 v5, -0x1

    const/4 v6, 0x1

    if-eq v2, v4, :cond_d

    if-nez v3, :cond_1

    goto/16 :goto_3

    :cond_1
    sget-object v4, Lm6/k9;->CATEGORY:Lm6/k9;

    const/4 v7, 0x0

    if-ne v2, v4, :cond_6

    iget v0, p0, Lcom/harindra/iptvpro/PlayerActivity;->c3:I

    if-gtz v1, :cond_2

    goto :goto_1

    :cond_2
    if-eqz p1, :cond_3

    move v5, v6

    :cond_3
    add-int/lit8 p1, v1, -0x1

    move v2, v0

    :goto_0
    if-ge v7, p1, :cond_5

    add-int/2addr v2, v5

    rem-int/2addr v2, v1

    add-int/2addr v2, v1

    rem-int/2addr v2, v1

    iget-object v4, p0, Lcom/harindra/iptvpro/PlayerActivity;->T2:Ljava/util/List;

    invoke-interface {v4, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lm6/n;

    iget-object v4, v4, Lm6/n;->d:Ljava/lang/String;

    iget-object v6, v3, Lm6/n;->d:Ljava/lang/String;

    invoke-static {v4, v6}, Le7/m;->K(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_4

    return v2

    :cond_4
    add-int/lit8 v7, v7, 0x1

    goto :goto_0

    :cond_5
    add-int/2addr v0, v5

    rem-int/2addr v0, v1

    add-int/2addr v0, v1

    rem-int/2addr v0, v1

    return v0

    :cond_6
    invoke-interface {v0}, Ljava/util/Set;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_8

    iget p0, p0, Lcom/harindra/iptvpro/PlayerActivity;->c3:I

    if-eqz p1, :cond_7

    move v5, v6

    :cond_7
    add-int/2addr p0, v5

    return p0

    :cond_8
    iget v2, p0, Lcom/harindra/iptvpro/PlayerActivity;->c3:I

    if-gtz v1, :cond_9

    :goto_1
    return v7

    :cond_9
    if-eqz p1, :cond_a

    move v5, v6

    :cond_a
    add-int/lit8 p1, v1, -0x1

    move v3, v2

    :goto_2
    if-ge v7, p1, :cond_c

    add-int/2addr v3, v5

    rem-int/2addr v3, v1

    add-int/2addr v3, v1

    rem-int/2addr v3, v1

    iget-object v4, p0, Lcom/harindra/iptvpro/PlayerActivity;->T2:Ljava/util/List;

    invoke-interface {v4, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lm6/n;

    iget-object v4, v4, Lm6/n;->a:Ljava/lang/String;

    invoke-interface {v0, v4}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_b

    return v3

    :cond_b
    add-int/lit8 v7, v7, 0x1

    goto :goto_2

    :cond_c
    add-int/2addr v2, v5

    rem-int/2addr v2, v1

    add-int/2addr v2, v1

    rem-int/2addr v2, v1

    return v2

    :cond_d
    :goto_3
    iget p0, p0, Lcom/harindra/iptvpro/PlayerActivity;->c3:I

    if-eqz p1, :cond_e

    move v5, v6

    :cond_e
    add-int/2addr p0, v5

    return p0
.end method

.method public static z(Landroid/widget/EdgeEffect;FF)F
    .locals 2

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1f

    if-lt v0, v1, :cond_0

    invoke-static {p0, p1, p2}, Lj0/e;->c(Landroid/widget/EdgeEffect;FF)F

    move-result p0

    return p0

    :cond_0
    invoke-static {p0, p1, p2}, Lj0/d;->a(Landroid/widget/EdgeEffect;FF)V

    return p1
.end method


# virtual methods
.method public b()V
    .locals 0

    return-void
.end method

.method public c()V
    .locals 0

    return-void
.end method
